export function calculateDaysPassed(timestamp: any) {
  const currentDate: any = new Date(); // Get today's date
  const joinedDate: any = new Date(timestamp); // Convert timestamp to date object

  console.log(joinedDate);

  // Calculate the difference in milliseconds
  const differenceMs = currentDate - joinedDate;

  // Convert milliseconds to days
  const differenceDays = Math.floor(differenceMs / (1000 * 60 * 60 * 24));

  // Format the result
  return `${differenceDays > 0 ? differenceDays + " days" : "1 day"} `;
}

// Example usage
const timestamp = 1721123664760;
const daysPassed = calculateDaysPassed(timestamp);
console.log(daysPassed); // Output: "12 days"
