export function formatDate(timestamp: any) {
  // Create a new Date object from the timestamp
  const date = new Date(timestamp);

  // Define an array of month names
  const monthNames = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];

  // Extract the day, month, and year from the date object
  const day = date.getDate();
  const month = monthNames[date.getMonth()];
  const year = date.getFullYear();

  // Format the date as "12 July, 2024"
  return `${day} ${month}, ${year}`;
}
