import mongoose from "mongoose";

const contentRecordSchema = new mongoose.Schema({
  memberDetails: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Member",
    required: true,
  },
  recordFields: {
    type: Map,
    of: mongoose.Schema.Types.Mixed,
    default: {},
  },
  createDate: {
    type: Date,
    default: Date.now,
  },
});

const ContentRecord =
  mongoose.models.ContentRecord ||
  mongoose.model("ContentRecord", contentRecordSchema);

export default ContentRecord;
