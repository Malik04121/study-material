import mongoose from "mongoose";

const userSchema = new mongoose.Schema({
  fullName: {
    type: String,
    trim: true,
    // required: [true, "Please provide a username"],
  },
  avatar: {
    type: String,
    default:
      "https://hr-network-assets.s3.ap-south-1.amazonaws.com/profile-default-icon-512x511-v4sw4m29.png",
  },
  email: {
    type: String,
    required: [true, "Please provide an Email"],
    unique: true,
    trim: true,
  },
  password: {
    type: String,

    trim: true,
  },
  isVerified: {
    type: Boolean,
    default: false,
  },
  otpForVerification: {
    type: Number,
  },
  expiryDateForOTP: {
    type: Date,
  },
  phoneNumber: {
    type: String,
    unique: true,
    trim: true,
  },
  communityDetails: [
    {
      communityTitle: {
        type: String,
        trim: true,
      },
      communityId: {
        type: String,
        trim: true,
      },
      communityLogo: {
        type: String,
        trim: true,
      },
      memberId: {
        type: String,
        trim: true,
      },
      role: {
        type: String,
        enum: ["Host", "Member"],
        trim: true,
      },
    },
  ],
});

const User = mongoose.models.User || mongoose.model("User", userSchema);

export default User;
