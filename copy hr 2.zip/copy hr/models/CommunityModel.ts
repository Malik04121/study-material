import mongoose from "mongoose";

const applicationFieldSchema = new mongoose.Schema({
  typeOfField: {
    type: String,
    required: true,
  },
  isRequired: {
    type: Boolean,
    required: true,
  },
  labelName: {
    type: String,
    required: true,
  },
  options: {
    type: [String],
    default: [], // This will store the options for select fields
  },
});
const communitySchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, "Please provide a Community Title"],
    trim: true,
  },
  communityLimit: {
    type: String,
    enum: ["less than 10k", "10-100k", "100-500k", "over 500k"],
    default: "less than 10k",
  },
  publicPageUrl: {
    type: String,
    unique: true,
    required: [true, "Please provide a Community Public URL"],
    trim: true,
  },
  logoImage: {
    type: String,
    default:
      "https://hr-network-assets.s3.ap-south-1.amazonaws.com/default_community_logo.jpg",
  },
  description: {
    type: String,
    trim: true,
  },
  coverImage: {
    type: String,
    default:
      "https://hr-network-assets.s3.ap-south-1.amazonaws.com/coverimage.png",
  },
  approvedMembers: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Member",
      default: [],
    },
  ],
  pendingMembers: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Member",
      default: [],
    },
  ],
  rejectedMembers: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Member",
      default: [],
    },
  ],
  isAutoApproveMembership: {
    type: Boolean,
    default: true,
  },
  hostName: {
    type: String,
    trim: true,
  },
  isApplicationRequire: {
    type: Boolean,
    default: false,
  },
  host: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Member",
    required: true,
  },
  welcomeMessageSubject: {
    type: String,
    default: "Welcome to Community",
  },
  welcomeMessageContent: {
    type: String,
    default: `{name}, 

You’re now a member of {community_name}.

And there’s so much for you to explore in the community!
Introduce yourself in the chat group
Go the Community Portal to access your member benefits.
Stay tuned for what's upcoming.`,
  },
  whatsUpGroupLink: {
    type: String,
    default: "",
  },
  applicationFields: [applicationFieldSchema],
  contentTypes: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: "ContentType",
      default: [],
    },
  ],
});

const Community =
  mongoose.models.Community || mongoose.model("Community", communitySchema);

export default Community;
