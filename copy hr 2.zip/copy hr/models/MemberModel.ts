import mongoose from "mongoose";

const memberSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true,
  },
  applicationSubmittedDate: {
    type: Date,
    default: null,
  },
  joinDate: {
    type: Date,
    default: null,
  },
  rejectedDate: {
    type: Date,
    default: null,
  },
  removalReason: {
    type: String,
    default: "",
  },
  additionalFields: {
    type: Map,
    of: String,
    default: {},
  },
});

const Member = mongoose.models.Member || mongoose.model("Member", memberSchema);

export default Member;
