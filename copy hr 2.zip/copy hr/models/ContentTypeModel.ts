import mongoose from "mongoose";

const contentTypeFormFieldSchema = new mongoose.Schema({
  typeOfField: {
    type: String,
    required: true,
  },
  isRequired: {
    type: Boolean,
    required: true,
  },
  labelName: {
    type: String,
    required: true,
  },
  options: {
    type: [String],
    default: [], // This will store the options for select fields
  },
});

const contentTypeSchema = new mongoose.Schema({
  title: {
    type: String,
    trim: true,
    required: [true, "Please provide a Title"],
  },
  description: {
    type: String,
    trim: true,
    required: [true, "Please provide a Description"],
  },
  isActive: {
    type: Boolean,
    default: true,
  },
  contentTypeForm: {
    type: [contentTypeFormFieldSchema], // Make it an array to hold multiple form fields
    default: [], // Default to an empty array if no form fields are provided
  },
  records: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: "ContentRecord",
      default: [],
    },
  ],
  tags: {
    type: [String],
    default: [],
  },
});

const ContentType =
  mongoose.models.ContentType ||
  mongoose.model("ContentType", contentTypeSchema);

export default ContentType;
