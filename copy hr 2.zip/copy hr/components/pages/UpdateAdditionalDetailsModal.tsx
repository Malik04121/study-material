import React from "react";
import { useForm, SubmitHandler, Controller } from "react-hook-form";
import Modal from "../reusable/Modal";
import Select, { SingleValue, MultiValue } from "react-select";
import { CommunityDetails } from "@/types/communityDetails.types";

interface UpdateAdditionalDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  communityDetails: CommunityDetails;
  onSave: (additionalDetails: Map<string, string>) => void;
  additionalMemberDetails: Map<string, string>;
}

interface AdditionalFields {
  [key: string]: any;
}

interface OptionType {
  value: string;
  label: string;
}

const UpdateAdditionalDetailsModal: React.FC<
  UpdateAdditionalDetailsModalProps
> = ({
  isOpen,
  onClose,
  communityDetails,
  onSave,
  additionalMemberDetails,
}) => {
  const {
    register,
    handleSubmit,
    formState: { errors, isValid, isDirty },
    control,
  } = useForm<AdditionalFields>({
    mode: "onChange",
    defaultValues: Object.fromEntries(Array.from(additionalMemberDetails)),
  });

  const onSubmit: SubmitHandler<AdditionalFields> = (data) => {
    onSave(new Map(Object.entries(data)));
    onClose();
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} width="80">
      {communityDetails.applicationFields.length > 0 ? (
        <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-4">
          <h2 className="text-xl font-semibold mb-4">
            Update Additional Details
          </h2>
          {communityDetails.applicationFields.map((field, index) => (
            <div key={index} className="w-full">
              <label htmlFor={field.labelName} className="form-label">
                {field.labelName}
                {field.isRequired && "*"}
              </label>
              {field.typeOfField === "text" && (
                <input
                  type="text"
                  {...register(field.labelName, {
                    required: field.isRequired
                      ? `${field.labelName} is required`
                      : false,
                  })}
                  placeholder={field.labelName}
                  className="create-community-input"
                />
              )}
              {field.typeOfField === "number" && (
                <input
                  type="number"
                  {...register(field.labelName, {
                    required: field.isRequired
                      ? `${field.labelName} is required`
                      : false,
                  })}
                  placeholder={field.labelName}
                  className="create-community-input"
                />
              )}
              {field.typeOfField === "single-select" && (
                <Controller
                  name={field.labelName}
                  control={control}
                  rules={{
                    required: field.isRequired
                      ? `${field.labelName} is required`
                      : false,
                  }}
                  render={({
                    field: { onChange, value },
                    fieldState: { error },
                  }) => (
                    <>
                      <Select
                        options={field.options?.map((option) => ({
                          value: option,
                          label: option,
                        }))}
                        value={field.options
                          ?.map((option) => ({ value: option, label: option }))
                          .find((option) => option.value === value)}
                        onChange={(selectedOption: SingleValue<OptionType>) =>
                          onChange(selectedOption?.value)
                        }
                        className="create-community-input"
                        placeholder={`Select ${field.labelName}`}
                      />
                      {error && (
                        <p className="text-red-500 text-sm">{error.message}</p>
                      )}
                    </>
                  )}
                />
              )}
              {field.typeOfField === "multi-select" && (
                <Controller
                  name={field.labelName}
                  control={control}
                  rules={{
                    required: field.isRequired
                      ? `${field.labelName} is required`
                      : false,
                  }}
                  render={({
                    field: { onChange, value },
                    fieldState: { error },
                  }) => (
                    <>
                      <Select
                        options={field.options?.map((option) => ({
                          value: option,
                          label: option,
                        }))}
                        isMulti
                        value={field.options
                          ?.map((option) => ({ value: option, label: option }))
                          .filter((option) => value?.includes(option.value))}
                        onChange={(selectedOptions: MultiValue<OptionType>) =>
                          onChange(
                            selectedOptions
                              ? selectedOptions.map((option) => option.value)
                              : []
                          )
                        }
                        className="create-community-input"
                        placeholder={`Select ${field.labelName}`}
                      />
                      {error && (
                        <p className="text-red-500 text-sm">{error.message}</p>
                      )}
                    </>
                  )}
                />
              )}
              {field.typeOfField === "url" && (
                <input
                  type="url"
                  {...register(field.labelName, {
                    required: field.isRequired
                      ? `${field.labelName} is required`
                      : false,
                  })}
                  placeholder={field.labelName}
                  className="create-community-input"
                />
              )}
              {errors[field.labelName] && (
                <p className="text-red-500 text-sm">
                  {(errors[field.labelName]?.message as string) ||
                    "This field is required"}
                </p>
              )}
            </div>
          ))}
          <button
            type="submit"
            disabled={!isValid && isDirty}
            className="primaryButton"
          >
            Update
          </button>
        </form>
      ) : (
        <div className="text-center text-gray-900 mt-4">
          No additional details are required for this community at this time.
        </div>
      )}
    </Modal>
  );
};

export default UpdateAdditionalDetailsModal;
