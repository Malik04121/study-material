import { useForm, useFieldArray, Controller } from "react-hook-form";
import { AiOutlineDelete } from "react-icons/ai";
import CreatableSelect from "react-select/creatable";
import React, { useState } from "react";
import axios from "axios";
import { CommunityDetails, ContentType } from "@/types/communityDetails.types";
import toast from "react-hot-toast";

type ContentTypeFormField = {
  typeOfField: string;
  isRequired: boolean;
  labelName: string;
  options?: string[];
};

type ContentTypeForm = {
  title: string;
  description: string;
  contentTypeForm: ContentTypeFormField[];
  tags?: { value: string; label: string }[]; // Made tags optional
};

type ContentProps = {
  onClose: () => void;
  communityDetails: CommunityDetails;
  contentType?: ContentType | null;
};

export default function DynamicForm({
  onClose,
  communityDetails,
  contentType,
}: ContentProps) {
  const [loading, setLoading] = useState(false); // Loading state
  const isViewOnly = contentType?.records?.length
    ? contentType.records.length > 0
    : false;

  const {
    control,
    handleSubmit,
    register,
    setValue,
    trigger, // Trigger manual validation
    watch,
    getValues,
    formState: { errors, isValid },
  } = useForm<ContentTypeForm>({
    mode: "onChange", // Validate on change
    defaultValues: {
      title: contentType?.title || "",
      description: contentType?.description || "",
      contentTypeForm: contentType?.contentTypeForm || [
        { typeOfField: "text-single", isRequired: false, labelName: "" },
      ],
      tags: contentType?.tags.map((tag) => ({ value: tag, label: tag })) || [],
    },
  });

  const { fields, append, remove } = useFieldArray({
    control,
    name: "contentTypeForm",
  });

  const [optionInputs, setOptionInputs] = useState<Record<number, string>>({});

  const onSubmit = async (data: ContentTypeForm) => {
    if (isViewOnly) return; // Prevent form submission if view-only mode is active

    setLoading(true); // Start loading
    try {
      const formattedData = {
        ...data,
        tags: data.tags?.map((tag) => tag.value),
      };

      const apiUrl = contentType
        ? `/api/content/${contentType._id}`
        : "/api/content";
      const method = contentType ? "put" : "post";

      await axios[method](apiUrl, {
        ...formattedData,
        communityId: communityDetails._id,
      });

      toast(
        contentType
          ? "Content type updated successfully!"
          : "Content type created successfully!",
        {
          icon: "✅",
          style: {
            backgroundColor: "#454545",
            color: "white",
          },
        }
      );

      onClose();
    } catch (error) {
      if (axios.isAxiosError(error)) {
        toast(
          `Error: ${
            error.response?.data?.message || "An unknown error occurred"
          }`,
          {
            icon: "❌",
            style: {
              backgroundColor: "#454545",
              color: "white",
            },
          }
        );
      } else {
        toast("Unexpected error occurred. Please try again.", {
          icon: "❌",
          style: {
            backgroundColor: "#454545",
            color: "white",
          },
        });
      }
    } finally {
      setLoading(false); // End loading
    }
  };

  const handleTitleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value
      .replace(/[^a-zA-Z\s]/g, "")
      .replace(/\b\w/g, (char) => char.toUpperCase());
    setValue("title", value, { shouldValidate: true }); // Validate after setting value
  };

  const handleFieldTypeChange = async (
    e: React.ChangeEvent<HTMLSelectElement>,
    index: number
  ) => {
    const newFieldType = e.target.value;
    setValue(`contentTypeForm.${index}.typeOfField`, newFieldType);

    if (newFieldType === "single-select" || newFieldType === "multi-select") {
      setValue(`contentTypeForm.${index}.options`, []); // Initialize options as an empty array
    } else {
      setValue(`contentTypeForm.${index}.options`, undefined);
    }

    await trigger(`contentTypeForm.${index}.options`); // Manually trigger validation
  };

  const handleAddOption = async (index: number) => {
    const optionValue = optionInputs[index];
    if (!optionValue || optionValue.trim() === "") return;

    const currentOptions = getValues(`contentTypeForm.${index}.options`) || [];
    const newOptions = [...currentOptions, optionValue];
    setValue(`contentTypeForm.${index}.options`, newOptions);
    setOptionInputs({ ...optionInputs, [index]: "" });

    await trigger(`contentTypeForm.${index}.options`); // Manually trigger validation
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 px-5">
      <h3 className="text-lg text-center font-semibold">
        {isViewOnly ? "View Content Form" : "Content Form"}
      </h3>
      <div className="mb-4">
        <label className="block mb-2 font-medium">
          {" "}
          <span className="text-red-600">*</span> Title
        </label>
        <input
          {...register("title", {
            required: "Title is required",
            validate: (value) =>
              /^[A-Za-z\s]{3,}$/.test(value) ||
              "Title must contain only alphabets and spaces, and be at least 3 characters long.",
          })}
          type="text"
          placeholder="Enter title"
          onChange={handleTitleChange}
          className={`border border-gray-300 rounded-md p-2 w-full outline-none focus:border-black ${
            errors.title ? "border-red-500" : ""
          }`}
          disabled={isViewOnly} // Disable input if view-only mode is active
        />
        {errors.title && (
          <p className="text-xs text-red-500 text-sm pt-1">
            {errors.title.message}
          </p>
        )}
      </div>

      <div className="mb-4">
        <label className="block mb-2 font-medium">
          {" "}
          <span className="text-red-600">*</span> Description
        </label>
        <textarea
          {...register("description")}
          placeholder="Enter description"
          className="border border-gray-300 rounded-md p-2 w-full outline-none focus:border-black"
          disabled={isViewOnly} // Disable textarea if view-only mode is active
        />
      </div>

      <div className="mb-4">
        <label className="block mb-2 font-medium"> Tags</label>
        <Controller
          control={control}
          name="tags"
          render={({ field }) => (
            <CreatableSelect
              isMulti
              value={field.value}
              onChange={field.onChange}
              options={[]}
              className={`border border-gray-300 rounded-md p-2 w-full outline-none focus:border-black`}
              classNamePrefix="react-select"
              placeholder="Enter tags"
              isDisabled={isViewOnly} // Disable tag selection if view-only mode is active
              styles={{
                control: (base) => ({
                  ...base,
                  borderWidth: 0, // Remove the inner border
                  boxShadow: "none", // Remove any box shadow
                  "&:hover": {
                    borderColor: "#000",
                  },
                }),
                container: (base) => ({
                  ...base,
                  border: "1px solid #d1d5db",
                  borderRadius: "0.375rem",
                  padding: "2px",
                }),
                multiValue: (base) => ({
                  ...base,
                  backgroundColor: "#e5e7eb",
                  color: "#374151",
                  borderRadius: "0.375rem",
                }),
                multiValueLabel: (base) => ({
                  ...base,
                  color: "#374151",
                }),
                multiValueRemove: (base) => ({
                  ...base,
                  color: "#374151",
                  "&:hover": {
                    backgroundColor: "#f87171",
                    color: "white",
                  },
                }),
              }}
            />
          )}
        />
      </div>

      {fields.map((item, index) => (
        <div key={item.id} className="bg-gray-100 p-4 shadow-md rounded-lg">
          <div className="flex items-center justify-between flex-col gap-3">
            <div className="w-full flex justify-between gap-2">
              <div className="flex-1">
                <select
                  {...register(`contentTypeForm.${index}.typeOfField`, {
                    required: "Field Type is required",
                  })}
                  className="border border-gray-300 rounded-md p-2 w-full"
                  onChange={(e) => handleFieldTypeChange(e, index)}
                  disabled={isViewOnly} // Disable select if view-only mode is active
                >
                  <option value="text-single">Single Line Text</option>
                  <option value="text-multi">Multi Line Text</option>
                  <option value="single-select">Single Select</option>
                  <option value="multi-select">Multi Select</option>
                  <option value="file-upload">File Upload</option>
                </select>
              </div>
              <div className="flex items-center space-x-2">
                <label
                  htmlFor={`contentTypeForm.${index}.isRequired`}
                  className="text-gray-700"
                >
                  Required
                </label>
                <input
                  {...register(`contentTypeForm.${index}.isRequired`)}
                  type="checkbox"
                  onChange={(e) => {
                    // First, call the registered onChange event from react-hook-form
                    register(`contentTypeForm.${index}.isRequired`).onChange(e);

                    // Then trigger validation after updating the field value
                    trigger();
                  }}
                  className="h-4 w-4 border-gray-300 rounded"
                  disabled={isViewOnly} // Disable checkbox if view-only mode is active
                />
              </div>
            </div>
            <div className="w-full flex justify-between gap-2">
              <div className="flex-1">
                <input
                  {...register(`contentTypeForm.${index}.labelName`, {
                    required: "Label Name is required",
                  })}
                  type="text"
                  placeholder="Enter label"
                  className="border border-gray-300 rounded-md p-2 w-full outline-none focus:border-black"
                  disabled={isViewOnly} // Disable input if view-only mode is active
                />
              </div>
              {!isViewOnly && ( // Show delete button only if not in view-only mode
                <button
                  type="button"
                  onClick={() => {
                    remove(index);
                    trigger(); // Trigger validation after removing
                  }}
                  className="text-red-500"
                >
                  <AiOutlineDelete size={20} />
                </button>
              )}
            </div>
          </div>

          {(watch(`contentTypeForm.${index}.typeOfField`) === "single-select" ||
            watch(`contentTypeForm.${index}.typeOfField`) ===
              "multi-select") && (
            <Controller
              control={control}
              name={`contentTypeForm.${index}.options`}
              rules={{
                validate: (value) =>
                  value && value.length >= 2
                    ? true
                    : "At least two options are required for select fields.",
              }}
              render={({ field }) => (
                <div className="mt-4">
                  <label className="block mb-2 font-semibold">Options</label>
                  {field.value?.map((option: string, optIndex: number) => (
                    <div key={optIndex} className="flex items-center mb-2">
                      <input
                        value={option}
                        onChange={(e) => {
                          const newOptions = [...(field.value || [])];
                          newOptions[optIndex] = e.target.value;
                          field.onChange(newOptions);
                        }}
                        type="text"
                        placeholder="Enter option"
                        className="border border-gray-300 rounded-md p-2 w-full"
                        disabled={isViewOnly} // Disable option input if view-only mode is active
                      />
                      {!isViewOnly && (
                        <button
                          type="button"
                          className="text-red-500 ml-2"
                          onClick={() => {
                            const newOptions = [...(field.value || [])];
                            newOptions.splice(optIndex, 1);
                            field.onChange(newOptions);
                            trigger(`contentTypeForm.${index}.options`); // Manually trigger validation
                          }}
                        >
                          <AiOutlineDelete size={20} />
                        </button>
                      )}
                    </div>
                  ))}
                  {!isViewOnly && (
                    <div className="flex items-center mb-2">
                      <input
                        type="text"
                        placeholder="Enter option and press Add"
                        value={optionInputs[index] || ""}
                        onChange={(e) =>
                          setOptionInputs({
                            ...optionInputs,
                            [index]: e.target.value,
                          })
                        }
                        className="border border-gray-300 rounded-md p-2 w-full"
                        onKeyDown={async (e) => {
                          if (e.key === "Enter" && optionInputs[index]) {
                            e.preventDefault();
                            await handleAddOption(index);
                          }
                        }}
                      />
                      <button
                        type="button"
                        className="text-black border border-black flex justify-center items-center p-2 rounded-full w-7 h-7 ml-2"
                        onClick={async () => await handleAddOption(index)}
                      >
                        <p>+</p>
                      </button>
                    </div>
                  )}
                  {errors.contentTypeForm?.[index]?.options && (
                    <p className="text-xs text-red-500 text-sm pt-1">
                      {errors.contentTypeForm?.[index]?.options?.message}
                    </p>
                  )}
                </div>
              )}
            />
          )}
        </div>
      ))}

      <div className="flex flex-col mt-8 w-full">
        {!isViewOnly && (
          <button
            type="button"
            className="secondaryButton"
            onClick={() =>
              append({
                typeOfField: "text-single",
                isRequired: false,
                labelName: "",
              })
            }
            disabled={loading} // Disable button during loading
          >
            {loading ? "Loading..." : "Add Question"}
          </button>
        )}
        <button
          type="submit"
          className="primaryButton"
          disabled={!isValid || loading || isViewOnly} // Disable if form is invalid, during loading, or in view-only mode
        >
          {loading ? "Loading..." : contentType ? "Update" : "Submit"}
        </button>
      </div>
    </form>
  );
}
