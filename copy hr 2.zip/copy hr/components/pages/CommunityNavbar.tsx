// Navbar.tsx
import React, { useEffect, useRef, useState } from "react";
import Image from "next/image";
import { CommunityDetails } from "@/types/communityDetails.types";
import axios from "axios";
import { Router } from "next/router";
import { useRouter } from "next/navigation";
import { User } from "@/types/user.types";
import Link from "next/link";

interface NavbarProps {
  onMenuToggle: () => void;
  communityDetails?: CommunityDetails;
  activePage: string;
  loggedUserData?: User;
}

const CommunityNavbar: React.FC<NavbarProps> = ({
  onMenuToggle,
  communityDetails,
  activePage,
  loggedUserData,
}) => {
  const [showProfile, setShowProfile] = useState<boolean>(false);
  const profileRef = useRef<HTMLDivElement>(null);
  const buttonRef = useRef<HTMLButtonElement>(null);
  const router = useRouter();
  console.log(communityDetails);
  const handleClickOutside = (event: MouseEvent) => {
    if (
      profileRef.current &&
      !profileRef.current.contains(event.target as Node) &&
      buttonRef.current &&
      !buttonRef.current.contains(event.target as Node)
    ) {
      setShowProfile(false);
    }
  };

  const logout = async () => {
    try {
      const response = await axios.delete("/api/users/logout");

      if (response.data) {
        router.push("/login");
      }
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);
  console.log(showProfile);
  return (
    <nav className="bg-white p-4 flex justify-between items-center gap-5 relative">
      <div className="flex justify-start items-center gap-5">
        {communityDetails && (
          <button
            type="button"
            onClick={onMenuToggle}
            className="relative w-11 h-11 overflow-hidden rounded-md"
          >
            <Image
              src={communityDetails.logoImage}
              alt="profile_photo"
              width={70}
              height={70}
              className=" object-cover  w-full h-full "
            />
            <div className="w-5 h-5 absolute -right-1 -bottom-1 bg-white rounded-full p-1">
              <Image
                src={"/assets/icons/menu.png"}
                alt="update"
                width={20}
                height={20}
                className="object-cover object-center"
              />
            </div>
          </button>
        )}
        <h1 className="text-2xl font-bold text-primaryBlack  ">{activePage}</h1>
      </div>
      {loggedUserData && (
        <div className="flex justify-center items-center gap-2">
          <button
            ref={buttonRef}
            type="button"
            className="flex justify-center items-center gap-3 rounded-2xl bg-white hover:bg-gray-200 p-1"
            onClick={(e) => {
              e.stopPropagation();
              setShowProfile((prev) => !prev);
            }}
          >
            <div className="w-8 h-8 rounded-full overflow-hidden">
              <Image
                src={loggedUserData?.avatar}
                alt="user_logo"
                width={100}
                height={100}
                className="object-cover w-full h-full"
              />
            </div>
            <div className="w-4 h-4">
              <Image
                src={"/assets/icons/menu.png"}
                alt="menu_icon"
                width={100}
                height={100}
                className="object-center object-cover"
              />
            </div>
          </button>
        </div>
      )}
      {showProfile && (
        <div
          ref={profileRef}
          className="absolute right-0 -bottom-[250%] z-[100] min-w-[50%] rounded-md bg-white text-primaryBlack  drop-shadow-2xl"
        >
          <div className="flex flex-col justify-between items-startFcon p-4 gap-4">
            <div className="text-sm ">
              <p>{loggedUserData?.fullName}</p>
              <p className="text-gray-500 font-extralight">
                {loggedUserData?.email}
              </p>
            </div>
            <hr className="bg-gray-600 w-full h-[1px] border border-gray-700" />

            <Link
              href={`/user/profile?fromPortal=${communityDetails?._id}`}
              onClick={() => {
                setShowProfile(false);
              }}
              className="flex justify-start items-center gap-2 w-full"
            >
              <Image
                src={"/assets/icons/demo_profile.png"}
                alt="profile_icon"
                width={15}
                height={15}
              />
              <p className="text-sm">Profile Settings</p>
            </Link>
            <Link
              href={`/community`}
              onClick={() => {
                setShowProfile(false);
              }}
              className="flex justify-start items-center gap-2 w-full"
            >
              <Image
                src={"/assets/icons/members.png"}
                alt="logo"
                width={15}
                height={15}
              />
              <p className="text-sm">My Communities</p>
            </Link>
            <button
              type="button"
              onClick={() => {
                setShowProfile(false);
                logout();
              }}
              className="flex justify-start items-center gap-2 w-full"
            >
              <Image
                src={"/assets/icons/logout.png"}
                alt="logout_icon"
                width={15}
                height={15}
              />
              <p className="text-sm">Logout</p>
            </button>
          </div>
        </div>
      )}
    </nav>
  );
};

export default CommunityNavbar;
