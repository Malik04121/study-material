"use client";
import Footer from "@/components/Footer";
import { User } from "@/types/user.types";
import axios from "axios";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import React, { useEffect, useRef, useState } from "react";

const MyCommunity = () => {
  const [showProfile, setShowProfile] = useState<boolean>(false);
  const profileRef = useRef<HTMLDivElement>(null);
  const buttonRef = useRef<HTMLButtonElement>(null);
  const router = useRouter();
  const [loggedUserData, setLoggedUserData] = useState<User>();

  const handleClickOutside = (event: MouseEvent) => {
    if (
      profileRef.current &&
      !profileRef.current.contains(event.target as Node) &&
      buttonRef.current &&
      !buttonRef.current.contains(event.target as Node)
    ) {
      setShowProfile(false);
    }
  };

  const logout = async () => {
    try {
      const response = await axios.delete("/api/users/logout");
      if (response.data) {
        router.push("/login");
      }
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  useEffect(() => {
    const init = async () => {
      try {
        const res = await axios.get("/api/users/get-community");
        setLoggedUserData(res.data.user);
      } catch (error) {
        console.error("error", error);
        router.push("/unauthorized");
      }
    };
    init();
  }, [router]);

  const communities = loggedUserData?.communityDetails || [];
  console.log(communities);

  const hostCommunities = communities.filter(
    (community) => community.role === "Host"
  );
  const subscribedCommunities = communities.filter(
    (community) => community.role !== "Host"
  );

  const hasAnyCommunities = communities.length > 0;

  return (
    <main className="bg-white-bg desktopView w-screen relative min-h-screen">
      <nav className="bg-white px-4 py-2 flex justify-between items-center gap-5 relative">
        <div className="flex justify-start items-center gap-5">
          <Image src={"/logo.jpeg"} alt="logo" width={70} height={70} />
        </div>
        {loggedUserData && (
          <div className="flex justify-center items-center gap-2">
            <button
              ref={buttonRef}
              type="button"
              className="flex justify-center items-center gap-3 rounded-2xl bg-white hover:bg-gray-200 p-1 "
              onClick={(e) => {
                e.stopPropagation();
                setShowProfile((prev) => !prev);
              }}
            >
              <div className="w-8 h-8 rounded-full overflow-hidden">
                <Image
                  src={loggedUserData?.avatar}
                  alt="user_logo"
                  width={100}
                  height={100}
                  className="object-cover w-full h-full"
                />
              </div>
              <div className="w-4 h-4">
                <Image
                  src={"/assets/icons/menu.png"}
                  alt="menu_icon"
                  width={100}
                  height={100}
                  className="object-center object-cover"
                />
              </div>
            </button>
          </div>
        )}
        {showProfile && (
          <div
            ref={profileRef}
            className="absolute right-0 -bottom-[100%] z-[100] min-w-[50%] rounded-md bg-white text-primaryBlack  drop-shadow-2xl"
          >
            <div className="flex flex-col justify-between items-start p-4 gap-4">
              <div className="text-sm">
                <p>{loggedUserData?.fullName}</p>
                <p className="text-gray-500 font-extralight">
                  {loggedUserData?.email}
                </p>
              </div>
              <hr className="bg-gray-600 w-full h-[1px] border border-gray-700" />

              <button
                type="button"
                onClick={() => {
                  setShowProfile(false);
                  logout();
                }}
                className="flex justify-start items-center gap-2 w-full"
              >
                <Image
                  src={"/assets/icons/logout.png"}
                  alt="logout_icon"
                  width={15}
                  height={15}
                />
                <p className="text-sm">Logout</p>
              </button>
            </div>
          </div>
        )}
      </nav>
      <div className="p-6 bg-gray-100 min-h-[75vh]">
        {!hasAnyCommunities && (
          <div className="text-center mt-20">
            <p className="text-gray-700 text-lg font-medium">
              You haven&apos;t joined any community yet.
            </p>
          </div>
        )}

        {hasAnyCommunities && hostCommunities.length > 0 && (
          <div className="mb-8">
            <h2 className="text-xl font-semibold mb-4">Your Communities</h2>
            <div className="flex flex-wrap gap-6">
              {hostCommunities.map((community) => (
                <Link
                  href={`/portal/home/${community.communityId}`}
                  key={community._id}
                  target="_blank"
                  className="bg-white p-4 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300 w-full flex flex-row gap-5 items-center"
                >
                  <div className="w-14 h-14">
                    <Image
                      src={community.logoImage}
                      alt={community.communityTitle}
                      width={80}
                      height={80}
                      className="w-full h-full object-cover rounded-md"
                    />
                  </div>
                  <div className="flex-1 overflow-hidden">
                    <p className="text-lg font-medium text-gray-800 truncate">
                      {community.communityTitle}
                    </p>
                    <p className="text-sm text-gray-500">{community.role}</p>
                  </div>
                  <div>
                    <Image
                      src={"/assets/icons/link.svg"}
                      alt="Link icon"
                      width={17}
                      height={17}
                    />
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}

        {hasAnyCommunities && subscribedCommunities.length > 0 && (
          <div>
            <h2 className="text-xl font-semibold mb-4">
              Subscribed Communities
            </h2>
            <div className="flex flex-wrap gap-6">
              {subscribedCommunities.map((community) => (
                <Link
                  href={`/${community.publicPageUrl}`}
                  key={community._id}
                  target="_blank"
                  className="bg-white p-4 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300 w-full flex flex-row gap-5 items-center"
                >
                  <div className="w-14 h-14">
                    <Image
                      src={community.logoImage}
                      alt={community.communityTitle}
                      width={80}
                      height={80}
                      className="w-full h-full object-cover rounded-md"
                    />
                  </div>
                  <div className="flex-1 overflow-hidden">
                    <p className="text-lg font-medium text-gray-800 truncate">
                      {community.communityTitle}
                    </p>
                    <p className="text-sm text-gray-500">{community.role}</p>
                  </div>
                  <div>
                    <Image
                      src={"/assets/icons/link.svg"}
                      alt="Link icon"
                      width={17}
                      height={17}
                    />
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
      <Footer />
    </main>
  );
};

export default MyCommunity;
