"use client";
import AboutCommunity from "@/components/publicPage/AboutCommunity";
import Navbar from "@/components/publicPage/Navbar";
import {
  CommunityDetails,
  ContentType,
  RecordType,
} from "@/types/communityDetails.types";
import { User, CommunityStatus } from "@/types/user.types";
import axios from "axios";
import Image from "next/image";
import React, { Suspense, useEffect, useState } from "react";
import { SubmitHandler, useForm } from "react-hook-form";
import toast, { Toaster } from "react-hot-toast";
import { useRouter } from "next/navigation";
import AdditionalDetailsForm from "./communityDashboard/settingForms/AdditionalDetailsForm"; // Import the new component
import Modal from "../reusable/Modal";
import Select, { MultiValue } from "react-select";
import { FaCopy } from "react-icons/fa";

import Link from "next/link";
import Head from "next/head";
import Footer from "../Footer";

interface FormValues {
  email: string;
  otp: string;
}

type userFields = {
  email: string;
  phoneNumber: string;
  fullName: string;
};
type TagOption = {
  value: string;
  label: string;
};

type GroupedRecords = {
  [monthYear: string]: RecordType[];
};

const CommunityPage = ({ params }: { params: { publicPageUrl: string } }) => {
  const decodedUrl = decodeURIComponent(params.publicPageUrl);
  const [communityDetails, setCommunityDetails] = useState<CommunityDetails>();
  const [loggedUserData, setLoggedUserData] = useState<User>();
  const [activeTab, setActiveTab] = useState<String>("home");
  const [isJoinCommunityFormOpen, setIsJoinCommunityOpen] =
    useState<boolean>(false);
  const [showRecords, setShowRecords] = useState<boolean>(false);

  const [isOTPSend, setIsOTPsend] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);
  const [openUserDetailsForm, setOpenUserDetailsForm] =
    useState<boolean>(false);
  const [isAdditionDetailsReq, setIsAdditionDetailsReq] =
    useState<boolean>(false);
  const [tags, setTags] = useState<TagOption[]>([]);

  const [countdown, setCountdown] = useState(-1);
  const [showPendingReqModal, setShowPendingReqModal] =
    useState<boolean>(false);
  const router = useRouter();
  const [selectedContentType, setSelectedContentType] =
    useState<ContentType | null>();
  const [selectedTags, setSelectedTags] = useState<MultiValue<TagOption>>([]);
  const [filteredRecords, setFilteredRecords] = useState<RecordType[]>([]);
  const [copySuccess, setCopySuccess] = useState(false);
  const [isListView, setIsListView] = useState(true); // New state to toggle between views
  const [selectedRecord, setSelectedRecord] = useState<RecordType | null>();

  const [dateFilter, setDateFilter] = useState<string | null>("today");
  const [selectedMonth, setSelectedMonth] = useState<string | null>(null); // For month dropdown
  const [textFilter, setTextFilter] = useState<string>("");

  const {
    register,
    handleSubmit,
    watch,
    reset,
    setValue,
    formState: { errors },
  } = useForm<FormValues>({ mode: "onChange" });

  const {
    register: registerUser,
    handleSubmit: handleSubmitUser,
    formState: { errors: userErrors, isValid: isUserValid },
    setError,
    getValues,
    setValue: setUser,
  } = useForm<userFields>({
    mode: "onChange",
    defaultValues: {
      email: loggedUserData?.email,
    },
  });

  useEffect(() => {
    const init = async () => {
      await fetchCommunity();
      await checkTokenValidity();
    };
    init();
  }, []);

  useEffect(() => {
    if (communityDetails && loggedUserData) {
      checkIsUserHost(communityDetails, loggedUserData);
    }
    if (loggedUserData?.communityStatus === "Pending") {
      setShowPendingReqModal(true);
    }
  }, [communityDetails, loggedUserData]);

  const copyToClipboard = async () => {
    try {
      if (selectedContentType) {
        await navigator.clipboard.writeText(
          `${process.env.NEXT_PUBLIC_DOMAIN_NAME}/content-form/${communityDetails?._id}/${selectedContentType._id}`
        );
        setCopySuccess(true);
      }
    } catch (err) {
      console.error("Failed to copy:", err);
    }
  };
  const handleCloseRecordModal = () => {
    setSelectedRecord(null);
  };
  useEffect(() => {
    if (copySuccess) {
      // toast.success("Link copied to clipboard!");
      toast("Link copied to clipboard!", {
        icon: "👍",
        style: {
          backgroundColor: "white",
          color: "black",
        },
      });
      setCopySuccess(false);
    }
  }, [copySuccess]);

  const fetchCommunity = async () => {
    try {
      const response = await axios.get(
        `/api/community/get-by-public-url/${decodedUrl}`
      );
      console.log("response", response.data);

      if (response.status === 200) {
        setCommunityDetails(response.data.community);
      } else {
        console.log("Unexpected status code:", response.status);
        router.push("/not-found");
      }
    } catch (error) {
      console.error(error);
      router.push("/not-found");
    }
  };

  const filterByDate = (records: RecordType[]) => {
    const today = new Date();
    const normalizeDate = (date: Date) =>
      new Date(date.getFullYear(), date.getMonth(), date.getDate());

    return records.filter((record) => {
      if (!record.createDate) {
        console.log("Invalid or missing createdAt field in record:", record);
        return false; // Skip records with invalid or missing dates
      }

      const recordDate = new Date(record.createDate);

      // Check if recordDate is valid
      if (isNaN(recordDate.getTime())) {
        console.log("Invalid date format in record:", record);
        return false; // Skip records with invalid dates
      }

      const normalizedRecordDate = normalizeDate(recordDate);

      if (dateFilter === "today") {
        return (
          normalizedRecordDate.getTime() === normalizeDate(today).getTime()
        );
      } else if (dateFilter === "yesterday") {
        const yesterday = new Date(today);
        yesterday.setDate(yesterday.getDate() - 1);
        return (
          normalizedRecordDate.getTime() === normalizeDate(yesterday).getTime()
        );
      } else if (dateFilter === "last7days") {
        const last7Days = new Date(today);
        last7Days.setDate(last7Days.getDate() - 7);
        return (
          normalizedRecordDate.getTime() >= normalizeDate(last7Days).getTime()
        );
      } else if (dateFilter === "last30days") {
        const last30Days = new Date(today);
        last30Days.setDate(last30Days.getDate() - 30);
        return (
          normalizedRecordDate.getTime() >= normalizeDate(last30Days).getTime()
        );
      } else if (dateFilter === "month" && selectedMonth) {
        const [year, month] = selectedMonth.split("-");
        return (
          normalizedRecordDate.getFullYear() === parseInt(year) &&
          normalizedRecordDate.getMonth() + 1 === parseInt(month)
        );
      }

      return true;
    });
  };

  const filterRecords = () => {
    let filtered = selectedContentType?.records || [];

    if (selectedTags.length > 0) {
      filtered = filtered.filter((record) =>
        selectedTags.every((tag) => {
          const tagInTags = record.recordFields.tags
            ?.split(", ")
            .includes(tag.value);
          const tagInFields = Object.values(record.recordFields).some(
            (answer) => typeof answer === "string" && answer === tag.value
          );
          return tagInTags || tagInFields;
        })
      );
    }

    if (dateFilter || selectedMonth) {
      filtered = filterByDate(filtered);
    }

    if (textFilter) {
      filtered = filtered.filter((record) =>
        Object.values(record.recordFields).some(
          (answer) =>
            typeof answer === "string" &&
            answer.toLowerCase().includes(textFilter.toLowerCase())
        )
      );
    }

    setFilteredRecords(filtered);
  };
  useEffect(() => {
    if (selectedContentType) {
      // Create a Set to store unique tags
      const uniqueTagsSet = new Set<string>();

      // Extract tags from selectedContentType tags array
      if (selectedContentType.tags) {
        selectedContentType.tags.forEach((tag) => uniqueTagsSet.add(tag));
      }

      // Extract answers from recordFields and add them to the Set
      // selectedContentType.records.forEach((record) => {
      //   Object.values(record.recordFields).forEach((answer) => {
      //     if (typeof answer === "string") {
      //       uniqueTagsSet.add(answer);
      //     }
      //   });
      // });

      // Convert the Set to an array of TagOption objects
      const uniqueTagsArray = Array.from(uniqueTagsSet).map((tag) => ({
        value: tag,
        label: tag,
      }));
      console.log(uniqueTagsArray);

      setTags(uniqueTagsArray);
      setFilteredRecords(selectedContentType.records);
    }
  }, [selectedContentType]);
  // Run filterRecords whenever dateFilter, selectedMonth, or selectedTags change
  useEffect(() => {
    filterRecords();
  }, [dateFilter, selectedMonth, selectedTags, textFilter]);

  const checkTokenValidity = async () => {
    try {
      const response = await axios.get("/api/users/check-user");
      if (response.data) {
        setLoggedUserData(response.data.user);
      }
      return true;
    } catch (error) {
      console.error(error);
      return false;
    }
  };

  const checkIsUserHost = (
    communityDetails: CommunityDetails,
    loggedUserData: User
  ) => {
    if (
      loggedUserData.communityStatus === CommunityStatus.HOST ||
      loggedUserData.communityStatus === CommunityStatus.Member ||
      loggedUserData.communityStatus === CommunityStatus.NEW ||
      loggedUserData.communityStatus === CommunityStatus.PENDING
    ) {
      return;
    }

    let updatedUser: User | undefined = undefined;

    communityDetails.approvedMembers.map((member) => {
      if (member.userId?._id === loggedUserData._id) {
        loggedUserData.communityDetails.map((community) => {
          if (community.communityId === communityDetails._id) {
            console.log(community);

            updatedUser = {
              ...loggedUserData,
              communityStatus:
                community.role === "Host"
                  ? CommunityStatus.HOST
                  : CommunityStatus.Member,
            };
          }
        });
      }
    });
    console.log(updatedUser);

    if (updatedUser) {
      setLoggedUserData(updatedUser);
      return;
    }
    communityDetails.pendingMembers.map((member) => {
      if (member.userId?._id === loggedUserData._id) {
        // loggedUserData.communityDetails.map((community) => {
        //   if (community.communityId === communityDetails._id) {
        updatedUser = {
          ...loggedUserData,
          communityStatus: CommunityStatus.PENDING,
        };
        //   }
        // });
      }
    });
    if (updatedUser) {
      setLoggedUserData(updatedUser);
    } else {
      setLoggedUserData({
        ...loggedUserData,
        communityStatus: CommunityStatus.NEW,
      });
    }
  };

  const sentOtp = async () => {
    try {
      const response = await axios.post("/api/aws/sent-otp", {
        email: watch("email"),
      });
      if (response) {
        toast("Check your email for OTP", {
          icon: "💁🏻",
          style: {
            backgroundColor: "#454545",
            color: "white",
            zIndex: "10000",
          },
        });
        startCountdown();

        setIsOTPsend(true);
      }
    } catch (error) {
      console.error(error);
      toast("Email service error", {
        icon: "❌",
        style: { backgroundColor: "#454545", color: "white", zIndex: "10000" },
      });
    }
  };

  const checkOtp = async () => {
    try {
      const response = await axios.post("/api/users/check-otp", {
        email: watch("email"),
        otp: watch("otp"),
        isCheckOtpVerificationOnly: true,
      });

      if (response) {
        toast("OTP verified successfully!", {
          icon: "✅",
          style: { backgroundColor: "#454545", color: "white" },
        });

        let checkUserPartOFCommunity = false;
        setLoggedUserData(() => response.data.user);
        console.log(response.data.user);

        if (!response.data.user.isVerified) {
          setOpenUserDetailsForm(true);
          return;
        } else if (communityDetails) {
          communityDetails?.approvedMembers.map((member) => {
            if (member.userId._id === response.data.user._id) {
              checkUserPartOFCommunity = true;
            }
          });
          communityDetails?.pendingMembers?.map((member) => {
            if (member.userId._id === response.data.user._id) {
              checkUserPartOFCommunity = true;
            }
          });
        }
        console.log(checkUserPartOFCommunity);

        if (checkUserPartOFCommunity) {
          reset();
          setIsJoinCommunityOpen(false);
        } else {
          console.log("its not part of community so create new member");
          if (communityDetails?.isApplicationRequire) {
            setIsAdditionDetailsReq(true);
            setIsJoinCommunityOpen(true);
          } else {
            await onSubmitUser({
              email: response.data.user.email,
              fullName: response.data.user.fullName,
              phoneNumber: response.data.user.phoneNumber,
            });
          }
        }
      }
    } catch (error: any) {
      console.error(error);
      const errorMessage =
        error.response?.data?.message || "Error while OTP verification";
      toast(errorMessage, {
        icon: "❌",
        style: { backgroundColor: "#454545", color: "white" },
      });
    }
  };

  const onSubmit: SubmitHandler<FormValues> = async (data) => {
    try {
      setLoading(true);
      if (!isOTPSend) {
        const response = await axios.get(
          `/api/users/check-email/${data.email.toString().trim()}`
        );
        if (response.data) {
          await sentOtp();
        }
      } else {
        await checkOtp();
      }
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const createMember = async (userId: string) => {
    try {
      const res = await axios.post("/api/member", {
        userId,
      });
      console.log(res.data);
      return res.data.newMember;
    } catch (error) {
      console.log(error);
    }
  };
  const onSubmitUser: SubmitHandler<userFields> = async (data) => {
    try {
      setLoading(true);

      const response = await axios.post("/api/users", {
        email: data.email || watch("email"),
        fullName: data.fullName,
        phoneNumber: data.phoneNumber,
      });

      if (response.status === 200) {
        console.log(response.data);
        if (communityDetails?.isApplicationRequire) {
          setOpenUserDetailsForm(false);
          setIsAdditionDetailsReq(true);
          return;
        }
        const newMember = await createMember(response.data.savedUser._id);
        setLoggedUserData(() => response.data.savedUser);

        if (communityDetails?.isAutoApproveMembership) {
          await updateMembership(
            true,
            false,
            newMember._id,
            response.data.savedUser._id
          );
        } else {
          await updateMembership(
            false,
            false,
            newMember._id,
            response.data.savedUser._id
          );
        }
        setIsJoinCommunityOpen(false);
        setOpenUserDetailsForm(false);
      }
      console.log(response.status);
    } catch (error: any) {
      console.log(error);
      const errorMessage =
        error.response?.data?.message || "An error occurred. Please try again.";
      toast(errorMessage, {
        icon: "❌",
        style: {
          backgroundColor: "#454545",
          color: "white",
        },
      });

      // Reset the phone number field
      setUser("phoneNumber", "+91 ");
    } finally {
      setLoading(false);
    }
  };

  const updateMembership = async (
    isApprovedMember: boolean,
    isRejectedMember: boolean,
    newMemberId: string,
    userId: string
  ) => {
    try {
      console.log(communityDetails, newMemberId);
      console.log(isApprovedMember, isRejectedMember);

      const response = await axios.post("/api/community/update-membership", {
        communityId: communityDetails?._id,
        memberId: newMemberId,
        userId: userId,
        isApprovedMember,
        isRejectedMember,
        receiverEmail: loggedUserData?.email,
      });
      if (response.data) {
        window.location.reload();
      }
    } catch (error) {
      console.error(error);
    }
  };

  const joinCommunity = async () => {
    if (loggedUserData) {
      await onSubmitUser({
        email: loggedUserData?.email,
        fullName: loggedUserData?.fullName,
        phoneNumber: loggedUserData?.phoneNumber,
      });
    }
  };
  const handleJoinCommunity = () => {
    console.log(loggedUserData);

    if (!loggedUserData) {
      setIsJoinCommunityOpen(true);
    } else {
      console.log(loggedUserData);
      if (!loggedUserData.isVerified) {
        joinCommunity();
      } else {
        if (communityDetails?.isApplicationRequire) {
          setIsJoinCommunityOpen(true);
          setIsAdditionDetailsReq(true);
        } else {
          joinCommunity();
        }
      }
    }
  };
  console.log(loggedUserData);
  console.log(showPendingReqModal);

  const startCountdown = () => {
    setCountdown(30); // 3 minutes in seconds
  };

  useEffect(() => {
    if (countdown > 0) {
      const timer = setTimeout(() => {
        setCountdown(countdown - 1);
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [countdown]);

  const onClose = () => {
    setShowPendingReqModal(false);
  };
  const withDrawRequest = async () => {
    setLoading(true);
    try {
      const res = await axios.post("/api/community/withdraw-request", {
        communityId: communityDetails?._id,
        userId: loggedUserData?._id,
      });
      console.log(res.data);
      if (res.data) {
        toast("Withdraw request from community successfully!", {
          icon: "✅",
          style: { backgroundColor: "#454545", color: "white" },
        });
      }

      setTimeout(() => {
        window.location.reload();
      }, 1500);
    } catch (error: any) {
      console.error(error);
      const errorMessage =
        error.response?.data?.message || "Error while withdraw request";
      toast(errorMessage, {
        icon: "❌",
        style: { backgroundColor: "#454545", color: "white" },
      });
    } finally {
      setLoading(false);
    }
  };
  console.log(loggedUserData);

  const groupRecordsByMonthAndYear = (
    records: RecordType[]
  ): [string, RecordType[]][] => {
    const grouped: GroupedRecords = records.reduce((acc, record) => {
      const date = new Date(record.createDate);
      const monthYear = `${date.toLocaleString("default", {
        month: "long",
      })} ${date.getFullYear()}`;

      if (!acc[monthYear]) {
        acc[monthYear] = [];
      }
      acc[monthYear].push(record);
      return acc;
    }, {} as GroupedRecords);

    // Sort the grouped records by monthYear in descending order (latest first)
    const sortedGroupedEntries = Object.entries(grouped).sort(([a], [b]) => {
      const [aMonth, aYear] = a.split(" ");
      const [bMonth, bYear] = b.split(" ");

      const dateA = new Date(`${aMonth} 1, ${aYear}`);
      const dateB = new Date(`${bMonth} 1, ${bYear}`);

      return dateB.getTime() - dateA.getTime();
    });

    return sortedGroupedEntries;
  };

  useEffect(() => {
    if (isJoinCommunityFormOpen || showPendingReqModal || selectedRecord) {
      document.body.classList.add("no-scroll");
    } else {
      document.body.classList.remove("no-scroll");
    }
  }, [isJoinCommunityFormOpen, showPendingReqModal, selectedRecord]);
  console.log(showRecords);
  console.log(selectedContentType);

  return (
    <Suspense>
      {communityDetails && (
        <>
          <Head>
            <link rel="icon" href={communityDetails.logoImage} />
          </Head>
          <div
            className={`bg-white-bg   desktopView w-screen relative min-h-screen ${
              isJoinCommunityFormOpen && " h-screen overflow-clip "
            }`}
          >
            <Navbar
              loggedUser={loggedUserData}
              communityId={communityDetails?._id}
              community={communityDetails}
              handleJoinCommunity={handleJoinCommunity}
            />
            {!showRecords && (
              <div className="w-full flex justify-start xs:justify-center items-center gap-3 my-5 overflow-x-auto whitespace-nowrap px-8 xs:px-0">
                <button
                  type="button"
                  onClick={() => setActiveTab("home")}
                  className={`text-primaryBlack text-base px-2 ${
                    activeTab === "home" ? "border-b-2 border-primaryBlack" : ""
                  }`}
                >
                  Home
                </button>
                {(loggedUserData?.communityStatus === "Member" ||
                  loggedUserData?.communityStatus === "Host") &&
                  communityDetails.whatsUpGroupLink && (
                    <button
                      type="button"
                      onClick={() => setActiveTab("chat")}
                      className={`text-primaryBlack text-base px-2 ${
                        activeTab === "chat"
                          ? "border-b-2 border-primaryBlack"
                          : ""
                      }`}
                    >
                      Chat
                    </button>
                  )}
                <button
                  type="button"
                  onClick={() => setActiveTab("members")}
                  className={`text-primaryBlack text-base px-2 ${
                    activeTab === "members"
                      ? "border-b-2 border-primaryBlack"
                      : ""
                  }`}
                >
                  Members
                </button>
                {communityDetails.description && (
                  <button
                    type="button"
                    onClick={() => setActiveTab("about")}
                    className={`text-primaryBlack text-base px-2 ${
                      activeTab === "about"
                        ? "border-b-2 border-primaryBlack"
                        : ""
                    }`}
                  >
                    About
                  </button>
                )}
                {(loggedUserData?.communityStatus === "Member" ||
                  loggedUserData?.communityStatus === "Host") &&
                  communityDetails.contentTypes.length > 0 && (
                    <button
                      type="button"
                      onClick={() => setActiveTab("contentType")}
                      className={`text-primaryBlack text-base px-2 ${
                        activeTab === "contentType"
                          ? "border-b-2 border-primaryBlack"
                          : ""
                      }`}
                    >
                      Content Forms
                    </button>
                  )}
              </div>
            )}

            <section className="min-h-[70vh]">
              {activeTab === "home" && !showRecords && (
                <AboutCommunity
                  communityDetails={communityDetails}
                  Members={communityDetails.approvedMembers.length}
                  communityHostName={communityDetails.hostName || "temp"}
                  communityLogo={communityDetails.logoImage}
                  coverImage={communityDetails.coverImage}
                  isAutoApproveMembership={
                    communityDetails.isAutoApproveMembership
                  }
                  title={communityDetails.title}
                  loggedUserData={loggedUserData}
                  handleJoinCommunity={handleJoinCommunity}
                  withDrawRequest={withDrawRequest}
                  setIsJoinCommunityOpen={setIsJoinCommunityOpen}
                  loading={loading}
                />
              )}

              {activeTab === "members" && !showRecords && (
                <div className=" w-full   flex flex-col justify-start items-center  pt-10 px-8 drop-shadow-2xl">
                  {loggedUserData?.communityStatus === "Pending" ||
                  loggedUserData?.communityStatus === "New" ||
                  !loggedUserData ? (
                    <div className="rounded-3xl w-full bg-white py-5 px-8 space-y-3">
                      <div className="space-y-3 ">
                        <div className="flex justify-between items-center gap-2">
                          <div className=" bg-gray-100    rounded-full w-10 h-10 flex justify-center items-center">
                            <Image
                              src={"/assets/icons/demo_profile.png"}
                              alt="demo_profile_icon"
                              width={20}
                              height={20}
                              className=""
                            />
                          </div>
                          <div className="basis-[90%] h-5 bg-gray-100    rounded-md"></div>
                        </div>
                        <div className="flex justify-between items-center gap-2">
                          <div className=" bg-gray-100    rounded-full w-10 h-10 flex justify-center items-center">
                            <Image
                              src={"/assets/icons/demo_profile.png"}
                              alt="demo_profile_icon"
                              width={20}
                              height={20}
                              className=""
                            />
                          </div>
                          <div className="basis-[90%] h-5 bg-gray-100   rounded-md"></div>
                        </div>
                        <div className="flex justify-between items-center gap-2">
                          <div className=" bg-gray-100   rounded-full w-10 h-10 flex justify-center items-center">
                            <Image
                              src={"/assets/icons/demo_profile.png"}
                              alt="demo_profile_icon"
                              width={20}
                              height={20}
                              className=""
                            />
                          </div>
                          <div className="basis-[90%] h-5 bg-gray-100    rounded-md"></div>
                        </div>
                      </div>
                      <div className="text-center w-full">
                        <div className="flex justify-center items-center gap-1 ">
                          <div>
                            <Image
                              src={"/assets/icons/padlock.png"}
                              alt="lock_icon"
                              className=""
                              width={20}
                              height={20}
                            />
                          </div>
                          <p className="text-primaryBlack ">Locked</p>
                        </div>
                      </div>
                      <h2 className="text-primaryBlack  text-xl  text-center">
                        Join to view Members List
                      </h2>
                      <div className="mt-5">
                        {loggedUserData?.communityStatus !== "Pending" ? (
                          <button
                            className="primaryButton"
                            type="button"
                            onClick={handleJoinCommunity}
                          >
                            Join Community
                          </button>
                        ) : (
                          <>
                            <button
                              type="button"
                              onClick={withDrawRequest}
                              disabled={loading}
                              className="primaryButton text-center"
                            >
                              {loading
                                ? "Requesting for withdraw"
                                : "Withdraw request"}
                            </button>
                            <p className="text-primaryBlack  text-sm mt-2 text-center">
                              💁🏻‍♂️ We will let you know when your application is
                              approved.
                            </p>
                          </>
                        )}
                      </div>
                    </div>
                  ) : (
                    <div className="w-full space-y-3 bg-white  py-5 px-8 rounded-3xl">
                      <p className="text-primaryBlack  text-left w-full text-lg">
                        {communityDetails.approvedMembers?.length?.toString() +
                          (communityDetails.approvedMembers.length === 1
                            ? " Member"
                            : " Members")}
                      </p>
                      {communityDetails.approvedMembers.map((member) => (
                        <div
                          key={member._id}
                          className="flex justify-start items-center gap-3 w-full text-primaryBlack  pb-5"
                        >
                          <div className="w-16 h-16 rounded-full overflow-hidden">
                            <Image
                              src={
                                member.userId?.avatar ||
                                "/assets/icons/demo_profile.png"
                              }
                              alt="member_logo"
                              width={80}
                              height={80}
                              className="object-cover w-full h-full"
                            />
                          </div>
                          <div>
                            <p className="">{member.userId?.fullName}</p>
                            <p
                              className={`${
                                communityDetails.host === member._id
                                  ? "bg-purple-200  "
                                  : "bg-yellow-200  "
                              } text-center rounded text-xs text-white p-0 w-[100px]`}
                            >
                              {communityDetails.host === member._id
                                ? "Host"
                                : "Member"}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
              {activeTab === "chat" && !showRecords && (
                <div className="rounded-md bg-white shadow-md flex  justify-between items-start m-7 p-5 gap-3">
                  <Link
                    href={communityDetails.whatsUpGroupLink}
                    target="_blank"
                    className=" flex justify-center items-center w-20 h-20 rounded-md shadow bg-white-bg"
                  >
                    <Image
                      src="/assets/icons/whatsapp_icon.png"
                      alt="WhatsApp Icon"
                      width={40}
                      height={40}
                    />
                  </Link>
                  <div className="flex-1">
                    <p className="text-lg font-semibold">
                      Tab to join the community chat.
                    </p>

                    <button
                      onClick={() => {
                        const shareUrl = `${communityDetails.whatsUpGroupLink}`;
                        if (navigator.share) {
                          navigator.share({
                            title: communityDetails?.title,
                            text: "Check out this community!",
                            url: shareUrl,
                          });
                        } else {
                          navigator.clipboard
                            .writeText(shareUrl)
                            .catch((err) => console.error(err));
                        }
                      }}
                      className="bg-black py-1 px-3 hover:bg-opacity-80 text-sm mt-2 rounded text-white "
                    >
                      Share
                    </button>
                  </div>
                </div>
              )}
              {activeTab === "about" && !showRecords && (
                <div className="w-full">
                  <div className="w-full h-[250px] md:h-[300px]  relative">
                    <Image
                      src={communityDetails.coverImage}
                      alt="cover-image"
                      width={4080}
                      height={200}
                      className="object-cover object-center w-full h-full"
                    />
                    <div className="absolute -bottom-[20%] left-1/2 transform w-20 h-20 -translate-x-1/2 border-[7px] border-white rounded-2xl">
                      <Image
                        src={communityDetails.logoImage}
                        alt="community-logo"
                        width={100}
                        height={100}
                        className="w-full h-full rounded-lg bg-white object-cover"
                      />
                    </div>
                  </div>
                  <div className=" flex flex-col justify-between items-start bg-white   px-8 pb-5 gap-3">
                    <div className="w-full pt-20">
                      <h1 className="text-4xl text-primaryBlack  font-semibold w-full text-center">
                        {communityDetails.title}
                      </h1>
                      <p className=" text-primaryBlack  font-light text-base text-center">
                        by {communityDetails.hostName}
                      </p>
                    </div>
                    <h3 className="text-2xl font-medium leading-6">About</h3>
                    <p className="text-primaryBlack text-base ">
                      {communityDetails.description}
                    </p>
                  </div>
                </div>
              )}
              {activeTab === "contentType" && !showRecords && (
                <div className=" w-full  pt-10 px-8 drop-shadow-2xl">
                  <div className="w-full space-y-3 bg-white  py-5 px-8 rounded-3xl">
                    <p className="text-primaryBlack  text-left w-full text-lg">
                      {communityDetails.contentTypes.length} Content form(s)
                    </p>
                    {communityDetails &&
                    communityDetails.contentTypes &&
                    communityDetails.contentTypes.length > 0 ? (
                      communityDetails.contentTypes.map(
                        (contentType: ContentType) => (
                          <div
                            key={contentType._id}
                            className="flex justify-between gap-2 md:my-4 md:px-8"
                          >
                            <div
                              onClick={() => {
                                setShowRecords(true);
                                setSelectedContentType(contentType);
                              }}
                              className="flex cursor-pointer flex-1 bg-slate-100 px-4 py-4 rounded-md justify-between items-center"
                            >
                              <div>
                                {contentType.title} (
                                {contentType.records.length})
                              </div>
                              <div className="flex items-center gap-2">
                                {/* Toggle Active/Inactive Button */}
                              </div>
                            </div>
                            {/* add todo : is member having record then dont show the + button */}
                            <Link
                              href={`/content-form/${communityDetails._id}/${contentType._id}`}
                              target="_blank"
                              className="w-14 bg-slate-100 text-xl flex justify-center items-center rounded-md"
                            >
                              <p>+</p>
                            </Link>
                          </div>
                        )
                      )
                    ) : (
                      <div className="flex justify-center items-center w-full h-full">
                        <h2 className="text-center">
                          There are no Content Types
                        </h2>
                      </div>
                    )}
                  </div>
                </div>
              )}
              {isJoinCommunityFormOpen && !showRecords && (
                <div
                  className={`fixed inset-0 text-primaryBlack left-0 right-0 bg-white desktopView   bg-opacity-80 z-[500] flex justify-center items-end transition-transform duration-500  ${
                    isJoinCommunityFormOpen
                      ? "translate-y-0"
                      : "translate-y-full"
                  }`}
                  onClick={() => setIsJoinCommunityOpen(false)}
                >
                  <button
                    type="button"
                    onClick={() => setIsJoinCommunityOpen(false)}
                    className="text-primaryBlack  absolute top-10 right-10 text-lg z-[501] border p-1 border-primaryBlack rounded-full w-5 h-5 flex justify-center items-center "
                  >
                    <p>&times;</p>
                  </button>
                  {!loggedUserData && (
                    <div
                      className="bg-white w-full    p-4 rounded-t-3xl relative border"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <h2 className="text-xl w-full font-semibold text-center absolute left-0 right-0 -top-12 ">
                        Join this community
                      </h2>
                      <form
                        onSubmit={handleSubmit(onSubmit)}
                        className="flex flex-col justify-between items-center gap-2"
                      >
                        <div className="w-16 h-16 overflow-hidden rounded-lg">
                          <Image
                            src={communityDetails.logoImage}
                            alt="logo"
                            width={50}
                            height={50}
                            className="h-full w-full object-cover"
                          />
                        </div>
                        <h3 className="font-semibold text-2xl">
                          {communityDetails.title}
                        </h3>
                        <p className="text-gray-500 text-sm">
                          {communityDetails.approvedMembers.length} Member(s)
                        </p>
                        {!isOTPSend && (
                          <div className="flex flex-col justify-between items-start gap-2 w-full">
                            <input
                              type="email"
                              placeholder="Your email address"
                              {...register("email", {
                                required: "Email is required",
                                pattern: {
                                  value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
                                  message: "Invalid email address",
                                },
                              })}
                              className="create-community-input"
                            />
                            {errors.email && (
                              <span className="text-red-500 text-sm text-sm">
                                {errors.email.message}
                              </span>
                            )}
                          </div>
                        )}

                        {isOTPSend && (
                          <div className="flex flex-col justify-between items-center gap-2 w-full mb-5">
                            {/* <input
                            type="email"
                            placeholder="Your email address"
                            {...register("email", {
                              required: "Email is required",
                              pattern: {
                                value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
                                message: "Invalid email address",
                              },
                            })}
                            readOnly={true}
                            className="w-full bg-gray-100 mt-1 border-gray-400 border-[1px] text-base rounded-lg placeholder:text-gray-600 font-light focus:border-primaryBlack  outline-none text-primaryBlack  p-2 read-only:bg-[#D3D0D0] read-only:bg-opacity-50"
                          /> */}
                            <div className="relative w-full">
                              <input
                                type="email"
                                {...register("email", {
                                  required: "Email is required",
                                  pattern: {
                                    value:
                                      /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/,
                                    message: "Invalid email address",
                                  },
                                })}
                                placeholder="johndoe@gmail.com"
                                readOnly={true}
                                className="create-community-input read-only:bg-gray-200"
                              />

                              <button
                                type="button"
                                className="absolute right-2 top-[60%] transform -translate-y-1/2 "
                                onClick={() => {
                                  setLoading(false);
                                  setIsOTPsend(false);
                                  setCountdown(-1);
                                  reset();
                                }}
                              >
                                <Image
                                  src={"/assets/icons/edit-button.svg"}
                                  alt="edit"
                                  width={20}
                                  height={20}
                                />
                              </button>
                            </div>
                            <input
                              type="text"
                              {...register("otp", {
                                required:
                                  "Enter 6 digit OTP sent on your email.",
                                validate: {
                                  isNumeric: (value) =>
                                    /^\d*$/.test(value) ||
                                    "OTP must contain only digits",
                                  isValidLength: (value) =>
                                    value.length === 0 ||
                                    value.length === 6 ||
                                    "OTP must be exactly 6 characters long",
                                },
                              })}
                              onInput={(e: any) => {
                                e.target.value = e.target.value
                                  .replace(/[^0-9]/g, "")
                                  .slice(0, 6);
                              }}
                              placeholder="Enter your OTP"
                              className="create-community-input"
                            />
                            {errors.otp && (
                              <span className="text-red-500 text-sm text-left w-full">
                                {errors.otp.message}
                              </span>
                            )}
                          </div>
                        )}

                        <button
                          type="submit"
                          disabled={
                            loading ||
                            (!isOTPSend
                              ? !watch("email") || !!errors.email
                              : !watch("otp") || !!errors.otp)
                          }
                          className="bg-primaryBlack  mb-3 disabled:bg-opacity-50 text-white px-2 py-3 font-light rounded-xl w-full mt-3"
                        >
                          {loading
                            ? "Sending OTP"
                            : isOTPSend
                            ? "Verify OTP"
                            : "Send OTP"}
                        </button>
                        <button
                          type="button"
                          className="underline text-primaryBlack  text-center w-full mx-auto pb-10"
                          onClick={() => {
                            setValue("otp", "");
                            sentOtp();
                          }}
                          disabled={countdown > 0}
                          style={{ whiteSpace: "nowrap" }}
                        >
                          {countdown > 0
                            ? `Didn’t received the OTP? Retry in ${String(
                                Math.floor(countdown / 60)
                              ).padStart(2, "0")}:${String(
                                countdown % 60
                              ).padStart(2, "0")}`
                            : countdown !== -1 && "Resend OTP"}
                        </button>
                        {isOTPSend && (
                          <button
                            type="button"
                            onClick={() => {
                              setLoading(false);
                              setIsOTPsend(false);
                              setCountdown(-1);
                              reset();
                            }}
                            className="secondaryButton"
                          >
                            {" "}
                            Back
                          </button>
                        )}
                      </form>
                    </div>
                  )}
                  {loggedUserData && openUserDetailsForm && (
                    <div
                      className="bg-white w-full   p-4 rounded-t-3xl relative border overflow-y-scroll "
                      onClick={(e) => e.stopPropagation()}
                    >
                      <form
                        onSubmit={handleSubmitUser(onSubmitUser)}
                        className="flex flex-col justify-between items-center gap-2 "
                      >
                        <Image
                          src={communityDetails.logoImage}
                          alt="logo"
                          width={50}
                          height={50}
                          className="rounded-lg object-cover"
                        />
                        <h3 className="font-semibold text-2xl">
                          {communityDetails.title}
                        </h3>
                        <p className="text-gray-500 text-sm">
                          {communityDetails.approvedMembers.length} Members
                        </p>
                        <div className="w-full">
                          <label htmlFor="fullName" className="form-lebel">
                            Full Name*
                          </label>
                          <input
                            type="text"
                            {...registerUser("fullName", {
                              required: "Full name is required",
                              pattern: {
                                value: /^[a-zA-Z\s]*$/,
                                message:
                                  "Full name must only contain letters and spaces.",
                              },
                              validate: {
                                noSpecialChars: (value) =>
                                  /^[^\u00C0-\uFFFF]*$/.test(value) ||
                                  "Full name must not contain special characters or emojis.",
                              },
                            })}
                            placeholder="John Doe"
                            className="create-community-input"
                            onInput={(
                              e: React.ChangeEvent<HTMLInputElement>
                            ) => {
                              e.target.value = e.target.value
                                .replace(/[^a-zA-Z\s]/g, "") // Remove non-letter and non-space characters
                                .replace(/\b\w/g, (char) => char.toUpperCase()); // Capitalize the first letter of each word
                            }}
                          />
                          {userErrors.fullName && (
                            <p className="text-red-500 text-sm">
                              {userErrors.fullName.message}
                            </p>
                          )}
                        </div>
                        <div className="w-full">
                          <label htmlFor="phoneNumber" className="form-lebel">
                            Mobile Number (WhatsApp)*
                          </label>
                          <input
                            type="tel"
                            {...registerUser("phoneNumber", {
                              required: "Mobile Number (WhatsApp) is required",
                              pattern: {
                                value: /^\+91 \d{10}$/,
                                message:
                                  "Mobile Number (WhatsApp) must be exactly 10 digits",
                              },
                            })}
                            defaultValue="+91 "
                            className="create-community-input outline-none w-full pl-14"
                            onInput={(
                              e: React.ChangeEvent<HTMLInputElement>
                            ) => {
                              if (!e.target.value.startsWith("+91 ")) {
                                e.target.value = "+91 ";
                              } else {
                                const digits = e.target.value
                                  .slice(4)
                                  .replace(/[^\d]/g, "");

                                // Limit the digits to 10 characters
                                const limitedDigits = digits.slice(0, 10);

                                // Set the value back to the input field
                                e.target.value = "+91 " + limitedDigits;
                              }
                            }}
                            placeholder="1234567890"
                          />
                          {userErrors.phoneNumber && (
                            <p className="text-red-500 text-sm">
                              {userErrors.phoneNumber.message}
                            </p>
                          )}
                        </div>
                        <button
                          type="submit"
                          disabled={!isUserValid || loading}
                          className="bg-primaryBlack  disabled:bg-opacity-50 text-white px-2 py-3 font-light rounded-xl w-full mt-3"
                        >
                          {loading ? "Loading" : "Create Account"}
                        </button>
                      </form>
                    </div>
                  )}
                  {loggedUserData && isAdditionDetailsReq && (
                    <AdditionalDetailsForm
                      communityDetails={communityDetails}
                      loggedUserData={loggedUserData}
                    />
                  )}
                </div>
              )}
              {showPendingReqModal && !showRecords && (
                <Modal
                  isOpen={showPendingReqModal}
                  onClose={onClose}
                  width={"90"}
                  isCloseRequire={false}
                >
                  <div className="flex flex-col justify-center items-center text-center p-5 md:p-10">
                    <div className="w-12 h-12 md:w-16 md:h-16 flex items-center justify-center mb-4">
                      <Image
                        src="/assets/icons/hourglass.png"
                        alt="Hourglass Icon"
                        width={48}
                        height={48}
                      />
                    </div>
                    <h2 className="text-xl md:text-2xl font-semibold mb-2">
                      Your membership is pending approval!
                    </h2>
                    <p className="text-gray-600 mb-5 flex items-center justify-center text-left sm:text-center sm:text-nowrap gap-2 w-[80%] text-sm sm:text-base ">
                      <Image
                        src="/assets/icons/mail.png"
                        alt="Email Icon"
                        width={24}
                        height={24}
                        className="mr-2"
                      />
                      You will be notified via email upon approval.
                    </p>
                    <div className="w-[30%] mx-auto">
                      <button onClick={onClose} className="primaryButton">
                        Got it
                      </button>
                    </div>
                  </div>
                </Modal>
              )}
              {showRecords && selectedContentType && (
                <section className="bg-slate-100 overflow-x-hidden desktopView relative min-h-screen p-4">
                  <div className="flex  justify-between items-center mb-4 gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedContentType(null);
                        setShowRecords(false);
                      }}
                      className="px-3 py-2 text-sm bg-primaryBlack text-white rounded"
                    >
                      &lt; Back
                    </button>

                    <Select
                      isMulti
                      value={selectedTags}
                      onChange={(selected) => setSelectedTags(selected)}
                      options={tags}
                      className="flex-1 focus:outline-none outline-none w-full text-sm placeholder:text-[#767676]"
                      placeholder="Filter Records by tags"
                      styles={{
                        control: (base, state) => ({
                          ...base,
                          borderWidth: 0,
                          border: "none",
                          boxShadow: "none",
                        }),
                        container: (base) => ({
                          ...base,
                          backgroundColor: "white",
                          border: "1px solid #d1d5db",
                          borderRadius: "0.375rem",
                          padding: "6px",
                        }),
                        placeholder: (base) => ({
                          ...base,
                          color: "#767676",
                        }),
                      }}
                    />
                  </div>
                  <div className="flex flex-wrap items-center justify-center gap-4 mb-6">
                    <input
                      type="text"
                      value={textFilter}
                      onChange={(e) => setTextFilter(e.target.value)}
                      placeholder="Filter Records by text"
                      className="flex-grow min-w-[180px] w-full py-4 px-4 border-[#E9E9E9] border-[1px] rounded-lg text-sm placeholder:text-[#767676] placeholder:text-sm outline-none focus:border-primaryBlack font-normal text-primaryBlack leading-5"
                    />
                  </div>

                  <div className="flex flex-wrap items-center justify-center gap-4 mb-6">
                    <select
                      value={selectedMonth || dateFilter || ""}
                      onChange={(e) => {
                        const value = e.target.value;
                        if (
                          [
                            "today",
                            "yesterday",
                            "last7days",
                            "last30days",
                          ].includes(value)
                        ) {
                          setDateFilter(value);
                          setSelectedMonth(null);
                        } else {
                          setDateFilter("month");
                          setSelectedMonth(value);
                        }
                      }}
                      className="flex-grow min-w-[180px] w-full py-4 px-4 border-[#E9E9E9] border-[1px] rounded-lg text-sm  placeholder:text-[#767676] placeholder:text-sm outline-none focus:border-primaryBlack  font-normal text-primaryBlack leading-5"
                    >
                      <option value="">Filter Records by date</option>
                      <option value="today">Today</option>
                      <option value="yesterday">Yesterday</option>
                      <option value="last7days">Last 7 Days</option>
                      <option value="last30days">Last 30 Days</option>
                    </select>
                  </div>
                  <div className="flex flex-col xs:flex-row justify-between items-center mb-10 gap-5">
                    <div className="flex items-center ">
                      <span
                        className={`px-4 py-2 text-xs md:text-sm rounded-l-md cursor-pointer ${
                          isListView
                            ? "bg-primaryBlack text-white"
                            : "bg-white text-black"
                        }`}
                        onClick={() => setIsListView(true)}
                      >
                        List View
                      </span>
                      <span
                        className={`px-4 py-2 text-xs md:text-sm rounded-r-md cursor-pointer ${
                          !isListView
                            ? "bg-primaryBlack text-white"
                            : "bg-white text-black"
                        }`}
                        onClick={() => setIsListView(false)}
                      >
                        Record View
                      </span>
                    </div>
                    <div
                      className="w-[70%] sm:w-[40%] cursor-pointer"
                      onClick={copyToClipboard}
                    >
                      <div className="text-gray-500 flex justify-center  text-sm md:text-base items-center gap-1 px-3 py-2 rounded-3xl  ">
                        <p className="text-nowrap">Tab to Copy Link</p>
                        <FaCopy />
                      </div>
                    </div>
                  </div>
                  {isListView ? (
                    <div className="space-y-4">
                      {filteredRecords.length > 0 ? (
                        groupRecordsByMonthAndYear(filteredRecords).map(
                          ([monthYear, records]) => (
                            <div key={monthYear}>
                              <h2 className="text-lg font-semibold mb-2">
                                {monthYear}
                              </h2>
                              {records.map((record) => {
                                let linkCounter = 1;
                                return (
                                  <div
                                    key={record._id}
                                    className="border p-4 rounded-md shadow-md bg-white mb-5"
                                  >
                                    {record.memberDetails ? (
                                      <div className="flex items-center mb-4">
                                        <Image
                                          width={20}
                                          height={20}
                                          src={
                                            record.memberDetails.userId.avatar
                                          }
                                          alt="Member Avatar"
                                          className="w-12 h-12 rounded-full mr-4"
                                        />
                                        <div>
                                          <p className="text-lg font-medium text-gray-700">
                                            {
                                              record.memberDetails.userId
                                                .fullName
                                            }
                                          </p>
                                          <p className="text-sm text-gray-500">
                                            {record.memberDetails.userId.email}
                                          </p>
                                          <p className="text-sm text-gray-500">
                                            {
                                              record.memberDetails.userId
                                                .phoneNumber
                                            }
                                          </p>
                                        </div>
                                      </div>
                                    ) : (
                                      <p className="mb-4">Deleted Member</p>
                                    )}
                                    <div className="bg-gray-100 p-4 rounded-md shadow-md">
                                      <h2 className="text-lg font-semibold mb-2">
                                        Record Details
                                      </h2>
                                      {Object.entries(record.recordFields).map(
                                        ([question, answer]) => (
                                          <div key={question} className="mb-2">
                                            <p className="font-semibold text-gray-800">
                                              {question}:
                                            </p>
                                            {typeof answer === "string" &&
                                            answer.startsWith("http") ? (
                                              <a
                                                href={answer}
                                                target="_blank"
                                                rel="noopener noreferrer"
                                                className="text-blue-600 underline"
                                              >
                                                {`LINK ${linkCounter++}`}
                                              </a>
                                            ) : (
                                              <p className="text-gray-600">
                                                {answer}
                                              </p>
                                            )}
                                          </div>
                                        )
                                      )}
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          )
                        )
                      ) : (
                        <p className="text-center mt-5">No records found</p>
                      )}
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {filteredRecords.length > 0 ? (
                        groupRecordsByMonthAndYear(filteredRecords).map(
                          ([monthYear, records]) => (
                            <div key={monthYear}>
                              <h2 className="text-lg font-semibold mb-2">
                                {monthYear}
                              </h2>
                              {records.map((record) => {
                                let linkCounter = 1;
                                return (
                                  <div
                                    key={record._id}
                                    onClick={() => {
                                      setSelectedRecord(record);
                                    }}
                                    className="border p-4 rounded-md shadow-md bg-white cursor-pointer mb-5"
                                  >
                                    <p>
                                      Record by{" "}
                                      {record.memberDetails?.userId.fullName ||
                                        "Deleted Member"}
                                    </p>
                                  </div>
                                );
                              })}
                            </div>
                          )
                        )
                      ) : (
                        <p className="text-center mt-5">No records found</p>
                      )}
                    </div>
                  )}

                  {selectedRecord && (
                    <Modal
                      isOpen={!!selectedRecord}
                      width="90"
                      onClose={handleCloseRecordModal}
                    >
                      <div className="p-6 h-[90vh] overflow-x-auto bg-gray-100 rounded-lg no-scrollbar">
                        {/* Member Details */}
                        {selectedRecord.memberDetails ? (
                          <div className="mb-6">
                            <h2 className="text-xl font-semibold mb-4 text-primaryBlack">
                              Member Details
                            </h2>
                            <div className="flex items-center mb-4">
                              <Image
                                width={50}
                                height={50}
                                src={selectedRecord.memberDetails.userId.avatar}
                                alt="Member Avatar"
                                className="w-16 h-16 rounded-full mr-4"
                              />
                              <div>
                                <p className="text-lg font-medium text-gray-700">
                                  {selectedRecord.memberDetails.userId.fullName}
                                </p>
                                <p className="text-sm text-gray-500">
                                  {selectedRecord.memberDetails.userId.email}
                                </p>
                                <p className="text-sm text-gray-500">
                                  {
                                    selectedRecord.memberDetails.userId
                                      .phoneNumber
                                  }
                                </p>
                              </div>
                            </div>
                          </div>
                        ) : (
                          <p className="mb-5">Deleted Member</p>
                        )}

                        {/* Record Fields */}
                        <div>
                          <h2 className="text-xl font-semibold mb-4 text-primaryBlack">
                            Record Details
                          </h2>
                          <div className="space-y-4">
                            {Object.entries(selectedRecord.recordFields).map(
                              ([question, answer]) => {
                                let linkCounter = 1;
                                return (
                                  <div
                                    key={question}
                                    className="p-4 bg-white shadow rounded-md"
                                  >
                                    <p className="font-semibold text-gray-800">
                                      {question}:
                                    </p>
                                    {typeof answer === "string" &&
                                    answer.startsWith("http") ? (
                                      <a
                                        href={answer}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="text-blue-600 underline"
                                      >
                                        {`LINK ${linkCounter++}`}
                                      </a>
                                    ) : (
                                      <p className="text-gray-600">{answer}</p>
                                    )}
                                  </div>
                                );
                              }
                            )}
                          </div>
                        </div>
                      </div>
                    </Modal>
                  )}
                </section>
              )}
            </section>
            <Footer />
          </div>
        </>
      )}

      <Toaster />
    </Suspense>
  );
};

export default CommunityPage;
