"use client";
import { CommunityDetails } from "@/types/communityDetails.types";
import { User } from "@/types/user.types";
import axios from "axios";

import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import React, { Dispatch, SetStateAction } from "react";

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  communityDetails?: CommunityDetails;
  loggedUserData?: User;
  setActivePage: Dispatch<SetStateAction<string>>;
  activePage: string;
}

const Sidebar: React.FC<SidebarProps> = ({
  isOpen,
  onClose,
  communityDetails,
  setActivePage,
  loggedUserData,
  activePage,
}) => {
  console.log(loggedUserData);
  const router = useRouter();
  const logout = async () => {
    try {
      const response = await axios.delete("/api/users/logout");

      if (response.data) {
        router.push("/login");
      }
    } catch (error) {
      console.error(error);
    }
  };
  return (
    <div
      className={`fixed w-full text-primaryBlack  sm:max-w-[500px] md:max-w-[550px] mx-auto top-0 left-0 h-full bg-white  z-50   transform transition-transform ease-in-out duration-300 ${
        isOpen ? "translate-x-0" : "-translate-x-full"
      }`}
    >
      {loggedUserData && (
        <div className="flex justify-between items-stretch h-full bg-gray-80">
          <div className="w-[20%]  py-10 pt-6 flex flex-col justify-start items-center gap-4 ">
            {/* <div className="w-full bg-white px-1 overflow-y-scroll   flex flex-col justify-start items-center gap-4 "> */}
            {loggedUserData?.communityDetails.map((community) => {
              if (community.role === "Host") {
                return (
                  <Link
                    href={`/portal/home/${community.communityId}`}
                    key={community._id}
                    className={`${
                      community.communityId === communityDetails?._id &&
                      " bg-blue-200 rounded "
                    } p-3 w-20 h-20`}
                  >
                    {/* todo:add community logo here */}
                    <Image
                      src={community.logoImage}
                      alt="community-log"
                      width={80}
                      height={80}
                      className="rounded-md w-full h-full object-cover"
                    />
                  </Link>
                );
              }
            })}
            <Link href={`/start-community`} className={` px-3 py-1 mt-auto `}>
              {/* todo:add community logo here */}
              <Image
                src={"/assets/icons/add.png"}
                alt="community-log"
                width={50}
                height={50}
                className="rounded-md"
              />
            </Link>
            {/* </div> */}
          </div>
          <div className="m-1 flex-1 bg-white rounded-2xl shadow-2xl flex flex-col justify-between items-center px-5 py-10 my-6 relative">
            <button
              className="text-white focus:outline-none absolute right-4 top-4"
              onClick={onClose}
              aria-label="Close sidebar"
            >
              <svg
                className="w-5 h-5 text-primaryBlack"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M6 18L18 6M6 6l12 12"
                />
              </svg>
            </button>

            <div className="w-full">
              <div className="w-full">
                <h2 className="text-primaryBlack font-semibold text-xl">
                  {communityDetails?.title}
                </h2>
                <span className="bg-gray-100 font-light px-2 py-[0.1rem] text-sm text-gray-800">
                  Host
                </span>
              </div>
              <div className="w-full mt-10">
                <button
                  className={`w-full flex rounded justify-start items-center gap-5 px-3 py-1 bg-${
                    activePage === "Home" ? "gray-100" : ""
                  }`}
                  onClick={() => {
                    if (activePage === "Home") {
                      onClose();
                    } else {
                      router.push(`/portal/home/${communityDetails?._id}`);
                    }
                  }}
                >
                  <Image
                    src={"/assets/icons/home_icon.png"}
                    alt="logo"
                    width={20}
                    height={20}
                  />
                  <p>Community Home</p>
                </button>
                <hr className="h-[0.5px] border border-gray-600 my-5" />
                <div className="">
                  <p className="text-xs text-gray-700 font-light">MANAGE</p>
                  <div className="mt-5 space-y-5">
                    <button
                      type="button"
                      className={`w-full flex rounded justify-start items-center gap-5 px-3 py-1 bg-${
                        activePage === "Members" ? "gray-100" : ""
                      }`}
                      onClick={() => {
                        if (activePage === "Members") {
                          onClose();
                        } else {
                          router.push(
                            `/portal/members/${communityDetails?._id}?tab=members`
                          );
                        }
                      }}
                    >
                      <Image
                        src={"/assets/icons/members.png"}
                        alt="logo"
                        width={20}
                        height={20}
                      />
                      <p>Members</p>
                    </button>
                    <button
                      type="button"
                      className={`w-full rounded flex justify-start items-center gap-5 px-3 py-1 bg-${
                        activePage === "Settings" ? "gray-100" : ""
                      }`}
                      onClick={() => {
                        if (activePage === "Settings") {
                          onClose();
                        } else {
                          router.push(
                            `/portal/settings/${communityDetails?._id}?tab=public_page`
                          );
                        }
                      }}
                    >
                      <Image
                        src={"/assets/icons/settings_icon.png"}
                        alt="logo"
                        width={20}
                        height={20}
                      />
                      <p>Settings</p>
                    </button>
                    <button
                      type="button"
                      className={`w-full rounded flex justify-start items-center gap-5 px-3 py-1 bg-${
                        activePage === "Contents" ? "gray-100" : ""
                      }`}
                      onClick={() => {
                        if (activePage === "Contents") {
                          onClose();
                        } else {
                          router.push(
                            `/portal/contents/${communityDetails?._id}`
                          );
                        }
                      }}
                    >
                      <Image
                        src={"/assets/icons/content.png"}
                        alt="logo"
                        width={20}
                        height={20}
                      />
                      <p>Contents</p>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Sidebar;
