import { CommunityDetails } from "@/types/communityDetails.types";
import { CommunityStatus, User } from "@/types/user.types";
import axios from "axios";
import { useRouter } from "next/navigation";
import React, { ReactNode, useEffect, useReducer, useState } from "react";

type Props = {
  communityId: string;
  children: ReactNode;
};

type ChildProps = {
  communityDetails?: CommunityDetails;
  loggedUserData?: User;
};

const CommunityHost = ({ communityId, children }: Props) => {
  const [communityDetails, setCommunityDetails] = useState<CommunityDetails>();
  const [loggedUserData, setLoggedUserData] = useState<User>();
  const router = useRouter();
  const fetchCommunity = async () => {
    if (communityId) {
      try {
        const response = await axios.get(
          `/api/community/get-by-id/${communityId}`
        );
        if (response.status === 200) {
          console.log(response.data.community);

          setCommunityDetails(response.data.community);
        } else {
          console.log("Unexpected status code:", response.status);
        }
      } catch (error) {
        console.error(error);
        router.push("/not-found");
      }
    }
  };

  const checkTokenValidity = async () => {
    try {
      const response = await axios.get("/api/users/get-community");
      if (response.data) {
        setLoggedUserData(response.data.user);
      }
    } catch (error) {
      console.error(error);
      router.push("/unauthorized");
    }
  };

  useEffect(() => {
    const init = async () => {
      await fetchCommunity();
      await checkTokenValidity();
    };

    init();
  }, [communityId]);

  const checkIsUserHost = (details: CommunityDetails, userData: User) => {
    const userCommunityDetail = userData.communityDetails.find(
      (communityDetail) =>
        communityDetail.communityId === details._id.toString()
    );

    // Check if the user is the host
    return userCommunityDetail?.role === "Host";
  };

  useEffect(() => {
    if (communityDetails && loggedUserData) {
      const isHost = checkIsUserHost(communityDetails, loggedUserData);
      console.log(isHost);

      if (!isHost) {
        router.push("/unauthorized");
      }
    }
  }, [communityDetails, loggedUserData]);
  console.log(loggedUserData);

  return (
    <div>
      {/* Pass communityDetails and loggedUserData as props to children */}
      {React.Children.map(children, (child) =>
        React.isValidElement(child)
          ? React.cloneElement(child, {
              communityDetails,
              loggedUserData,
              setCommunityDetails,
              setLoggedUserData,
            } as ChildProps) // Type assertion to ChildProps
          : child
      )}
    </div>
  );
};

export default CommunityHost;
