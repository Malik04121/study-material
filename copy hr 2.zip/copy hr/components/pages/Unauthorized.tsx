"use client";
import axios from "axios";
import Image from "next/image";
import { useRouter } from "next/navigation";
import React from "react";

const Unauthorized = () => {
  const router = useRouter();
  const logout = async () => {
    try {
      const response = await axios.delete("/api/users/logout");

      if (response.data) {
        router.push("/login");
      }
    } catch (error) {
      console.error(error);
    }
  };
  return (
    <div className="w-screen h-screen  desktopView flex justify-center items-center bg-white ">
      <div className="text-center flex flex-col  p-8 ">
        <Image
          src="/assets/pages/401.jpg"
          alt="Unauthorized"
          width={500}
          height={300}
          className="mx-auto"
        />
        <h1 className="text-4xl font-bold text-gray-800 mt-6">
          Unauthorized Access
        </h1>
        <p className="text-gray-600 mt-4">
          You do not have permission to view this page.
        </p>
        {/* <Link href={"/login"} className="primaryButton"> */}
        <button className="primaryButton " type="button" onClick={logout}>
          Go to Login
        </button>
        {/* </Link> */}
      </div>
    </div>
  );
};

export default Unauthorized;
