"use client";
import { useState } from "react";
import { useForm } from "react-hook-form";
import axios from "axios";
import toast from "react-hot-toast";

interface WhatsAppLinkFormProps {
  communityId: string;
  setCommunityDetails: (details: any) => void;
}

interface FormData {
  whatsAppLink: string;
}

const WhatsAppLinkForm: React.FC<WhatsAppLinkFormProps> = ({
  communityId,
  setCommunityDetails,
}) => {
  const {
    register,
    handleSubmit,
    formState: { errors, isValid },
  } = useForm<FormData>({ mode: "onChange" });
  const [submitting, setSubmitting] = useState<boolean>(false);

  const onSubmit = async (data: FormData) => {
    setSubmitting(true);
    try {
      const response = await axios.post("/api/community/update-whatsapp-link", {
        communityId,
        whatsAppLink: data.whatsAppLink,
      });

      if (response.data.success) {
        setCommunityDetails(response.data.community);
        toast("Community WhatsApp group URL updated successfully!", {
          icon: "✅",
          style: {
            backgroundColor: "white",
            color: "black",
          },
        });
      }
    } catch (error) {
      console.error("Error updating WhatsApp link:", error);
      toast.error("Failed to update WhatsApp group URL.", {
        style: {
          backgroundColor: "white",
          color: "black",
        },
      });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="px-8">
      <h2 className="text-primaryBlack text-lg font-medium w-full">
        Connect an existing WhatsApp Group
      </h2>
      <div className="flex flex-col justify-between items-start gap-5 py-3 w-full">
        <ol className="list-decimal list-inside text-left mb-4 ">
          <li>
            Open <strong>Group info</strong> in your existing group chat.
          </li>
          <li>
            Under <strong>Participants</strong>, select{" "}
            <strong>Invite to Group via Link.</strong>
          </li>
          <li>
            <strong>Copy</strong> the link and <strong>paste</strong> it below.
          </li>
        </ol>
        <hr className="w-full h-[0.5px] border-[1px] border-para" />
        <div className="w-full">
          <div className="w-full">
            <label className="block text-base font-medium text-gray-700">
              Group invite link
            </label>
            <input
              type="text"
              className="create-community-input"
              {...register("whatsAppLink", {
                required: "Group invite link is required",
                pattern: {
                  value: /^https:\/\/chat\.whatsapp\.com\/[A-Za-z0-9]+$/,
                  message: "Please enter a valid WhatsApp group link",
                },
              })}
              placeholder="Insert link here"
            />
            {errors.whatsAppLink && (
              <p className="text-red-500 text-sm text-sm mt-2">
                {errors.whatsAppLink.message}
              </p>
            )}
          </div>
          <div className="w-[50%] min-w-[200px]">
            <button
              type="submit"
              className=" bg-primaryBlack  disabled:bg-[#D3D0D0] text-white px-2 py-3 font-light rounded-xl w-full mt-5"
              disabled={submitting || !isValid}
            >
              {submitting ? "Loading..." : "Continue"}
            </button>
          </div>
        </div>
      </div>
    </form>
  );
};

export default WhatsAppLinkForm;
