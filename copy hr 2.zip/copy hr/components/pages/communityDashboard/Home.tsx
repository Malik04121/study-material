import {
  CommunityDetails,
  MemberDetails,
} from "@/types/communityDetails.types";
import { User } from "@/types/user.types";
import Image from "next/image";
import Link from "next/link";
import React from "react";
import { FaCheckCircle } from "react-icons/fa";

type ChildComponentProps = {
  communityDetails?: CommunityDetails;
  loggedUserData?: User;
};

const Home = ({ communityDetails, loggedUserData }: ChildComponentProps) => {
  const getLast30DaysCount = (members: MemberDetails[]) => {
    const now = new Date();
    const last30Days = new Date(now.setDate(now.getDate() - 30));
    return members.filter((member) => {
      const submittedDate = new Date(member.applicationSubmittedDate);
      return submittedDate >= last30Days;
    }).length;
  };

  const last30DaysApplications = communityDetails
    ? getLast30DaysCount(communityDetails.approvedMembers)
    : 0;

  return (
    <div className="portal-gradient min-h-screen text-primaryBlack p-4">
      {communityDetails && (
        <div className="h-full flex flex-col justify-between items-start gap-5 px-4">
          <Link
            href={`/${communityDetails.publicPageUrl}`}
            target="_blank"
            className="text-white flex justify-start items-center gap-1 px-5  bg-primaryBlack rounded-2xl py-1"
          >
            <p>{communityDetails.publicPageUrl}</p>
            <Image
              src={"/assets/icons/link_icon.png"}
              alt={"link"}
              width={15}
              height={15}
            />
          </Link>
          <div className="w-full bg-white rounded-2xl p-5 shadow-2xl flex flex-col items-start gap-5 ">
            <div className="flex justify-start items-center gap-2 text-base">
              <Image
                src={"/assets/icons/members.png"}
                alt="members"
                width={20}
                height={20}
              />
              <p>Total Member(s)</p>
            </div>
            <p className="text-2xl font-semibold">
              {communityDetails.approvedMembers.length}
            </p>
            <div className="flex justify-start items-center">
              <Image
                src={"/assets/icons/increase.png"}
                alt="increase"
                width={20}
                height={20}
              />
              <p className="text-sm text-gray-700 ml-1">
                {last30DaysApplications} in the last 30 days
              </p>
            </div>
          </div>
          <div className="w-full bg-white rounded-2xl p-6 shadow-2xl flex flex-col items-start gap-5">
            <p className="text-xl font-semibold text-gray-800">
              Thank you for creating a community on the “WA Collab” Platform 🚀.
            </p>
            <p className="text-base text-gray-600 leading-relaxed">
              Our mission is to empower individuals and organizations to
              effortlessly create and manage thriving WhatsApp Groups, Channels
              & Communities, fostering seamless communication, connection, and
              collaboration.
            </p>
            <div className="mt-4 space-y-2">
              <p className="text-base text-gray-600 mb-2">
                Connect your WhatsApp Group / Channel / Community here and begin
                your journey with:
              </p>
              <ul className="list-none text-base text-gray-600 space-y-2">
                <li className="flex items-center">
                  <FaCheckCircle className="flex-shrink-0 mr-2 text-green-500" />
                  <span>Send / Share Invite Link of your community</span>
                </li>
                <li className="flex items-center">
                  <FaCheckCircle className="flex-shrink-0 mr-2 text-green-500" />
                  <span>Manage Members</span>
                </li>
                <li className="flex items-center">
                  <FaCheckCircle className="flex-shrink-0 mr-2 text-green-500" />
                  <span>
                    Manage your WhatsApp Group / Channel / Community page
                  </span>
                </li>
              </ul>
            </div>
            <p className="text-base text-gray-600 my-2">And so on…</p>
          </div>
          <div className="w-full bg-white rounded-2xl p-6 shadow-2xl flex flex-col items-start gap-5">
            {loggedUserData?.communityDetails.some(
              (community) => community.role === "Host"
            ) && (
              <div className="mb-8 w-full">
                <h2 className="text-xl font-semibold mb-4">
                  Your Community(s)
                </h2>
                <div className="flex flex-wrap gap-6">
                  {loggedUserData?.communityDetails.map((community) => {
                    if (community.role === "Host") {
                      return (
                        <Link
                          href={`/portal/home/${community.communityId}`}
                          key={community._id}
                          target="_blank"
                          className="bg-white  p-4 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300 w-full flex flex-row gap-5 items-center"
                        >
                          <div className="w-14 h-14">
                            <Image
                              src={community.logoImage}
                              alt={community.publicPageUrl}
                              width={80}
                              height={80}
                              className="w-full h-full object-cover rounded-md"
                            />
                          </div>
                          <div className="flex-1 overflow-hidden">
                            <p className="text-lg font-medium text-gray-800 truncate">
                              {community.communityTitle}
                            </p>
                            <p className="text-sm text-gray-500">
                              {community.role}
                            </p>
                          </div>
                          <div>
                            <Image
                              src={"/assets/icons/link.svg"}
                              alt="Link icon"
                              width={17}
                              height={17}
                            />
                          </div>
                        </Link>
                      );
                    }
                  })}
                </div>
              </div>
            )}

            <div className="w-full">
              {loggedUserData?.communityDetails.some(
                (community) => community.role !== "Host"
              ) && (
                <>
                  <h2 className="text-xl font-semibold mb-4">
                    Subscribed Community(s)
                  </h2>
                  <div className="flex flex-wrap gap-6">
                    {loggedUserData?.communityDetails.map((community) => {
                      if (community.role !== "Host") {
                        return (
                          <Link
                            href={`/${community.publicPageUrl}`}
                            key={community._id}
                            target="_blank"
                            className="bg-white p-4 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300 w-full flex flex-row gap-5 items-center"
                          >
                            <div className="w-14 h-14">
                              <Image
                                src={community.logoImage}
                                alt={community.communityTitle}
                                width={80}
                                height={80}
                                className="w-full h-full object-cover rounded-md"
                              />
                            </div>
                            <div className="flex-1 overflow-hidden">
                              <p className="text-lg font-medium text-gray-800 truncate">
                                {community.publicPageUrl}
                              </p>
                              <p className="text-sm text-gray-500">
                                {community.role}
                              </p>
                            </div>
                            <div>
                              <Image
                                src={"/assets/icons/link.svg"}
                                alt="Link icon"
                                width={17}
                                height={17}
                              />
                            </div>
                          </Link>
                        );
                      }
                    })}
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Home;
