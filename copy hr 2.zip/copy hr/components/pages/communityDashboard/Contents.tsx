import React, { Dispatch, SetStateAction, useEffect, useState } from "react";
import Modal from "@/components/reusable/Modal";
import Image from "next/image";
import axios from "axios";
import {
  CommunityDetails,
  ContentType,
  RecordType,
} from "@/types/communityDetails.types";
import { User } from "@/types/user.types";
import DynamicForm from "../ContentTypeForm";
import toast, { Toaster } from "react-hot-toast";
import { FaCopy } from "react-icons/fa";
import Select, { MultiValue } from "react-select";

type ChildComponentProps = {
  communityDetails?: CommunityDetails;
  loggedUserData?: User;
  setCommunityDetails: Dispatch<SetStateAction<CommunityDetails | undefined>>;
};

type TagOption = {
  value: string;
  label: string;
};

type GroupedRecords = {
  [monthYear: string]: RecordType[];
};

const Contents = ({
  communityDetails,
  setCommunityDetails,
}: ChildComponentProps) => {
  const [isCreateContentTypeModal, setIsCreateContentTypeModal] =
    useState<boolean>(false);
  const [isOpenDelete, setIsDelete] = useState<boolean>(false);
  const [selectedContentType, setSelectedContentType] =
    useState<ContentType | null>();
  const [showRecords, setShowRecords] = useState<boolean>(false);
  const [filteredRecords, setFilteredRecords] = useState<RecordType[]>([]);
  const [tags, setTags] = useState<TagOption[]>([]);
  const [selectedTags, setSelectedTags] = useState<MultiValue<TagOption>>([]);
  const [selectedRecord, setSelectedRecord] = useState<RecordType | null>();
  const [copySuccess, setCopySuccess] = useState(false);
  const [isListView, setIsListView] = useState(true);
  const [dateFilter, setDateFilter] = useState<string | null>(null);
  const [selectedMonth, setSelectedMonth] = useState<string | null>(null);
  const [textFilter, setTextFilter] = useState<string>("");

  function handleClose(): void {
    setIsCreateContentTypeModal(false);
    setIsDelete(false);
  }

  useEffect(() => {
    if (isCreateContentTypeModal || selectedRecord) {
      document.body.classList.add("no-scroll");
    } else {
      document.body.classList.remove("no-scroll");
    }
  }, [isCreateContentTypeModal, selectedRecord]);

  const handleToggleActive = async (
    contentTypeId: string,
    newIsActive: boolean
  ) => {
    try {
      const response = await axios.put(
        `/api/content/changeStatus/${contentTypeId}`,
        {
          isActive: newIsActive,
        }
      );

      if (response.data.success) {
        setCommunityDetails((prevDetails) => {
          if (!prevDetails) return prevDetails;
          return {
            ...prevDetails,
            contentTypes: prevDetails.contentTypes.map((contentType) =>
              contentType._id === contentTypeId
                ? { ...contentType, isActive: newIsActive }
                : contentType
            ),
          };
        });

        toast("Status updated successfully!", {
          icon: "✅",
          style: {
            backgroundColor: "#454545",
            color: "white",
          },
        });
      }
    } catch (error) {
      console.error("Error updating content type status:", error);

      toast("Failed to update status. Please try again.", {
        icon: "❌",
        style: {
          backgroundColor: "#454545",
          color: "white",
        },
      });
    }
  };

  const handleDelete = async (contentTypeId: string) => {
    try {
      const response = await axios.delete(`/api/content/${contentTypeId}`);

      if (response.data.success) {
        setCommunityDetails((prevDetails) => {
          if (!prevDetails) return prevDetails;
          return {
            ...prevDetails,
            contentTypes: prevDetails.contentTypes.filter(
              (contentType) => contentType._id !== contentTypeId
            ),
          };
        });

        toast("Content type deleted successfully!", {
          icon: "✅",
          style: {
            backgroundColor: "#454545",
            color: "white",
          },
        });
      }
    } catch (error) {
      console.error("Error deleting content type:", error);

      toast("Failed to delete content type. Please try again.", {
        icon: "❌",
        style: {
          backgroundColor: "#454545",
          color: "white",
        },
      });
    } finally {
      handleClose();
    }
  };

  const filterByDate = (records: RecordType[]) => {
    const today = new Date();
    const normalizeDate = (date: Date) =>
      new Date(date.getFullYear(), date.getMonth(), date.getDate());

    return records.filter((record) => {
      if (!record.createDate) {
        console.log("Invalid or missing createdAt field in record:", record);
        return false;
      }

      const recordDate = new Date(record.createDate);

      if (isNaN(recordDate.getTime())) {
        console.log("Invalid date format in record:", record);
        return false;
      }

      const normalizedRecordDate = normalizeDate(recordDate);

      if (dateFilter === "today") {
        return (
          normalizedRecordDate.getTime() === normalizeDate(today).getTime()
        );
      } else if (dateFilter === "yesterday") {
        const yesterday = new Date(today);
        yesterday.setDate(yesterday.getDate() - 1);
        return (
          normalizedRecordDate.getTime() === normalizeDate(yesterday).getTime()
        );
      } else if (dateFilter === "last7days") {
        const last7Days = new Date(today);
        last7Days.setDate(last7Days.getDate() - 7);
        return (
          normalizedRecordDate.getTime() >= normalizeDate(last7Days).getTime()
        );
      } else if (dateFilter === "last30days") {
        const last30Days = new Date(today);
        last30Days.setDate(last30Days.getDate() - 30);
        return (
          normalizedRecordDate.getTime() >= normalizeDate(last30Days).getTime()
        );
      } else if (dateFilter === "month" && selectedMonth) {
        const [year, month] = selectedMonth.split("-");
        return (
          normalizedRecordDate.getFullYear() === parseInt(year) &&
          normalizedRecordDate.getMonth() + 1 === parseInt(month)
        );
      }

      return true;
    });
  };

  const filterRecords = () => {
    let filtered = selectedContentType?.records || [];

    if (selectedTags.length > 0) {
      filtered = filtered.filter((record) =>
        selectedTags.every((tag) => {
          const tagInTags = record.recordFields.tags
            ?.split(", ")
            .includes(tag.value);
          const tagInFields = Object.values(record.recordFields).some(
            (answer) => typeof answer === "string" && answer === tag.value
          );
          return tagInTags || tagInFields;
        })
      );
    }

    if (dateFilter || selectedMonth) {
      filtered = filterByDate(filtered);
    }

    if (textFilter) {
      filtered = filtered.filter((record) =>
        Object.values(record.recordFields).some(
          (answer) =>
            typeof answer === "string" &&
            answer.toLowerCase().includes(textFilter.toLowerCase())
        )
      );
    }

    setFilteredRecords(filtered);
  };

  useEffect(() => {
    filterRecords();
  }, [dateFilter, selectedMonth, selectedTags, textFilter]);

  const fetchCommunity = async () => {
    if (communityDetails?._id) {
      try {
        console.log(communityDetails?._id);

        const response = await axios.get(
          `/api/community/get-by-id/${communityDetails?._id}`
        );
        if (response.status === 200) {
          console.log(response.data.community);

          setCommunityDetails(response.data.community);
        } else {
          console.log("Unexpected status code:", response.status);
        }
      } catch (error) {
        console.error(error);
      }
    }
  };

  const copyToClipboard = async () => {
    try {
      if (selectedContentType) {
        await navigator.clipboard.writeText(
          `${process.env.NEXT_PUBLIC_DOMAIN_NAME}/content-form/${communityDetails?._id}/${selectedContentType._id}`
        );
        setCopySuccess(true);
      }
    } catch (err) {
      console.error("Failed to copy:", err);
    }
  };

  useEffect(() => {
    if (copySuccess) {
      toast("Link copied to clipboard!", {
        icon: "👍",
        style: {
          backgroundColor: "white",
          color: "black",
        },
      });
      setCopySuccess(false);
    }
  }, [copySuccess]);

  useEffect(() => {
    if (selectedContentType) {
      const uniqueTagsArray = Array.from(
        new Set(selectedContentType.tags || [])
      ).map((tag) => ({ value: tag, label: tag }));

      setTags(uniqueTagsArray);
      setFilteredRecords(selectedContentType.records);
    }
  }, [selectedContentType]);

  const toggleViewMode = () => {
    setIsListView(!isListView);
  };

  const groupRecordsByMonthAndYear = (
    records: RecordType[]
  ): [string, RecordType[]][] => {
    const grouped: GroupedRecords = records.reduce((acc, record) => {
      const date = new Date(record.createDate);
      const monthYear = `${date.toLocaleString("default", {
        month: "long",
      })} ${date.getFullYear()}`;

      if (!acc[monthYear]) {
        acc[monthYear] = [];
      }
      acc[monthYear].push(record);
      return acc;
    }, {} as GroupedRecords);

    // Sort the grouped records by monthYear in descending order (latest first)
    const sortedGroupedEntries = Object.entries(grouped).sort(([a], [b]) => {
      const [aMonth, aYear] = a.split(" ");
      const [bMonth, bYear] = b.split(" ");

      const dateA = new Date(`${aMonth} 1, ${aYear}`);
      const dateB = new Date(`${bMonth} 1, ${bYear}`);

      return dateB.getTime() - dateA.getTime();
    });

    return sortedGroupedEntries;
  };

  useEffect(() => {
    fetchCommunity();
  }, [isCreateContentTypeModal, communityDetails?._id]);

  const handleCloseRecordModal = () => {
    setSelectedRecord(null);
  };

  return (
    <>
      {!showRecords && communityDetails && (
        <section className="text-primaryBlack px-4 flex flex-col justify-start min-h-screen">
          <div className="h-[85vh] bg-slate-100 overflow-y-scroll px-4 pt-3 rounded">
            {communityDetails.contentTypes &&
            communityDetails.contentTypes.length > 0 ? (
              communityDetails.contentTypes.map((contentType: ContentType) => (
                <div
                  key={contentType._id}
                  className="flex justify-between gap-2 mb-4"
                >
                  <div className="flex flex-1 bg-white px-4 py-4 rounded-md justify-between items-center">
                    <div
                      onClick={() => {
                        setShowRecords(true);
                        setSelectedContentType(contentType);
                      }}
                      className="w-[60%] cursor-pointer"
                    >
                      <p>{contentType.title}</p>
                      <p>{contentType.records.length} Record(s)</p>
                    </div>
                    <div className="flex justify-end items-center gap-5 w-[40%]">
                      <div className="flex items-center">
                        <label className="switch">
                          <input
                            type="checkbox"
                            checked={contentType.isActive}
                            onChange={() =>
                              handleToggleActive(
                                contentType._id,
                                !contentType.isActive
                              )
                            }
                          />
                          <span className="slider round"></span>
                        </label>
                      </div>

                      <button
                        type="button"
                        onClick={() => {
                          setSelectedContentType(contentType);
                          setIsDelete(true);
                        }}
                        className="disabled:cursor-not-allowed"
                        disabled={contentType.records.length !== 0}
                      >
                        <Image
                          src={"/assets/icons/bin.png"}
                          alt="delete"
                          width={20}
                          height={20}
                        />
                      </button>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedContentType(contentType);
                      setIsCreateContentTypeModal(true);
                    }}
                    className="w-14 bg-white text-sm flex justify-center items-center rounded-md disabled:cursor-not-allowed"
                  >
                    <Image
                      src={
                        contentType.records.length === 0
                          ? "/assets/icons/edit-button.png"
                          : "/assets/icons/eye.svg"
                      }
                      alt={contentType.records.length === 0 ? "update" : "view"}
                      width={20}
                      height={20}
                      className="object-cover object-center"
                    />
                  </button>
                </div>
              ))
            ) : (
              <div className="flex justify-center items-center w-full h-full">
                <h2 className="text-center">There are no Content Types</h2>
              </div>
            )}
          </div>
          <div className="h-[10vh] flex items-center justify-center">
            <button
              type="button"
              className="primaryButton"
              onClick={() => {
                setIsCreateContentTypeModal(true);
                setSelectedContentType(null);
              }}
            >
              Create New Content Type
            </button>
          </div>
          {isCreateContentTypeModal && (
            <Modal
              isOpen={isCreateContentTypeModal}
              onClose={handleClose}
              width="90"
            >
              <DynamicForm
                onClose={handleClose}
                communityDetails={communityDetails}
                contentType={selectedContentType}
              />
            </Modal>
          )}
          {isOpenDelete && selectedContentType && (
            <Modal isOpen={isOpenDelete} onClose={handleClose} width="90">
              <p className="text-center">Are you sure you want to delete?</p>
              <div className="flex w-full justify-between items-center gap-5">
                <button
                  type="button"
                  onClick={handleClose}
                  className="secondaryButton mt-5"
                >
                  No
                </button>
                <button
                  type="button"
                  className="primaryButton "
                  onClick={() => {
                    handleDelete(selectedContentType._id);
                  }}
                >
                  Yes
                </button>
              </div>
            </Modal>
          )}
        </section>
      )}
      {showRecords && selectedContentType && (
        <section className="bg-slate-100 overflow-x-hidden desktopView relative min-h-screen p-4">
          <div className="flex  justify-between items-stretch mb-4 gap-2">
            <button
              type="button"
              onClick={() => {
                setSelectedContentType(null);
                setShowRecords(false);
              }}
              className="px-3 py-3 text-sm bg-primaryBlack text-white rounded"
            >
              &lt; Back
            </button>

            <Select
              isMulti
              value={selectedTags}
              onChange={(selected) => setSelectedTags(selected)}
              options={tags}
              className="flex-1 focus:outline-none outline-none w-full text-sm placeholder:text-[#767676]"
              placeholder="Filter Records by tags"
              styles={{
                control: (base, state) => ({
                  ...base,
                  borderWidth: 0,
                  border: "none",
                  boxShadow: "none",
                }),
                container: (base) => ({
                  ...base,
                  backgroundColor: "white",
                  border: "1px solid #d1d5db",
                  borderRadius: "0.375rem",
                  padding: "6px",
                }),
                placeholder: (base) => ({
                  ...base,
                  color: "#767676",
                }),
              }}
            />
          </div>

          <div className="flex flex-wrap items-center justify-center gap-4 mb-6">
            <input
              type="text"
              value={textFilter}
              onChange={(e) => setTextFilter(e.target.value)}
              placeholder="Filter Records by text"
              className="flex-grow min-w-[180px] w-full py-4 px-4 border-[#E9E9E9] border-[1px] rounded-lg text-sm placeholder:text-[#767676] placeholder:text-sm outline-none focus:border-primaryBlack font-normal text-primaryBlack leading-5"
            />
          </div>
          <div className="flex flex-wrap items-center justify-center gap-4 mb-6">
            <select
              value={dateFilter || ""}
              onChange={(e) => setDateFilter(e.target.value)}
              className="flex-grow min-w-[180px] w-full py-4 px-4 border-[#E9E9E9] border-[1px] rounded-lg text-sm placeholder:text-[#767676] placeholder:text-sm outline-none focus:border-primaryBlack font-normal text-primaryBlack leading-5"
            >
              <option value="">Filter Records by date</option>
              <option value="today">Today</option>
              <option value="yesterday">Yesterday</option>
              <option value="last7days">Last 7 Days</option>
              <option value="last30days">Last 30 Days</option>
            </select>
          </div>
          <div className="flex flex-col xs:flex-row justify-between items-center mb-10 gap-5">
            <div className="flex items-center ">
              <span
                className={`px-4 py-2 text-xs md:text-sm rounded-l-md cursor-pointer ${
                  isListView
                    ? "bg-primaryBlack text-white"
                    : "bg-white text-black"
                }`}
                onClick={() => setIsListView(true)}
              >
                List View
              </span>
              <span
                className={`px-4 py-2 text-xs md:text-sm rounded-r-md cursor-pointer ${
                  !isListView
                    ? "bg-primaryBlack text-white"
                    : "bg-white text-black"
                }`}
                onClick={() => setIsListView(false)}
              >
                Record View
              </span>
            </div>
            <div
              className="w-[70%] sm:w-[40%] cursor-pointer"
              onClick={copyToClipboard}
            >
              <div className="text-gray-500 flex justify-center  text-sm md:text-base items-center gap-1 px-3 py-2 rounded-3xl  ">
                <p className="text-nowrap">Tab to Copy Link</p>
                <FaCopy />
              </div>
            </div>
          </div>
          {isListView ? (
            <div className="space-y-4">
              {filteredRecords.length > 0 ? (
                groupRecordsByMonthAndYear(filteredRecords).map(
                  ([monthYear, records]) => (
                    <div key={monthYear}>
                      <h2 className="text-lg font-semibold mb-2">
                        {monthYear}
                      </h2>
                      {records.map((record) => {
                        let linkCounter = 1;
                        return (
                          <div
                            key={record._id}
                            className="border p-4 rounded-md shadow-md bg-white mb-5"
                          >
                            {record.memberDetails ? (
                              <div className="flex items-center mb-4">
                                <Image
                                  src={record.memberDetails?.userId.avatar}
                                  alt="Member Avatar"
                                  className="w-12 h-12 rounded-full mr-4"
                                  width={20}
                                  height={20}
                                />
                                <div>
                                  <p className="text-lg font-medium text-gray-700">
                                    {record.memberDetails?.userId.fullName}
                                  </p>
                                  <p className="text-sm text-gray-500">
                                    {record.memberDetails?.userId.email}
                                  </p>
                                  <p className="text-sm text-gray-500">
                                    {record.memberDetails?.userId.phoneNumber}
                                  </p>
                                </div>
                              </div>
                            ) : (
                              <p className="mb-4">Deleted Member</p>
                            )}
                            <div className="bg-gray-100 p-4 rounded-md shadow-md">
                              <h2 className="text-lg font-semibold mb-2">
                                Record Details
                              </h2>
                              {Object.entries(record.recordFields).map(
                                ([question, answer]) => (
                                  <div key={question} className="mb-2">
                                    <p className="font-semibold text-gray-800">
                                      {question}:
                                    </p>
                                    {typeof answer === "string" &&
                                    answer.startsWith("http") ? (
                                      <a
                                        href={answer}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="text-blue-600 underline"
                                      >
                                        {`LINK ${linkCounter++}`}
                                      </a>
                                    ) : (
                                      <p className="text-gray-600">{answer}</p>
                                    )}
                                  </div>
                                )
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )
                )
              ) : (
                <p className="text-center mt-5">No records found</p>
              )}
            </div>
          ) : (
            <div className="space-y-4">
              {filteredRecords.length > 0 ? (
                groupRecordsByMonthAndYear(filteredRecords).map(
                  ([monthYear, records]) => (
                    <div key={monthYear}>
                      <h2 className="text-lg font-semibold mb-2">
                        {monthYear}
                      </h2>
                      {records.map((record) => {
                        let linkCounter = 1;
                        return (
                          <div
                            key={record._id}
                            onClick={() => {
                              setSelectedRecord(record);
                            }}
                            className="border p-4 rounded-md shadow-md bg-white cursor-pointer mb-5"
                          >
                            <p>
                              Record by{" "}
                              {record.memberDetails?.userId.fullName ||
                                "deleted Member"}
                            </p>
                          </div>
                        );
                      })}
                    </div>
                  )
                )
              ) : (
                <p className="text-center mt-5">No records found</p>
              )}
            </div>
          )}

          {selectedRecord && (
            <Modal
              isOpen={!!selectedRecord}
              width="90"
              onClose={handleCloseRecordModal}
            >
              <div className="p-6 h-[90vh] overflow-auto bg-gray-100 rounded-lg">
                {/* Member Details */}
                <div className="mb-6">
                  <h2 className="text-xl font-semibold mb-4 text-primaryBlack">
                    Member Details
                  </h2>
                  {selectedRecord.memberDetails ? (
                    <div className="flex items-center mb-4">
                      <Image
                        width={20}
                        height={20}
                        src={selectedRecord.memberDetails.userId.avatar}
                        alt="Member Avatar"
                        className="w-16 h-16 rounded-full mr-4"
                      />
                      <div>
                        <p className="text-lg font-medium text-gray-700">
                          {selectedRecord.memberDetails.userId.fullName}
                        </p>
                        <p className="text-sm text-gray-500">
                          {selectedRecord.memberDetails.userId.email}
                        </p>
                        <p className="text-sm text-gray-500">
                          {selectedRecord.memberDetails.userId.phoneNumber}
                        </p>
                      </div>
                    </div>
                  ) : (
                    <p className="mb-4">Deleted Member</p>
                  )}
                </div>

                {/* Record Fields */}
                <div>
                  <h2 className="text-xl font-semibold mb-4 text-primaryBlack">
                    Record Details
                  </h2>
                  <div className="space-y-4">
                    {Object.entries(selectedRecord.recordFields).map(
                      ([question, answer]) => {
                        let linkCounter = 1;
                        return (
                          <div
                            key={question}
                            className="p-4 bg-white shadow rounded-md"
                          >
                            <p className="font-semibold text-gray-800">
                              {question}:
                            </p>
                            {typeof answer === "string" &&
                            answer.startsWith("http") ? (
                              <a
                                href={answer}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-blue-600 underline"
                              >
                                {`LINK ${linkCounter++}`}
                              </a>
                            ) : (
                              <p className="text-gray-600">{answer}</p>
                            )}
                          </div>
                        );
                      }
                    )}
                  </div>
                </div>
              </div>
            </Modal>
          )}
        </section>
      )}
      <Toaster />
    </>
  );
};

export default Contents;
