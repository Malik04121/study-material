"use client";
import {
  CommunityDetails,
  MemberDetails,
} from "@/types/communityDetails.types";
import { User } from "@/types/user.types";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import React, {
  Dispatch,
  SetStateAction,
  Suspense,
  useEffect,
  useState,
} from "react";

import Image from "next/image";
import { formatDate } from "@/helper/formatDate";

import { calculateDaysPassed } from "@/helper/calculateDaysPassed";
import axios from "axios";
import Modal from "@/components/reusable/Modal";
import toast from "react-hot-toast";
type ChildComponentProps = {
  communityDetails?: CommunityDetails;
  loggedUserData?: User;
  setCommunityDetails: Dispatch<SetStateAction<CommunityDetails | undefined>>;
};

const Members = ({
  communityDetails,
  loggedUserData,
  setCommunityDetails,
}: ChildComponentProps) => {
  const searchParams = useSearchParams();
  const router = useRouter();
  const activeTab = searchParams.get("tab");
  const activeMember = searchParams.get("member");
  const pendingMember = searchParams.get("pending-member");
  const [selectedMember, setSelectedMember] = useState<MemberDetails>();
  const [openRemoveMember, setOpenRemoveMember] = useState<boolean>(false);
  const [selectedReason, setSelectedReason] = useState<string>("");
  const [otherReason, setOtherReason] = useState<string>("");
  const [searchQuery, setSearchQuery] = useState("");
  const [hasResults, setHasResults] = useState(true);
  const [removalMessage, setRemovalMessage] = useState("");
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [showRemoveMemberModal, setShowRemoveMemberModal] =
    useState<boolean>(false);
  const updateMembership = async (
    isApprovedMember: boolean,
    isRejectedMember: boolean,
    newMemberId: string,
    reason?: string,
    receiverEmail?: string
  ) => {
    try {
      setIsLoading(true);
      console.log(communityDetails, newMemberId);
      setRemovalMessage(
        "Removing from community. But you have to delete the member from WhatsApp (if present)."
      );
      const response = await axios.post("/api/community/update-membership", {
        communityId: communityDetails?._id,
        memberId: newMemberId,
        userId: loggedUserData?._id,
        reasonForRemoval: reason,
        isCustomReason: selectedReason === "other",
        isApprovedMember,
        isRejectedMember,
        fromHost: true,
        receiverEmail,
      });
      if (response.data) {
        if (reason && communityDetails?.whatsUpGroupLink) {
          toast.custom((t) => (
            <div
              className={`${
                t.visible ? "animate-enter" : "animate-leave"
              } max-w-md w-full bg-gray-100 shadow-lg rounded-lg pointer-events-auto flex ring-1 ring-black ring-opacity-5`}
            >
              <div className="flex-1 w-0 p-4">
                <div className="flex items-center">
                  <div className="flex-shrink-0 text-lg pt-0.5">💁🏻‍♂️</div>
                  <div className="ml-3 flex-1">
                    <p className="text-sm font-medium text-gray-900">
                      Member successfully removed from WA Collab but not from
                      the chat.
                    </p>
                    <p className="mt-1 text-xs text-gray-500">
                      You will need to remove the member manually from the chat.
                    </p>
                  </div>
                </div>
              </div>
              <div className="flex items-center border-l border-gray-200">
                <button
                  onClick={() => toast.dismiss(t.id)}
                  className="w-full border border-transparent rounded-none rounded-r-lg p-4 flex items-center justify-center text-sm font-medium text-primaryBlack focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-yellow-500"
                >
                  Got it
                </button>
              </div>
            </div>
          ));
        }
        // setTimeout(() => {
        //   setRemovalMessage("");
        window.location.reload();
        // }, 5000);

        // setCommunityDetails(() => response.data.community);
      }
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleReasonChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSelectedReason(e.target.value);
    if (e.target.value !== "other") {
      setOtherReason("");
    }
  };

  const handleOtherReasonChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setOtherReason(e.target.value);
  };

  const handleSubmit = async (id: string) => {
    const reason = selectedReason === "other" ? otherReason : selectedReason;
    console.log("Reason for removal:", reason);
    try {
      // setOpenRemoveMember(false);
      // setShowRemoveMemberModal(false);

      await updateMembership(
        false,
        true,
        id,
        reason,
        selectedMember?.userId.email
      );
    } catch (error) {
      console.error(error);
    }
    // You can handle the submit logic here (e.g., make an API call)
  };
  let filteredPendingMembers, filteredRejectedMembers, filteredApprovedMembers;
  console.log(communityDetails);

  if (communityDetails) {
    filteredPendingMembers = communityDetails.pendingMembers.filter(
      (member) =>
        member.userId?.fullName
          ?.toLowerCase()
          ?.includes(searchQuery.toLowerCase()) ||
        member.userId?.email.toLowerCase().includes(searchQuery.toLowerCase())
    );

    filteredRejectedMembers = communityDetails.rejectedMembers.filter(
      (member) =>
        member.userId?.fullName
          .toLowerCase()
          .includes(searchQuery.toLowerCase()) ||
        member.userId?.email.toLowerCase().includes(searchQuery.toLowerCase())
    );

    filteredApprovedMembers = communityDetails.approvedMembers.filter(
      (member) =>
        member.userId?.fullName
          .toLowerCase()
          .includes(searchQuery.toLowerCase()) ||
        member.userId?.email.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }
  console.log(filteredApprovedMembers);

  useEffect(() => {
    const hasPendingResults = filteredPendingMembers?.length > 0;
    const hasRejectedResults = filteredRejectedMembers?.length > 0;
    const hasApprovedResults = filteredApprovedMembers?.length > 0;

    setHasResults(
      hasPendingResults || hasRejectedResults || hasApprovedResults
    );
  }, [
    filteredPendingMembers,
    filteredRejectedMembers,
    filteredApprovedMembers,
  ]);

  const handleClose = () => {
    setShowRemoveMemberModal(false);
  };
  console.log(showRemoveMemberModal);

  useEffect(() => {
    if (showRemoveMemberModal || openRemoveMember) {
      document.body.classList.add("no-scroll");
    } else {
      document.body.classList.remove("no-scroll");
    }
  }, [showRemoveMemberModal, openRemoveMember]);
  return (
    <Suspense>
      {communityDetails && (
        <section className=" text-primaryBlack px-4 flex flex-col justify-between min-h-screen">
          <div className="flex justify-start items-center gap-2  overflow-x-scroll no-scrollbar ">
            <Link
              href={`/portal/members/${communityDetails?._id}?tab=all`}
              className={` text-sm p-1 px-4 border-[0.5px] border-white text-nowrap text-center rounded-2xl font-medium  ${
                activeTab === "all"
                  ? "border-gold bg-yellow-50 "
                  : "  bg-gray-100 "
              }`}
            >
              All (
              {communityDetails.approvedMembers.length +
                communityDetails.pendingMembers.length +
                communityDetails.rejectedMembers.length}
              )
            </Link>

            {communityDetails?.approvedMembers.length > 0 && (
              <Link
                href={`/portal/members/${communityDetails?._id}?tab=members`}
                className={` text-sm p-1 px-4 border-[0.5px] border-white text-nowrap text-center rounded-2xl font-medium  ${
                  activeTab === "members"
                    ? "border-gold bg-yellow-50 "
                    : "  bg-gray-100 "
                }`}
              >
                Active Members ({communityDetails.approvedMembers.length})
              </Link>
            )}
            {communityDetails?.pendingMembers.length > 0 && (
              <Link
                href={`/portal/members/${communityDetails?._id}?tab=pending`}
                className={` text-sm p-1 px-4 border-[0.5px] border-white text-nowrap text-center rounded-2xl font-medium  ${
                  activeTab === "pending"
                    ? "border-gold bg-yellow-50 "
                    : "  bg-gray-100 "
                }`}
              >
                Pending approval ({communityDetails.pendingMembers.length})
              </Link>
            )}
            {communityDetails?.rejectedMembers.length > 0 && (
              <Link
                href={`/portal/members/${communityDetails?._id}?tab=rejected`}
                className={` text-sm p-1 px-4 border-[0.5px] border-white text-nowrap text-center rounded-2xl font-medium  ${
                  activeTab === "rejected"
                    ? "border-gold bg-yellow-50 "
                    : "  bg-gray-100 "
                }`}
              >
                Inactive Members ({communityDetails.rejectedMembers.length})
              </Link>
            )}
          </div>
          <div>
            <div className=" my-5 flex justify-between items-stretch border-[0.5px] border-primaryBlack  rounded-xl overflow-clip ">
              <div className="basis-[8%] bg-para flex justify-center items-center bg-opacity-20 p-2">
                <Image
                  src={"/assets/icons/search_icon.png"}
                  alt="icons"
                  width={15}
                  height={15}
                  className="w-[90%] "
                />
              </div>
              <input
                type="text"
                name="search"
                id=""
                className=" w-full py-4 px-4 border-[#E9E9E9] border-[1px] rounded-r-lg text-base  placeholder:text-[#767676] placeholder:text-sm outline-none  font-normal text-primaryBlack leading-5"
                placeholder="Search using email or name"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
          {/* <hr className="h-[0.5px] border-gray-500 border" /> */}
          <div className=" flex-1 ">
            {communityDetails && loggedUserData && (
              <div className="flex flex-col justify-between items-center w-full py-8">
                <div className="w-full mb-3">
                  <p className="text-xl font-medium leading-5 text-left">
                    {filteredApprovedMembers &&
                    filteredPendingMembers &&
                    filteredRejectedMembers &&
                    activeTab === "all"
                      ? filteredApprovedMembers.length +
                        filteredPendingMembers.length +
                        filteredRejectedMembers.length
                      : activeTab === "members"
                      ? filteredApprovedMembers &&
                        filteredApprovedMembers.length
                      : activeTab === "pending"
                      ? filteredPendingMembers && filteredPendingMembers.length
                      : activeTab === "rejected"
                      ? filteredRejectedMembers &&
                        filteredRejectedMembers.length
                      : 0}
                    {" Record(s)"}
                  </p>
                </div>
                <div className="w-full overflow-x-auto">
                  {hasResults ? (
                    <table className="min-w-[1000px] w-full table-auto">
                      <thead>
                        <tr>
                          <th className="px-20 py-1  text-para font-medium text-sm leading-4 ">
                            Name
                          </th>
                          <th className="px-20 py-1  text-para font-medium text-sm leading-4">
                            Contact
                          </th>
                          <th className="px-20 py-1  text-para font-medium text-sm text-nowrap">
                            Joined Date
                          </th>
                          <th className="px-20 py-1  text-para font-medium text-sm text-nowrap">
                            Application Submitted Date
                          </th>
                          {(activeTab === "rejected" ||
                            activeTab === "all") && (
                            <th className="px-20 py-1  text-para font-medium text-sm text-nowrap">
                              Removal Date
                            </th>
                          )}
                          {(activeTab === "rejected" ||
                            activeTab === "all") && (
                            <th className="px-20 py-1  text-para font-medium text-sm text-nowrap">
                              Removal Reason
                            </th>
                          )}
                        </tr>
                      </thead>

                      <tbody>
                        {(activeTab === "all" || activeTab === "rejected") &&
                          filteredRejectedMembers &&
                          filteredRejectedMembers.map((member) => (
                            <tr
                              key={member._id}
                              className="border border-y-gray-400 border-x-white cursor-pointer"
                              onClick={() => {
                                setSelectedMember(member);
                                router.push(
                                  `/portal/members/${communityDetails._id}?tab=all&member=${member._id}`
                                );
                              }}
                            >
                              <td className="py-2">
                                <div className="flex justify-start gap-5 items-center">
                                  <div className="w-10 h-10 rounded-full overflow-hidden">
                                    <Image
                                      src={member.userId.avatar}
                                      alt="member_logo"
                                      width={100}
                                      height={100}
                                      className="w-full h-full object-cover "
                                    />
                                  </div>
                                  <div className="flex flex-col justify-between items-start gap-1">
                                    <p className="text-base text-primaryBlack">
                                      {member.userId.fullName}
                                    </p>
                                    <p className="text-red-900 bg-red-100 rounded text-xs px-2 py-1">
                                      Removed
                                    </p>
                                  </div>
                                </div>
                              </td>
                              <td className="py-2">
                                <div className="flex flex-col justify-start gap-1 items-center text-sm">
                                  <p>{member.userId.email}</p>
                                  <p>{member.userId.phoneNumber}</p>
                                </div>
                              </td>
                              <td className="text-center text-sm font-light py-2">
                                <p>
                                  {member.joinDate
                                    ? formatDate(member.joinDate)
                                    : formatDate(Date.now())}
                                </p>
                              </td>
                              <td className="text-center text-sm font-light py-2">
                                <p>
                                  {member.applicationSubmittedDate
                                    ? formatDate(
                                        member.applicationSubmittedDate
                                      )
                                    : "-"}
                                </p>
                              </td>
                              <td className="text-center text-sm font-light py-2">
                                <p>
                                  {member.rejectedDate
                                    ? formatDate(member.rejectedDate)
                                    : "-"}
                                </p>
                              </td>
                              <td className="text-center text-sm font-light py-2">
                                <p>
                                  {member.removalReason
                                    ? member.removalReason
                                    : "-"}
                                </p>
                              </td>
                            </tr>
                          ))}
                        {(activeTab === "all" || activeTab === "pending") &&
                          filteredPendingMembers &&
                          filteredPendingMembers.map((member) => (
                            <tr
                              key={member._id}
                              className="border border-y-gray-400  border-x-white cursor-pointer"
                              onClick={() => {
                                setSelectedMember(member);
                                router.push(
                                  `/portal/members/${communityDetails._id}?tab=all&member=${member._id}&pending-member=true`
                                );
                              }}
                            >
                              <td className="  py-2">
                                <div className="flex justify-start gap-5 items-center cursor-pointer">
                                  <div className="w-10 h-10 rounded-full overflow-hidden">
                                    <Image
                                      src={member.userId.avatar}
                                      alt="member_logo"
                                      width={100}
                                      height={100}
                                      className="w-full h-full object-cover"
                                    />
                                  </div>
                                  <div className="flex flex-col justify-between items-start gap-1">
                                    <p className="text-base text-primaryBlack">
                                      {member.userId.fullName}
                                    </p>
                                    <p className="text-purple-900 bg-purple-100 rounded text-xs px-2 py-1">
                                      Pending
                                    </p>
                                  </div>
                                </div>
                              </td>
                              <td className="  py-2">
                                <div className="flex flex-col justify-start gap-1 items-center text-sm">
                                  <p>{member.userId.email}</p>
                                  <p>{member.userId.phoneNumber}</p>
                                </div>
                              </td>
                              <td className=" text-center text-sm font-light   py-2">
                                <p>
                                  {member.joinDate
                                    ? Date.now()
                                    : formatDate(Date.now())}
                                </p>
                              </td>
                              <td className=" text-center text-sm font-light   py-2">
                                <p>
                                  {member.applicationSubmittedDate
                                    ? formatDate(
                                        member.applicationSubmittedDate
                                      )
                                    : "-"}
                                </p>
                              </td>
                              {activeTab === "all" && (
                                <td className="text-center text-sm font-light py-2">
                                  <p>-</p>
                                </td>
                              )}
                              {activeTab === "all" && (
                                <td className="text-center text-sm font-light py-2">
                                  <p>-</p>
                                </td>
                              )}
                            </tr>
                          ))}

                        {(activeTab === "all" || activeTab === "members") &&
                          filteredApprovedMembers &&
                          filteredApprovedMembers.map((member) => (
                            <tr
                              key={member._id}
                              className="border border-y-gray-400  border-x-white cursor-pointer"
                              onClick={() => {
                                setSelectedMember(member);
                                router.push(
                                  `/portal/members/${communityDetails._id}?tab=all&member=${member._id}`
                                );
                              }}
                            >
                              <td className="  py-2">
                                <div className="flex justify-start gap-5 items-center">
                                  <div className="w-10 h-10 rounded-full overflow-hidden">
                                    <Image
                                      src={member.userId.avatar}
                                      alt="member_logo"
                                      width={100}
                                      height={100}
                                      className="w-full h-full object-cover"
                                    />
                                  </div>
                                  <div className="flex flex-col justify-between items-start gap-1">
                                    <p className="text-base text-primaryBlack">
                                      {member.userId?.fullName}
                                    </p>
                                    <p className="text-green-900 bg-green-100 rounded text-xs px-2 py-1">
                                      Subscribed
                                    </p>
                                  </div>
                                </div>
                              </td>
                              <td className="  py-2">
                                <div className="flex flex-col justify-start gap-1 items-center text-sm">
                                  <p>{member.userId?.email}</p>
                                  <p>{member.userId?.phoneNumber}</p>
                                </div>
                              </td>
                              <td className=" text-center text-sm font-light   py-2">
                                <p>
                                  {member.joinDate
                                    ? formatDate(member.joinDate)
                                    : formatDate(Date.now())}
                                </p>
                              </td>
                              <td className=" text-center text-sm font-light   py-2">
                                <p>
                                  {member.applicationSubmittedDate
                                    ? formatDate(
                                        member.applicationSubmittedDate
                                      )
                                    : "-"}
                                </p>
                              </td>
                              {activeTab === "all" && (
                                <td className="text-center text-sm font-light py-2">
                                  <p>-</p>
                                </td>
                              )}
                              {activeTab === "all" && (
                                <td className="text-center text-sm font-light py-2">
                                  <p>-</p>
                                </td>
                              )}
                            </tr>
                          ))}
                      </tbody>
                    </table>
                  ) : (
                    <div className="flex flex-col items-center justify-center py-20">
                      <Image
                        src="/assets/icons/members.png"
                        alt="No matches found"
                        width={30}
                        height={30}
                      />
                      <p className="text-xl text-primaryBlack mt-4">
                        No matches found.
                      </p>
                      <p className="text-sm text-gray-500">
                        Tweak your search and filters.
                      </p>
                      <button
                        className="mt-6 px-4 py-2 text-white bg-black rounded-full"
                        onClick={() => setSearchQuery("")}
                      >
                        Reset Filters
                      </button>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
          {activeMember && selectedMember && (
            <div
              className={`fixed inset-0 text-primaryBlack left-0 right-0 bg-white desktopView bg-opacity-80 z-[500] flex justify-center items-end transition-transform duration-500 ${
                activeMember ? "translate-y-0" : "translate-y-full"
              }`}
            >
              <div
                className="bg-white w-full h-[100vh] relative border flex flex-col justify-start items-center  overflow-hidden"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="w-full h-[100%] flex flex-col overflow-y-auto px-8">
                  <div className="w-full py-5 flex justify-between items-center">
                    {activeMember === communityDetails.host &&
                    !pendingMember ? (
                      <div className="border-[0.5px] rounded-2xl px-4 py-2 text-sm text-primaryBlack">
                        Role: Host
                      </div>
                    ) : (
                      <div className="border-[0.5px] rounded-2xl px-4 py-2 text-sm text-primaryBlack">
                        Role: Member
                      </div>
                    )}
                    <button
                      type="button"
                      onClick={() => {
                        router.push(
                          `/portal/members/${communityDetails._id}?tab=all`
                        );
                      }}
                      className="text-primaryBlack text-lg self-end"
                    >
                      x
                    </button>
                  </div>
                  {/* {pendingMember && (
                    <p className="text-xs text-para text-center py-3">
                      User will be notified via email
                    </p>
                  )} */}
                  <hr className="h-[0.5px] w-full border-gray-300  border-[0.5px]" />
                  <div className="flex flex-col justify-between items-center py-10 gap-1">
                    <div className=" rounded-full  w-20 h-20">
                      <Image
                        src={selectedMember.userId.avatar}
                        alt="user_avatar"
                        width={100}
                        height={100}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <p className="text-xl font-medium leading-6">
                      {selectedMember.userId.fullName}
                    </p>
                    <p className="text-sm">{selectedMember.userId.email}</p>
                    {pendingMember && (
                      <div className="w-full py-3 space-y-1">
                        <div className="flex justify-start gap-2 items-center  w-[70%] mx-auto">
                          <button
                            type="button"
                            onClick={async () => {
                              setOpenRemoveMember(true);
                            }}
                            className="px-5 py-2 text-white bg-red-600 text-sm rounded-2xl w-full"
                          >
                            Reject
                          </button>
                          <button
                            type="button"
                            onClick={async () => {
                              await updateMembership(
                                true,
                                false,
                                selectedMember._id,
                                "",
                                selectedMember.userId.email
                              );
                            }}
                            disabled={isLoading}
                            className={`px-5 py-2 text-white bg-green-600 text-sm rounded-2xl w-full ${
                              isLoading && " bg-gray-400 text-black"
                            }`}
                          >
                            {!isLoading ? "Approve" : "Loading"}
                          </button>
                        </div>
                        <p className="text-sm font-light w-full text-center  text-para ">
                          User will be notified via email.
                        </p>
                      </div>
                    )}
                  </div>
                  <hr className="h-[0.5px] w-full border-gray-300  border-[0.5px] mb-2" />

                  <div className="flex flex-col justify-between items-center pb-10 w-full gap-3">
                    <h3 className="text-xl w-full font-medium leading-6 text-left">
                      Subscription Details
                    </h3>
                    <div className="w-full flex justify-between items-center text-sm">
                      <p>Status</p>
                      <div className="basis-[45%]">
                        <span
                          className={`px-2 py-1 rounded  text-left ${
                            pendingMember
                              ? "bg-purple-100 text-purple-500"
                              : selectedMember.rejectedDate
                              ? "bg-red-100 text-red-500 text-sm"
                              : "bg-green-100 text-green-500"
                          }`}
                        >
                          {pendingMember
                            ? "Pending"
                            : selectedMember.rejectedDate
                            ? "Removed"
                            : "Subscribed"}
                        </span>
                      </div>
                    </div>
                    <div className="w-full flex justify-between items-center text-sm">
                      <p>Joined date</p>
                      <p className="basis-[45%] text-left">
                        {selectedMember.joinDate
                          ? formatDate(selectedMember.joinDate)
                          : "-"}
                      </p>
                    </div>
                    <div className="w-full flex justify-between items-center text-sm">
                      <p className="basis-[45%] text-left">Member duration</p>
                      <p className="basis-[45%] text-left">
                        {selectedMember.applicationSubmittedDate
                          ? calculateDaysPassed(
                              selectedMember.applicationSubmittedDate
                            )
                          : "-"}
                      </p>
                    </div>
                  </div>
                  <hr className="h-[0.5px] w-full border-gray-300  border-[0.5px] mb-2" />

                  <div className="flex flex-col justify-between items-center pb-10 w-full gap-3">
                    <h3 className="text-xl w-full font-medium leading-6 text-left">
                      Member Details
                    </h3>
                    <div className="w-full flex justify-between items-center text-sm">
                      <div>
                        Mobile Number{" "}
                        <p className="md:inline-block">(WhatsApp)</p>
                      </div>
                      <p className="basis-[45%] text-left">
                        {selectedMember.userId.phoneNumber}
                      </p>
                    </div>
                  </div>
                  <hr className="h-[0.5px] w-full border-gray-300  border-[0.5px] mb-2" />

                  <div className="flex flex-col justify-between items-center pb-10 w-full gap-3">
                    {selectedMember.additionalFields &&
                      Object.keys(selectedMember.additionalFields).length >
                        0 && (
                        <>
                          <h3 className="text-xl w-full font-medium leading-6 text-left">
                            Additional Form Details
                          </h3>
                          {Object.entries(selectedMember.additionalFields).map(
                            ([key, value]) => (
                              <div
                                key={key}
                                className="w-full flex justify-between items-center text-sm"
                              >
                                <p className="w-[45%] text-left">{key}</p>
                                <p className="w-[45%] text-left">
                                  {value ? (
                                    key.toLowerCase().includes("url") ||
                                    key.toLowerCase().includes("link") ? (
                                      <Link
                                        href={value}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="hover:underline text-blue-400"
                                      >
                                        {value}
                                      </Link>
                                    ) : (
                                      value
                                    )
                                  ) : (
                                    "-"
                                  )}
                                </p>
                              </div>
                            )
                          )}
                        </>
                      )}
                  </div>

                  {selectedMember._id !== communityDetails.host &&
                    !pendingMember &&
                    !selectedMember.rejectedDate && (
                      <div className="mt-auto mb-5 w-full">
                        <button
                          type="button"
                          onClick={async () => {
                            setOpenRemoveMember(true);
                          }}
                          className="px-5 py-2 text-white bg-red-600 text-sm rounded-2xl"
                        >
                          Remove member
                        </button>
                      </div>
                    )}
                  {openRemoveMember && (
                    <div
                      className={`fixed inset-0 text-primaryBlack left-0 right-0 bg-white desktopView bg-opacity-90 z-[505] flex justify-center items-end transition-transform duration-500 ${
                        openRemoveMember ? "translate-y-0" : "translate-y-full"
                      }`}
                    >
                      <div
                        className="bg-white w-full pt-10 relative border  rounded-t-3xl"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <div className="flex flex-col justify-start items-center px-8 gap-4">
                          <h3 className="text-xl w-full font-medium leading-6 text-left">
                            Reason for member removal
                          </h3>
                          <div className="w-full space-x-2">
                            <input
                              type="radio"
                              name="reason"
                              id="1"
                              value="Member is not a fit for the community anymore"
                              onChange={handleReasonChange}
                            />
                            <label htmlFor="1">
                              Member is not a fit for the community anymore
                            </label>
                          </div>
                          <div className="w-full space-x-2">
                            <input
                              type="radio"
                              name="reason"
                              id="2"
                              value="Member requested to be removed from the community"
                              onChange={handleReasonChange}
                            />
                            <label htmlFor="2">
                              Member requested to be removed from the community
                            </label>
                          </div>
                          <div className="w-full space-x-2">
                            <input
                              type="radio"
                              name="reason"
                              id="3"
                              value="other"
                              onChange={handleReasonChange}
                            />
                            <label htmlFor="3">Other</label>
                          </div>
                          {selectedReason === "other" && (
                            <div className="w-full mt-4">
                              <input
                                type="text"
                                placeholder="Please specify the reason"
                                value={otherReason}
                                onChange={handleOtherReasonChange}
                                className="create-community-input"
                              />
                            </div>
                          )}
                          <div className="w-full flex justify-between items-center gap-2">
                            <button
                              type="button"
                              className="secondaryButton mt-5"
                              onClick={() => setOpenRemoveMember(false)}
                            >
                              Cancel
                            </button>
                            <button
                              type="button"
                              className="primaryButton mt-5"
                              onClick={() => {
                                setShowRemoveMemberModal(true);
                                // handleSubmit(selectedMember._id);
                              }}
                              disabled={
                                selectedReason === "" ||
                                (selectedReason === "other" &&
                                  otherReason.trim() === "")
                              }
                            >
                              Submit
                            </button>
                          </div>
                        </div>
                        <div className="w-full bg-purple-100 mt-3 flex justify-center gap-2 px-5 py-5 items-center">
                          <p className="text-lg border-black border-2 rounded-full w-7 h-7  p-2 flex justify-center items-center text-center">
                            i
                          </p>
                          <p className="text-sm text-primaryBlack font-medium text-center flex-1">
                            {selectedReason === "other"
                              ? "This reason will be sent to the member after removing them from the community"
                              : "Member will be informed with the reason via email when they are removed."}
                          </p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
          {showRemoveMemberModal && selectedMember && (
            <Modal
              isOpen={showRemoveMemberModal}
              onClose={handleClose}
              width="90"
            >
              <div
                className="bg-white w-full max-w-lg p-3 relative  flex flex-col justify-start items-center gap-4 "
                onClick={(e) => e.stopPropagation()}
              >
                {!removalMessage && (
                  <h3 className="text-xl w-full font-medium leading-6 text-left">
                    Remove member from community?
                  </h3>
                )}
                {removalMessage ? (
                  <p>{removalMessage}</p>
                ) : (
                  <p className="text-sm text-gray-500">
                    This is a permanent action. The member will be removed and
                    lose all access to the community.
                  </p>
                )}
                {!removalMessage && (
                  <div className="w-full flex justify-between items-center gap-2 mt-6">
                    <button
                      type="button"
                      className="bg-gray-200 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-300 md:w-full"
                      onClick={handleClose}
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      className="bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-700 md:w-full "
                      onClick={() => handleSubmit(selectedMember._id)}
                    >
                      Remove Member
                    </button>
                  </div>
                )}
              </div>
            </Modal>
          )}
        </section>
      )}
    </Suspense>
  );
};

export default Members;
