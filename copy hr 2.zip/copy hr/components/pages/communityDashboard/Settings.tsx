"use client";
import { CommunityDetails } from "@/types/communityDetails.types";
import { User } from "@/types/user.types";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import React, { Dispatch, SetStateAction, Suspense, useEffect } from "react";
import CommunityUpdateForm from "./settingForms/CommunityUpdateForm";
import WhatsAppLinkDisplay from "./settingForms/WhatsAppLinkDisplay";
import WhatsAppLinkForm from "./WhatsAppLinkForm";
import CommunityMemberAccessForm from "./settingForms/CommunityMemberAccessForm";
type ChildComponentProps = {
  communityDetails?: CommunityDetails;
  loggedUserData?: User;
  setCommunityDetails: Dispatch<SetStateAction<CommunityDetails | undefined>>;
  setLoggedUserData: Dispatch<SetStateAction<User | undefined>>;
};

const Settings = ({
  communityDetails,
  loggedUserData,
  setCommunityDetails,
  setLoggedUserData,
}: ChildComponentProps) => {
  const searchParams = useSearchParams();

  const activeTab = searchParams.get("tab");

  return (
    <Suspense>
      <section className=" text-primaryBlack px-4">
        <div className="flex justify-between items-center  overflow-x-scroll no-scrollbar ">
          <Link
            href={`/portal/settings/${communityDetails?._id}?tab=public_page`}
            className={` p-4 basis-1/3 border-2 text-para border-white text-nowrap text-center  ${
              activeTab === "public_page" && "border-b-gold  text-primaryBlack"
            }`}
          >
            Public Page
          </Link>
          <Link
            href={`/portal/settings/${communityDetails?._id}?tab=member_access`}
            className={` p-4 border-2 basis-1/3 text-para border-white  text-nowrap  text-center ${
              activeTab === "member_access" && "border-b-gold text-primaryBlack"
            }`}
          >
            Member Access
          </Link>
          <Link
            href={`/portal/settings/${communityDetails?._id}?tab=chat`}
            className={` p-4 border-2 border-white  text-para basis-1/3  text-center ${
              activeTab === "chat" && "border-b-gold text-primaryBlack "
            }`}
          >
            Chat
          </Link>
        </div>
        <div>
          {activeTab === "public_page" &&
            communityDetails &&
            loggedUserData && (
              <div className="">
                <CommunityUpdateForm
                  community={communityDetails}
                  loggedUser={loggedUserData}
                  setCommunityDetails={setCommunityDetails}
                  setLoggedUserData={setLoggedUserData}
                />
              </div>
            )}
          {activeTab === "chat" && communityDetails && loggedUserData && (
            <div className="min-h-screen py-8">
              {communityDetails.whatsUpGroupLink ? (
                <WhatsAppLinkDisplay
                  whatsAppLink={communityDetails.whatsUpGroupLink}
                  communityId={communityDetails._id}
                  setCommunityDetails={setCommunityDetails}
                />
              ) : (
                <WhatsAppLinkForm
                  communityId={communityDetails._id}
                  setCommunityDetails={setCommunityDetails}
                />
              )}
            </div>
          )}
          {activeTab === "member_access" &&
            communityDetails &&
            loggedUserData && (
              <div className="min-h-screen py-8">
                <CommunityMemberAccessForm
                  community={communityDetails}
                  loggedUser={loggedUserData}
                  setCommunityDetails={setCommunityDetails}
                />
              </div>
            )}
        </div>
      </section>
    </Suspense>
  );
};

export default Settings;
