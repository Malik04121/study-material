"use client";
import React, { useEffect, useState } from "react";
import {
  useForm,
  SubmitHandler,
  useFieldArray,
  Controller,
} from "react-hook-form";
import { CommunityDetails } from "@/types/communityDetails.types";
import { User } from "@/types/user.types";
import axios from "axios";
import toast from "react-hot-toast";
import Modal from "@/components/reusable/Modal";
import Image from "next/image";
import dynamic from "next/dynamic";
import "react-quill/dist/quill.snow.css";
import { log } from "console";

const ReactQuill = dynamic(() => import("react-quill"), { ssr: false });

type Props = {
  community: CommunityDetails;
  loggedUser: User;
  setCommunityDetails: (details: CommunityDetails | undefined) => void;
};

type WelcomeMessageFormInputs = {
  welcomeMessageSubject: string;
  welcomeMessageContent: string;
};

type ApplicationField = {
  typeOfField: string;
  isRequired: boolean;
  labelName: string;
  options: string[];
};

type ApplicationFormValues = {
  applicationFields: ApplicationField[];
};

const CommunityMemberAccessForm: React.FC<Props> = ({
  community,
  loggedUser,
  setCommunityDetails,
}) => {
  const [isWelcomeMessageModalOpen, setIsWelcomeMessageModalOpen] =
    useState(false);
  const [isApplicationFormModalOpen, setIsApplicationFormModalOpen] =
    useState(false);
  const [isConfirmationModalOpen, setIsConfirmationModalOpen] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors, isValid },
    control,
    watch: watchMessage,
  } = useForm<WelcomeMessageFormInputs>({
    defaultValues: {
      welcomeMessageSubject: community.welcomeMessageSubject,
      welcomeMessageContent: community.welcomeMessageContent,
    },
  });
  console.log(watchMessage("welcomeMessageContent"));

  const {
    control: applicationControl,
    register: registerApplication,
    handleSubmit: handleApplicationSubmit,
    reset,
    watch,
    formState: {
      errors: applicationErrors,
      isValid: isApplicationFormValid,
      isDirty: isApplicationFormDirty,
    },
  } = useForm<ApplicationFormValues>({
    defaultValues: {
      applicationFields: community.applicationFields,
    },
  });

  const watchedFields = watch("applicationFields");

  const { fields, append, remove, update } = useFieldArray({
    control: applicationControl,
    name: "applicationFields",
  });

  const [loading, setLoading] = useState(false);

  const handleToggleAccess = async () => {
    try {
      const response = await axios.post("/api/community/toggle-access", {
        communityId: community._id,
        isAutoApproveMembership: !community.isAutoApproveMembership,
      });

      if (response.data.success) {
        setCommunityDetails(response.data.community);
        toast("Community mode has changed!", {
          icon: "✅",
          style: {
            backgroundColor: "white",
            color: "black",
          },
        });
      }
    } catch (error) {
      console.error("Error updating community access:", error);
    }
  };

  const handleToggleApplicationRequire = async () => {
    try {
      const response = await axios.post(
        "/api/community/toggle-application-require",
        {
          communityId: community._id,
          isApplicationRequire: !community.isApplicationRequire,
        }
      );

      if (response.data.success) {
        setCommunityDetails(response.data.community);
        toast("Application requirement updated successfully!", {
          icon: "✅",
          style: {
            backgroundColor: "white",
            color: "black",
          },
        });
      }
    } catch (error) {
      console.error("Error updating application requirement:", error);
    }
  };

  const onSubmit: SubmitHandler<WelcomeMessageFormInputs> = async (data) => {
    setLoading(true);
    try {
      console.log(data.welcomeMessageContent);

      const response = await axios.post(
        "/api/community/update-welcome-message",
        {
          communityId: community._id,
          welcomeMessageSubject: data.welcomeMessageSubject,
          welcomeMessageContent: data.welcomeMessageContent,
        }
      );

      if (response.data.success) {
        setCommunityDetails(response.data.community);
        setIsWelcomeMessageModalOpen(false);
        toast("Welcome message updated successfully!", {
          icon: "✅",
          style: {
            backgroundColor: "white",
            color: "black",
          },
        });
      }
    } catch (error) {
      console.error("Error updating welcome message:", error);
    } finally {
      setLoading(false);
    }
  };

  const onSubmitApplicationForm: SubmitHandler<ApplicationFormValues> = async (
    data
  ) => {
    setLoading(true);
    try {
      const response = await axios.post(
        "/api/community/update-application-fields",
        {
          communityId: community._id,
          applicationFields: data.applicationFields,
        }
      );

      if (response.data.success) {
        setCommunityDetails(response.data.community);
        console.log(response.data.community);

        setIsApplicationFormModalOpen(false);
        if (
          data.applicationFields.length > 0 &&
          community.isApplicationRequire === false
        ) {
          setIsConfirmationModalOpen(true);
        }
        toast("Application form updated successfully!", {
          icon: "✅",
          style: {
            backgroundColor: "white",
            color: "black",
          },
        });
      } else {
        toast(response.data.message, {
          icon: "❌",
          style: {
            backgroundColor: "white",
            color: "black",
          },
        });
      }
    } catch (error: any) {
      console.error("Error updating application form:", error);
      toast(
        error.response?.data?.message ||
          "An unexpected error occurred. Please try again later.",
        {
          icon: "❌",
          style: {
            backgroundColor: "white",
            color: "black",
          },
        }
      );
    } finally {
      setLoading(false);
    }
  };

  const handleOptionChange = (
    index: number,
    optionIndex: number,
    value: string
  ) => {
    const field = watchedFields[index];
    const options = field.options.slice();
    options[optionIndex] = value;
    update(index, { ...field, options });
  };

  const handleAddOption = (index: number) => {
    const field = watchedFields[index];
    const options = field.options.slice();
    options.push("");
    update(index, { ...field, options });
  };

  const handleRemoveOption = (index: number, optionIndex: number) => {
    const field = watchedFields[index];
    const options = field.options.slice();
    options.splice(optionIndex, 1);
    update(index, { ...field, options });
  };

  useEffect(() => {
    if (
      isWelcomeMessageModalOpen ||
      isApplicationFormModalOpen ||
      isConfirmationModalOpen
    ) {
      document.body.classList.add("no-scroll");
    } else {
      document.body.classList.remove("no-scroll");
    }
  }, [
    isWelcomeMessageModalOpen,
    isApplicationFormModalOpen,
    isConfirmationModalOpen,
  ]);

  return (
    <div className="flex flex-col justify-start items-start min-h-screen">
      <h2 className="text-xl font-medium mb-4">
        Choose how members access your community
      </h2>
      <div className="flex justify-between w-full mb-10 gap-4">
        <button
          className={`basis-[48%] border-[1px] border-para px-6 py-4 rounded-2xl hover:rounded-lg flex flex-col justify-between items-start gap-3 ${
            !community.isAutoApproveMembership &&
            "border-primaryBlack border-[3px]"
          }`}
          onClick={() =>
            community.isAutoApproveMembership && handleToggleAccess()
          }
          disabled={!community.isAutoApproveMembership}
        >
          <Image
            src={"/assets/icons/privacy.png"}
            alt="lock_icon"
            className=""
            width={25}
            height={25}
          />
          <p className="text-lg text-primaryBlack font-medium">Private</p>
          <p className="text-para w-full text-left">
            Community host manage membership
          </p>
        </button>
        <button
          className={`basis-[48%] border-[1px] border-para px-6 py-4 rounded-2xl hover:rounded-lg flex flex-col justify-start items-start gap-3 ${
            community.isAutoApproveMembership &&
            "border-primaryBlack border-[3px]"
          }`}
          onClick={() =>
            !community.isAutoApproveMembership && handleToggleAccess()
          }
          disabled={community.isAutoApproveMembership}
        >
          <Image
            src={"/assets/icons/public.png"}
            alt="lock_icon"
            className=""
            width={25}
            height={25}
          />
          <p className="text-lg text-primaryBlack font-medium">Public</p>
          <p className="text-para w-full text-left">Anyone can join for free</p>
        </button>
      </div>

      <hr className="w-full h-[0.5px] border-[1px] border-para mb-6" />
      <div className="flex flex-col w-full mb-10">
        <h3 className="text-lg font-normal mb-2">Welcome message</h3>
        <p className="text-para">
          Email sent to members immediately when they join your community
        </p>
        <div>
          <button
            className="border-2 px-4 py-2 rounded-2xl bg-primaryBlack text-white mt-4"
            onClick={() => setIsWelcomeMessageModalOpen(true)}
          >
            Edit Welcome Email
          </button>
        </div>
      </div>
      <Modal
        isOpen={isWelcomeMessageModalOpen}
        onClose={() => setIsWelcomeMessageModalOpen(false)}
        width="90"
      >
        <form onSubmit={handleSubmit(onSubmit)}>
          <h2 className="text-lg font-medium mb-4">Welcome Email</h2>
          <label className="block text-base font-medium text-gray-700 mb-2">
            Subject
          </label>
          <input
            type="text"
            className="create-community-input mb-4"
            {...register("welcomeMessageSubject", {
              required: "Subject is required",
            })}
            maxLength={150}
          />
          {errors.welcomeMessageSubject && (
            <p className="text-red-500 text-sm text-sm mb-4">
              {errors.welcomeMessageSubject.message}
            </p>
          )}
          <label className="block text-base font-medium text-gray-700 mb-2">
            Body
          </label>
          <Controller
            name="welcomeMessageContent"
            control={control}
            rules={{ required: "Content is required" }}
            render={({ field }) => (
              <ReactQuill
                {...field}
                className="create-community-input mb-4"
                theme="snow"
              />
            )}
          />
          {errors.welcomeMessageContent && (
            <p className="text-red-500 text-sm text-sm mb-4">
              {errors.welcomeMessageContent.message}
            </p>
          )}
          <p className="text-sm text-gray-600 mb-4">
            For adding variables type the following:
            <br />• {`{name}`} for Member name
            <br />• {`{community_name}`} for Community name
          </p>
          <div className="flex justify-between items-center gap-4">
            <button
              className="secondaryButton mt-5"
              type="button"
              onClick={() => setIsWelcomeMessageModalOpen(false)}
            >
              Cancel
            </button>
            <button
              className="primaryButton"
              type="submit"
              disabled={loading || !isValid}
            >
              {loading ? "Saving..." : "Save"}
            </button>
          </div>
        </form>
      </Modal>
      <div className="flex flex-col w-full mb-6">
        <div className="flex justify-between ">
          <div>
            <h3 className="text-lg font-normal mb-2">Require Application</h3>
          </div>
          {community.applicationFields.length > 0 && (
            <div className="flex items-center">
              <label className="relative inline-flex items-center cursor-pointer disabled:cursor-not-allowed">
                <input
                  type="checkbox"
                  checked={community.isApplicationRequire}
                  onChange={handleToggleApplicationRequire}
                  className="sr-only peer "
                />
                <div className="w-11 h-6 bg-gray-200 rounded-full peer-focus:outline-none peer-focus:ring-0 dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-500"></div>
              </label>
            </div>
          )}
        </div>
        <p className="text-para">
          Members who apply to join your community are required to fill up this
          application form
        </p>
        <div className="flex justify-between items-center py-2">
          <button
            className="border-2 px-4 py-2 rounded-2xl bg-primaryBlack text-white mt-4"
            onClick={() => setIsApplicationFormModalOpen(true)}
          >
            Edit Application
          </button>
        </div>
      </div>
      <Modal
        isOpen={isApplicationFormModalOpen}
        onClose={() => setIsApplicationFormModalOpen(false)}
        width="90"
        isCloseRequire={false}
      >
        <form onSubmit={handleApplicationSubmit(onSubmitApplicationForm)}>
          <h2 className="text-lg font-medium mb-4">Application Form</h2>
          <div className="bg-white rounded-lg shadow-2xl w-full px-5 mb-7">
            <p className="font-medium text-lg">Required</p>
            {["Email", "Full name", "Mobile Number (WhatsApp)"].map((label) => (
              <div
                key={label}
                className="flex justify-between items-center py-2"
              >
                <p>{label}</p>
                <div className="flex items-center">
                  <label className="relative inline-flex items-center cursor-not-allowed">
                    <input
                      type="checkbox"
                      checked
                      className="sr-only peer"
                      readOnly
                    />
                    <div className="w-11 h-6 bg-gray-200 rounded-full peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-500"></div>
                  </label>
                </div>
              </div>
            ))}
          </div>
          <div>
            {fields.map((field, index) => {
              const fieldType = watchedFields?.[index]?.typeOfField;
              return (
                <div
                  key={field.id}
                  className="bg-white rounded-lg shadow-2xl w-full px-5 mb-3"
                >
                  <div className="flex justify-between items-center py-2">
                    <div className="flex items-center gap-2">
                      <select
                        {...registerApplication(
                          `applicationFields.${index}.typeOfField`
                        )}
                        className="w-full py-1 px-1 border-[#E9E9E9] border-[1px] rounded-lg text-base placeholder:text-[#767676] placeholder:text-sm outline-none focus:border-primaryBlack font-normal text-primaryBlack leading-5 mb-2"
                      >
                        <option value="text">Text</option>
                        <option value="number">Number</option>
                        <option value="single-select">Single Select</option>
                        <option value="multi-select">Multi Select</option>
                        <option value="url">URL</option>
                      </select>
                    </div>
                    <div className="flex items-center gap-2">
                      <label className="flex items-center text-base font-normal text-gray-700">
                        Required
                        <input
                          type="checkbox"
                          {...registerApplication(
                            `applicationFields.${index}.isRequired`
                          )}
                          className="ml-2"
                        />
                      </label>
                      <button
                        type="button"
                        onClick={() => remove(index)}
                        className="text-red-500 text-sm"
                      >
                        <Image
                          src={"/assets/icons/bin.png"}
                          alt="bin_icon"
                          width={15}
                          height={15}
                        />
                      </button>
                    </div>
                  </div>
                  <input
                    {...registerApplication(
                      `applicationFields.${index}.labelName`,
                      { required: true }
                    )}
                    className="create-community-input mb-2"
                    placeholder="Enter label"
                  />
                  {applicationErrors.applicationFields?.[index]?.labelName && (
                    <p className="text-red-500  text-sm mb-2">
                      {
                        applicationErrors.applicationFields?.[index]?.labelName
                          ?.message
                      }
                    </p>
                  )}
                  {(fieldType === "single-select" ||
                    fieldType === "multi-select") && (
                    <>
                      <div>
                        {field.options?.map((option, optionIndex) => (
                          <div
                            key={optionIndex}
                            className="flex items-center gap-2 mb-2"
                          >
                            <input
                              type="text"
                              defaultValue={option}
                              onBlur={(e) =>
                                handleOptionChange(
                                  index,
                                  optionIndex,
                                  e.target.value
                                )
                              }
                              className="create-community-input"
                            />
                            <button
                              type="button"
                              onClick={() =>
                                handleRemoveOption(index, optionIndex)
                              }
                              className="text-red-500 text-sm"
                            >
                              <Image
                                src={"/assets/icons/bin.png"}
                                alt="bin_icon"
                                width={15}
                                height={15}
                              />
                            </button>
                          </div>
                        ))}
                      </div>
                      <button
                        type="button"
                        onClick={() => handleAddOption(index)}
                        className="primaryButton text-nowrap mb-2"
                      >
                        Add Option
                      </button>
                    </>
                  )}
                </div>
              );
            })}
          </div>
          <div className="w-[30%] min-w-[150px]">
            <button
              type="button"
              onClick={() =>
                append({
                  typeOfField: "text",
                  isRequired: false,
                  labelName: "",
                  options: [],
                })
              }
              className="primaryButton text-nowrap"
            >
              Add Question
            </button>
          </div>
          <div className="flex justify-between items-center gap-4 mt-4">
            <button
              className="secondaryButton mt-5"
              type="button"
              onClick={() => {
                reset();
                setIsApplicationFormModalOpen(false);
              }}
            >
              Cancel
            </button>
            <button
              className="primaryButton"
              type="submit"
              disabled={
                loading || !isApplicationFormValid || !isApplicationFormDirty
              }
            >
              {loading ? "Saving..." : "Save"}
            </button>
          </div>
        </form>
      </Modal>
      <Modal
        isOpen={isConfirmationModalOpen}
        onClose={() => setIsConfirmationModalOpen(false)}
        width="80"
        isCloseRequire={false}
      >
        <h2 className="text-lg font-medium mb-4">
          Application Form Successfully Updated
        </h2>
        <p className="text-base mb-6">
          Do you want new members to be required to submit this form when
          joining the community?
        </p>
        <div className="flex justify-between items-center gap-4">
          <button
            className="secondaryButton mt-5"
            type="button"
            onClick={() => setIsConfirmationModalOpen(false)}
          >
            Cancel
          </button>
          <button
            className="primaryButton"
            type="button"
            onClick={async () => {
              await handleToggleApplicationRequire();
              setIsConfirmationModalOpen(false);
            }}
          >
            Yes, required
          </button>
        </div>
      </Modal>
    </div>
  );
};

export default CommunityMemberAccessForm;
