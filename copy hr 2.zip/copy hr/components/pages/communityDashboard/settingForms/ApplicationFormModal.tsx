"use client";
import { CommunityDetails } from "@/types/communityDetails.types";
import React, { Dispatch, SetStateAction } from "react";
import { useForm, useFieldArray, SubmitHandler } from "react-hook-form";
import axios from "axios";
import toast from "react-hot-toast";

type Props = {
  community: CommunityDetails;
  setCommunityDetails: Dispatch<SetStateAction<CommunityDetails | undefined>>;
  onClose: () => void;
};

type ApplicationField = {
  typeOfField: string;
  isRequired: boolean;
  labelName: string;
};

type FormValues = {
  applicationFields: ApplicationField[];
};

const ApplicationFormModal: React.FC<Props> = ({
  community,
  setCommunityDetails,
  onClose,
}) => {
  const { register, control, handleSubmit } = useForm<FormValues>({
    defaultValues: {
      applicationFields: community.applicationFields || [],
    },
  });

  const { fields, append, remove } = useFieldArray({
    control,
    name: "applicationFields",
  });

  const onSubmit: SubmitHandler<FormValues> = async (data) => {
    try {
      const response = await axios.post(
        "/api/community/update-application-fields",
        {
          communityId: community._id,
          applicationFields: data.applicationFields,
        }
      );

      if (response.data.success) {
        setCommunityDetails(response.data.community);
        toast.success("Application form updated successfully!");
        onClose();
      }
    } catch (error) {
      console.error("Error updating application fields:", error);
      toast.error("Failed to update application form.");
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <h2 className="text-xl font-bold">Application Form</h2>
      <p>{fields.length} questions</p>
      {fields.map((field, index) => (
        <div key={field.id} className="border p-4 rounded space-y-2">
          <div>
            <label>Field Type</label>
            <select
              {...register(`applicationFields.${index}.typeOfField` as const)}
              className="create-community-input"
            >
              <option value="Text">Text</option>
              <option value="Number">Number</option>
              <option value="Single Select">Single Select</option>
              <option value="Multi Select">Multi Select</option>
              <option value="URL">URL</option>
            </select>
          </div>
          <div>
            <label>Label</label>
            <input
              {...register(`applicationFields.${index}.labelName` as const, {
                required: true,
              })}
              className="create-community-input"
              placeholder="Enter label"
            />
          </div>
          <div>
            <label>Required</label>
            <input
              type="checkbox"
              {...register(`applicationFields.${index}.isRequired` as const)}
            />
          </div>
          <button
            type="button"
            onClick={() => remove(index)}
            className="secondaryButton"
          >
            Delete
          </button>
        </div>
      ))}
      <button
        type="button"
        onClick={() =>
          append({ typeOfField: "Text", isRequired: false, labelName: "" })
        }
        className="primaryButton"
      >
        Add Question
      </button>
      <div className="flex justify-end space-x-4">
        <button type="button" onClick={onClose} className="secondaryButton">
          Cancel
        </button>
        <button type="submit" className="primaryButton">
          Save
        </button>
      </div>
    </form>
  );
};

export default ApplicationFormModal;
