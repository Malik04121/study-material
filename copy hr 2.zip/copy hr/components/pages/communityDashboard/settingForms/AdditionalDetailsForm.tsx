"use client";
import React, { useState } from "react";
import { useForm, SubmitHandler, Controller } from "react-hook-form";
import { CommunityDetails } from "@/types/communityDetails.types";
import { useRouter } from "next/navigation";
import toast from "react-hot-toast";
import axios from "axios";
import Image from "next/image";
import Select, { SingleValue, MultiValue } from "react-select";
import { User } from "@/types/user.types";

interface AdditionalDetailsFormProps {
  communityDetails: CommunityDetails;
  loggedUserData: User;
}

interface AdditionalFields {
  [key: string]: any;
}

interface OptionType {
  value: string;
  label: string;
}

const AdditionalDetailsForm: React.FC<AdditionalDetailsFormProps> = ({
  communityDetails,
  loggedUserData,
}) => {
  const {
    register,
    handleSubmit,
    formState: { errors, isValid, isDirty },
    watch,
    setValue,
    control,
  } = useForm<AdditionalFields>({ mode: "onChange" });
  const router = useRouter();
  const [loading, setLoading] = useState<boolean>(false);

  const updateMembership = async (
    isApprovedMember: boolean,
    isRejectedMember: boolean,
    newMemberId: string,
    userId: string
  ) => {
    try {
      console.log(communityDetails, newMemberId);
      console.log(isApprovedMember, isRejectedMember);
      setLoading(true);
      const response = await axios.post("/api/community/update-membership", {
        communityId: communityDetails?._id,
        memberId: newMemberId,
        userId: userId,
        isApprovedMember,
        isRejectedMember,
      });
      if (response.data) {
        window.location.reload();
      }
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const onSubmit: SubmitHandler<AdditionalFields> = async (data) => {
    try {
      const response = await axios.post(
        "/api/community/submit-additional-details",
        {
          communityId: communityDetails._id,
          additionalDetails: data,
          userId: loggedUserData._id,
        }
      );
      if (response.status === 200) {
        console.log(response.data);

        if (communityDetails.isAutoApproveMembership) {
          await updateMembership(
            true,
            false,
            response.data.member._id,
            loggedUserData._id
          );
        } else {
          await updateMembership(
            false,
            false,
            response.data.member._id,
            loggedUserData._id
          );
        }
      } else {
        console.log("Unexpected status code:", response.status);
      }
    } catch (error) {
      console.error(error);
      toast("Error submitting additional details", {
        icon: "❌",
        style: { backgroundColor: "#454545", color: "white" },
      });
    }
  };

  return (
    <div
      className="bg-white w-full p-4 rounded-t-3xl relative border overflow-y-scroll max-h-[90vh]"
      onClick={(e) => e.stopPropagation()}
    >
      <form
        onSubmit={handleSubmit(onSubmit)}
        className="flex flex-col justify-between items-center gap-2 w-full"
      >
        <div className="w-16 h-16 overflow-hidden rounded-lg">
          <Image
            src={communityDetails.logoImage}
            alt="logo"
            width={50}
            height={50}
            className="h-full w-full object-cover"
          />
        </div>
        <h3 className="font-semibold text-2xl">{communityDetails.title}</h3>
        <p className="text-gray-500 text-sm">
          {communityDetails.approvedMembers.length} Members
        </p>
        {communityDetails.applicationFields.map((field, index) => (
          <div key={index} className="w-full">
            <label htmlFor={field.labelName} className="form-label">
              {field.labelName}
              {field.isRequired && "*"}
            </label>
            {field.typeOfField === "text" && (
              <input
                type="text"
                {...register(field.labelName, {
                  required: field.isRequired
                    ? `${field.labelName} is required`
                    : false,
                })}
                placeholder={field.labelName}
                className="create-community-input"
              />
            )}
            {field.typeOfField === "number" && (
              <input
                type="number"
                {...register(field.labelName, {
                  required: field.isRequired
                    ? `${field.labelName} is required`
                    : false,
                  validate: (value) => {
                    if (isNaN(value)) {
                      return `${field.labelName} must be a number`;
                    }
                    if (/[^0-9]/.test(value)) {
                      return `${field.labelName} cannot contain special characters or alphabets`;
                    }
                    return true;
                  },
                })}
                placeholder={field.labelName}
                className="create-community-input"
              />
            )}

            {field.typeOfField === "single-select" && (
              <Controller
                name={field.labelName}
                control={control}
                rules={{
                  required: field.isRequired
                    ? `${field.labelName} is required`
                    : false,
                }}
                render={({
                  field: { onChange, value },
                  fieldState: { error },
                }) => (
                  <>
                    <Select
                      options={field.options?.map((option) => ({
                        value: option,
                        label: option,
                      }))}
                      value={field.options
                        ?.map((option) => ({ value: option, label: option }))
                        .find((option) => option.value === value)}
                      onChange={(selectedOption: SingleValue<OptionType>) =>
                        onChange(selectedOption?.value)
                      }
                      className="create-community-input"
                      placeholder={`Select ${field.labelName}`}
                    />
                    {error && (
                      <p className="text-red-500 text-sm">{error.message}</p>
                    )}
                  </>
                )}
              />
            )}
            {field.typeOfField === "multi-select" && (
              <Controller
                name={field.labelName}
                control={control}
                rules={{
                  required: field.isRequired
                    ? `${field.labelName} is required`
                    : false,
                }}
                render={({
                  field: { onChange, value },
                  fieldState: { error },
                }) => (
                  <>
                    <Select
                      options={field.options?.map((option) => ({
                        value: option,
                        label: option,
                      }))}
                      isMulti
                      value={field.options
                        ?.map((option) => ({ value: option, label: option }))
                        .filter((option) => value?.includes(option.value))}
                      onChange={(selectedOptions: MultiValue<OptionType>) =>
                        onChange(
                          selectedOptions
                            ? selectedOptions.map((option) => option.value)
                            : []
                        )
                      }
                      className="create-community-input"
                      placeholder={`Select ${field.labelName}`}
                    />
                    {error && (
                      <p className="text-red-500 text-sm">{error.message}</p>
                    )}
                  </>
                )}
              />
            )}
            {field.typeOfField === "url" && (
              <input
                type="url"
                {...register(field.labelName, {
                  required: field.isRequired
                    ? `${field.labelName} is required`
                    : false,
                })}
                placeholder={field.labelName}
                className="create-community-input"
              />
            )}
            {errors[field.labelName] && (
              <p className="text-red-500 text-sm">
                {(errors[field.labelName]?.message as string) ||
                  "This field is required"}
              </p>
            )}
          </div>
        ))}
        <div className="flex items-center bg-gray-100 text-primaryBlack space-x-1 rounded-md p-2 py-1 text-sm mt-4 w-full">
          <Image
            src={"/assets/icons/check.png"}
            alt="verified_icon"
            width={15}
            height={15}
          />
          <p> You can access the community upon approval.</p>
        </div>

        <button
          type="submit"
          disabled={(!isValid && isDirty) || loading}
          className="primaryButton"
        >
          {loading ? "Loading " : " Apply now"}
        </button>
      </form>
    </div>
  );
};

export default AdditionalDetailsForm;
