"use client";

import { CommunityDetails } from "@/types/communityDetails.types";
import { User } from "@/types/user.types";
import axios from "axios";
import Image from "next/image";
import Link from "next/link";
import { notFound, useRouter } from "next/navigation";
import React, {
  useEffect,
  useState,
  useRef,
  Dispatch,
  SetStateAction,
} from "react";
import { SubmitHandler, useForm } from "react-hook-form";
import toast, { Toaster } from "react-hot-toast";
import EditCoverImageModal from "@/components/modal/EditCoverImageModal"; // Ensure the path is correct

type Props = {
  community: CommunityDetails;
  loggedUser: User;
  setCommunityDetails: Dispatch<SetStateAction<CommunityDetails | undefined>>;
  setLoggedUserData: Dispatch<SetStateAction<User | undefined>>;
};

interface IFormInputs {
  title: string;
  description: string;
  hostName: string;
}

const CommunityUpdateForm = (props: Props) => {
  const { community, loggedUser, setCommunityDetails, setLoggedUserData } =
    props;
  const [editedPublicUrl, setEditedPublicUrl] = useState(
    decodeURIComponent(community.publicPageUrl)
  );
  const [copySuccess, setCopySuccess] = useState(false);
  const [showToOpenURl, setShowToOpenURl] = useState(true);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const coverFileInputRef = useRef<HTMLInputElement>(null);
  const [isLogoUploading, setIsLogoUploading] = useState<boolean>(false);
  const [isCoverUploading, setIsCoverUploading] = useState<boolean>(false);
  const [isEditCoverImageModalOpen, setIsEditCoverImageModalOpen] =
    useState<boolean>(false); // State for edit cover image modal

  const router = useRouter();

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    let value = event.target.value;
    value = value.replace(/[^a-zA-Z0-9 -]/g, "");
    setEditedPublicUrl(value);
    setShowToOpenURl(false);
    if (value === community.publicPageUrl) {
      setShowToOpenURl(true);
    }
  };

  const handleCancelEdit = () => {
    setEditedPublicUrl(decodeURIComponent(community.publicPageUrl)); // Reset to original value
  };

  const handleSave = async () => {
    try {
      let memberId = "";
      try {
        let response = await axios.post("/api/users/me", {
          publicUrl: decodeURIComponent(community.publicPageUrl),
        });
        memberId = response.data.data.memberId;
        if (response.status) {
          response = await axios.put("/api/community", {
            newPublicUrl: editedPublicUrl,
            publicUrl: decodeURIComponent(community.publicPageUrl),
            memberId,
          });
          if (response.status === 200) {
            toast("Community public page URL updated successfully!", {
              icon: "✅",
              style: { backgroundColor: "white", color: "black" },
            });
            setCommunityDetails(() => {
              return {
                ...community,
                publicPageUrl: response.data.community.publicPageUrl,
              };
            });
            setEditedPublicUrl(response.data.community.publicPageUrl);
            setShowToOpenURl(true);
          } else if (response.status === 201) {
            toast("Community Url already exists!", {
              icon: "❌",
              style: { backgroundColor: "white", color: "black" },
            });
          } else if (response.status === 404) {
            toast("Community not exist!", {
              icon: "❌",
              style: { backgroundColor: "white", color: "black" },
            });
            notFound();
          }
        }
      } catch (error) {
        console.error(error);
        if (axios.isAxiosError(error)) {
          if (error.response?.status === 404) {
            toast("Community doesn't exist!", {
              icon: "🚫",
              style: { backgroundColor: "white", color: "black" },
            });
            notFound();
          }
        }
        toast("You are unauthorized", {
          icon: "🚫",
          style: { backgroundColor: "white", color: "black" },
        });
        router.push("/unauthorized");
      }
    } catch (error) {
      console.error(error);
      if (axios.isAxiosError(error)) {
        if (error.response?.status === 401) {
          toast("You are unauthorized", {
            icon: "🚫",
            style: { backgroundColor: "white", color: "black" },
          });
          router.push("/unauthorized");
        }
      }
    }
  };

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(
        process.env.NEXT_PUBLIC_DOMAIN_NAME + "/" + community.publicPageUrl
      );
      setCopySuccess(true);
    } catch (err) {
      console.error("Failed to copy:", err);
    }
  };

  const handleEditImageClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const handleEditCoverImageClick = () => {
    setIsEditCoverImageModalOpen(true); // Open the edit cover image modal
  };

  const handleFileChange = async (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = event.target.files?.[0];
    if (file) {
      const validImageTypes = [
        "image/jpeg",
        "image/png",
        "image/gif",
        "image/webp",
      ];
      if (!validImageTypes.includes(file.type)) {
        toast.error(
          "Please upload a valid image file (JPEG, PNG, GIF, or WEBP)"
        );
        return;
      }
      setIsLogoUploading(true);
      try {
        const url = await getSignedUrl(file);
        await uploadImageToS3(url, file);
        const updatedCommunity = await updateCommunityLogoImage(
          url.split("?")[0],
          true
        );
        console.log(updatedCommunity);
        console.log(loggedUser);

        setCommunityDetails(updatedCommunity);
        const index = loggedUser.communityDetails.findIndex(
          (communitydetail) => {
            return communitydetail.communityId === updatedCommunity._id;
          }
        );
        console.log(index);
        let newCommunityArr = loggedUser.communityDetails;
        newCommunityArr[index].logoImage = updatedCommunity.logoImage;
        setLoggedUserData(() => {
          return { ...loggedUser, communityDetails: newCommunityArr };
        });
      } catch (error) {
        console.error("Error uploading image:", error);
      } finally {
        setIsLogoUploading(false);
      }
    }
  };

  const handleFileCoverChange = async (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = event.target.files?.[0];
    if (file) {
      const validImageTypes = [
        "image/jpeg",
        "image/png",
        "image/gif",
        "image/webp",
      ];
      if (!validImageTypes.includes(file.type)) {
        toast.error(
          "Please upload a valid image file (JPEG, PNG, GIF, or WEBP)"
        );
        return;
      }
      setIsCoverUploading(true);
      setIsEditCoverImageModalOpen(false);
      try {
        const url = await getSignedUrl(file);
        await uploadImageToS3(url, file);
        const updatedCommunity = await updateCommunityLogoImage(
          url.split("?")[0],
          false
        );
        setCommunityDetails(updatedCommunity);
      } catch (error) {
        console.error("Error uploading image:", error);
      } finally {
        setIsCoverUploading(false);
      }
    }
  };

  const getSignedUrl = async (file: File): Promise<string> => {
    const response = await axios.post("/api/aws/get-signed-url", {
      fileName: file.name,
      fileType: file.type,
    });
    return response.data.uploadUrl;
  };

  const uploadImageToS3 = async (url: string, file: File) => {
    try {
      await axios.put(url, file, {
        headers: { "Content-Type": file.type },
      });
    } catch (error) {
      console.error(error);
    }
  };

  const updateCommunityLogoImage = async (
    imageUrl: string,
    isLogo: boolean
  ) => {
    try {
      const response = await axios.put("/api/community/update-logo", {
        imageUrl,
        communityID: community._id,
        isLogo,
      });
      return response.data.community;
    } catch (error) {
      console.error("you are unauthorized", error);
    }
  };

  const handleSelectGalleryImage = async (url: string) => {
    const updatedCommunity = await updateCommunityLogoImage(
      url.split("?")[0],
      false
    );

    setCommunityDetails(updatedCommunity);
    // setCommunityDetails((prev) => {
    //   if (!prev) return prev;
    //   return {
    //     ...prev,
    //     coverImage: url,
    //   };
    // });
    setIsEditCoverImageModalOpen(false);
  };

  useEffect(() => {
    if (copySuccess) {
      toast("Link copied to clipboard!", {
        icon: "👍",
        style: { backgroundColor: "black", color: "white" },
      });
      setCopySuccess(false);
    }
  }, [copySuccess]);

  const validateTitle = (value: string): string | boolean => {
    if (!/^[A-Za-z0-9 ]*$/.test(value)) {
      return "Title can only contain letters, numbers, and spaces";
    }
    if (value.trim().length < 3) {
      return "Title must have at least 3 characters";
    }
    if (!/[A-Za-z0-9]/.test(value)) {
      return "Title must contain at least one letter or number";
    }
    return true;
  };

  const validateHostName = (value: string): string | boolean => {
    if (!/^[A-Za-z0-9 ]*$/.test(value)) {
      return "Host name can only contain letters, numbers, and spaces";
    }
    if (value.trim().length < 3) {
      return "Host name must have at least 3 characters";
    }
    if (!/[A-Za-z0-9]/.test(value)) {
      return "Host name must contain at least one letter or number";
    }
    return true;
  };

  const {
    register,
    handleSubmit,
    reset,
    setValue,
    formState: { errors, isDirty },
  } = useForm<IFormInputs>({
    mode: "onChange",
    defaultValues: {
      description: community?.description,
      hostName: community?.hostName,
      title: community.title,
    },
  });

  const handleReset = () => {
    reset({
      description: community?.description,
      hostName: community?.hostName,
      title: community.title,
    });
  };

  const onSubmit: SubmitHandler<IFormInputs> = async (data) => {
    try {
      const response = await axios.put(`/api/community/update-details`, {
        communityID: community._id,
        title: data.title,
        description: data.description,
        hostName: data.hostName,
      });
      if (response.data) {
        toast("Community Details updated successfully!", {
          icon: "✅",
          style: { backgroundColor: "black", color: "white" },
        });
        setCommunityDetails(response.data.community);
        reset({
          description: response.data.community?.description,
          hostName: response.data.community?.hostName,
          title: response.data.community.title,
        });
      }
    } catch (error) {
      console.error(error);
    }
  };
  useEffect(() => {
    if (isEditCoverImageModalOpen) {
      document.body.classList.add("no-scroll");
    } else {
      document.body.classList.remove("no-scroll");
    }
  }, [isEditCoverImageModalOpen]);

  return (
    <div className="flex flex-col justify-between items-center w-full gap-7 py-8">
      <p className="text-sm font-normal text-para w-full">
        This page shows all information about your community, you can edit URL,
        Community DP, Cover Photo, Title, Description, etc. from here.
      </p>

      <div className="w-full">
        <div className="w-full">
          <label
            htmlFor="pageUrl"
            className=" w-full text-sm text-left font-normal "
          >
            Community Page URL
          </label>
          <div className="space-y-5">
            <input
              type="text"
              id="pageUrl"
              value={editedPublicUrl}
              onChange={handleChange}
              className="create-community-input"
            />
            {!showToOpenURl ? (
              <div className="flex justify-start items-stretch gap-2">
                <button
                  type="button"
                  onClick={handleCancelEdit}
                  className="text-sm px-5 py-2 text-black bg-white border border-primaryBlack rounded-3xl disabled:bg-opacity-50"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleSave}
                  className="text-sm px-5 py-2 text-white bg-primaryBlack  rounded-3xl disabled:bg-opacity-50"
                >
                  Save
                </button>
              </div>
            ) : (
              <div className="flex flex-col gap-2 justify-between items-start">
                <button
                  type="button"
                  onClick={copyToClipboard}
                  className="text-para"
                >
                  Tap to copy link
                </button>
                <Link
                  href={
                    process.env.NEXT_PUBLIC_DOMAIN_NAME +
                    "/" +
                    community.publicPageUrl
                  }
                  target="_blank"
                  className="inline-flex  justify-start gap-2 items-center bg-primaryBlack text-white p-2 px-3 rounded-3xl"
                >
                  <p>Open</p>
                  <Image
                    src={"/assets/icons/link_icon.png"}
                    alt="link_icon"
                    width={20}
                    height={20}
                  />
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>

      <hr className="border h-[1px] border-para w-full " />
      <div className="flex flex-col justify-between items-start w-full gap-2">
        <p className="w-full text-base text-left font-normal ">Community DP</p>
        <div className="relative w-28 h-28">
          <Image
            src={community.logoImage}
            alt="profile_photo"
            layout="fill"
            className="object-cover object-center rounded-xl"
          />

          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            className="hidden"
            accept="image/*"
          />
          {isLogoUploading && (
            <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center rounded-xl">
              <p className="text-white">Uploading...</p>
            </div>
          )}
        </div>

        <div>
          <button
            type="button"
            onClick={handleEditImageClick}
            className="text-sm px-5 py-2 text-black bg-white border rounded-3xl disabled:bg-opacity-50"
          >
            Change the Image
          </button>
        </div>
      </div>
      <hr className="border h-[1px] border-para w-full " />

      <form
        onSubmit={handleSubmit(onSubmit)}
        className="flex flex-col justify-between items-center w-full gap-4"
      >
        <div className="w-full flex flex-col justify-between items-start gap-1">
          <label>Title*</label>
          <input
            {...register("title", {
              required: "Title is required",
              validate: validateTitle,
            })}
            className="update-community-input"
            placeholder="Enter community title"
          />
          {errors.title && (
            <p className="text-sm text-red-500 text-sm">
              {errors.title.message}
            </p>
          )}
        </div>
        <div className="w-full flex flex-col justify-between items-start gap-1">
          <label>Host Name*</label>
          <input
            {...register("hostName", {
              required: "Host name is required",
              validate: validateHostName,
            })}
            placeholder="Add host name"
            className="update-community-input"
            onChange={(e) => {
              let value = e.target.value
                .replace(/[^a-zA-Z\s]/g, "") // Remove non-letter and non-space characters
                .replace(/\b\w/g, (char) => char.toUpperCase()); // Capitalize the first letter of each word
              value = value.charAt(0).toUpperCase() + value.slice(1); // Ensure the first character is uppercase
              setValue("hostName", value, {
                shouldValidate: true,
                shouldDirty: true,
              });
            }}
          />
          {errors.hostName && (
            <p className="text-sm text-red-500 text-sm">
              {errors.hostName.message}
            </p>
          )}
        </div>
        <div className="w-full flex flex-col justify-between items-start gap-1">
          <label>Description</label>
          <textarea
            {...register("description", {
              maxLength: {
                value: 200,
                message: "Description cannot be longer than 200 characters",
              },
            })}
            rows={8}
            placeholder="Add description"
            className="update-community-input"
          />
          {errors.description && (
            <p className="text-sm text-red-500 text-sm">
              {errors.description.message}
            </p>
          )}
        </div>

        {isDirty && (
          <div className="space-x-2">
            <button
              type="button"
              onClick={() => {
                handleReset();

                // reset({}, { keepDirty: false, keepValues: true });
              }}
              className="text-sm px-5 py-3 text-primaryBlack bg-white border  rounded-3xl disabled:bg-opacity-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="text-sm px-5 py-3 text-white bg-primaryBlack  rounded-3xl disabled:bg-opacity-50"
            >
              Update Community
            </button>
          </div>
        )}
      </form>

      <hr className="border h-[1px] border-para w-full " />

      <div className="flex flex-col justify-between items-start w-full gap-2">
        <p className="w-full text-base text-left font-normal ">Cover photo</p>
        <p className="w-full text-xs text-left text-gray-500">
          Recommended dimensions: 1024 x 768 pixels and less than 10 MB.
        </p>
        <div className="relative w-full h-60 overflow-clip">
          <Image
            src={community.coverImage}
            alt="profile_photo"
            width={800}
            height={110}
            className="w-full h-60 object-cover rounded-xl"
          />

          <input
            type="file"
            ref={coverFileInputRef}
            onChange={handleFileCoverChange}
            className="hidden"
            accept="image/*"
          />
          <button
            type="button"
            onClick={handleEditCoverImageClick}
            className="absolute right-5 bottom-5 text-sm px-5 py-2 text-black bg-white border rounded-3xl disabled:bg-opacity-50"
          >
            Change the Image
          </button>
          {isCoverUploading && (
            <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center rounded-xl">
              <p className="text-white">Uploading...</p>
            </div>
          )}
        </div>
      </div>
      {isEditCoverImageModalOpen && (
        <EditCoverImageModal
          isOpen={isEditCoverImageModalOpen}
          onClose={() => setIsEditCoverImageModalOpen(false)}
          onFileChange={handleFileCoverChange}
          onDelete={() =>
            handleSelectGalleryImage(
              "https://hr-network-assets.s3.ap-south-1.amazonaws.com/event-cover-image-1.png"
            )
          } // Default cover image
          galleryImages={[
            "https://hr-network-assets.s3.ap-south-1.amazonaws.com/event-cover-image-2.png",
            "https://hr-network-assets.s3.ap-south-1.amazonaws.com/event-cover-image-3.png",
            "https://hr-network-assets.s3.ap-south-1.amazonaws.com/event-cover-image-4.png",
            "https://hr-network-assets.s3.ap-south-1.amazonaws.com/event-cover-image-4.png",
            "https://hr-network-assets.s3.ap-south-1.amazonaws.com/event-cover-image-5.png",
            "https://hr-network-assets.s3.ap-south-1.amazonaws.com/event-cover-image-6.png",
            "https://hr-network-assets.s3.ap-south-1.amazonaws.com/event-cover-image-7.png",
            "https://hr-network-assets.s3.ap-south-1.amazonaws.com/event-cover-image-8.png",
          ]}
          onSelectGalleryImage={handleSelectGalleryImage}
        />
      )}
    </div>
  );
};

export default CommunityUpdateForm;
