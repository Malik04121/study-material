import React from "react";
import axios from "axios";
import toast from "react-hot-toast";
import Link from "next/link";
import Image from "next/image";

interface WhatsAppLinkDisplayProps {
  whatsAppLink: string;
  communityId: string;
  setCommunityDetails: (details: any) => void;
}

const WhatsAppLinkDisplay: React.FC<WhatsAppLinkDisplayProps> = ({
  whatsAppLink,
  communityId,
  setCommunityDetails,
}) => {
  const handleDisconnect = async () => {
    try {
      const response = await axios.post("/api/community/update-whatsapp-link", {
        communityId,
        whatsAppLink: null,
      });

      if (response.data.success) {
        setCommunityDetails(response.data.community);
        toast("Community WhatsApp group URL cleared successfully!", {
          icon: "✅",
          style: {
            backgroundColor: "white",
            color: "black",
          },
        });
      }
    } catch (error) {
      console.error("Error disconnecting WhatsApp link:", error);
    }
  };

  return (
    <div className="p-4 border rounded shadow">
      <div className="flex items-center mb-4">
        <Image
          src="/assets/icons/whatsapp_icon.png"
          alt="WhatsApp"
          className="mr-2"
          width={50}
          height={50}
        />
        <h2 className="text-xl font-medium">WhatsApp</h2>
      </div>
      <p className="text-para mb-4 font-light">WhatsApp group link</p>
      <Link
        href={whatsAppLink}
        target="_blank"
        className="text-primaryBlack font-medium break-all"
      >
        <p>{whatsAppLink}</p>
      </Link>
      <div className="mt-4 flex gap-2">
        <Link
          href={whatsAppLink}
          target="_blank"
          className="px-4 py-2 text-white bg-black rounded-full flex items-center justify-start gap-1"
        >
          <Image
            src={"/assets/icons/link_icon.png"}
            alt="link_icon"
            width={20}
            height={15}
          />{" "}
          <p>Open</p>
        </Link>
        <button
          className="px-4 py-2 text-red-600 bg-red-100 rounded-full flex items-center justify-start gap-1"
          onClick={handleDisconnect}
        >
          <Image
            src={"/assets/icons/unlink.png"}
            alt="link_icon"
            width={15}
            height={15}
          />{" "}
          <p>Disconnect Chat</p>
        </button>
        <button
          onClick={() => {
            const shareUrl = `${whatsAppLink}`;
            if (navigator.share) {
              navigator.share({
                text: "Check out this community!",
                url: shareUrl,
              });
            } else {
              navigator.clipboard
                .writeText(shareUrl)
                .catch((err) => console.error(err));
            }
          }}
          className="bg-white pl-4  rounded text-white "
        >
          <Image
            src={"/assets/icons/share.png"}
            alt="share"
            width={30}
            height={30}
          />
        </button>
      </div>
    </div>
  );
};

export default WhatsAppLinkDisplay;
