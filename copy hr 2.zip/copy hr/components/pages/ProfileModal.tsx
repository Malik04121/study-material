"use client";
import React, { useState, useRef, Dispatch, SetStateAction } from "react";
import Modal from "../reusable/Modal";
import { User } from "@/types/user.types";
import axios from "axios";
import Image from "next/image";
import EditImageModal from "../modal/EditImageModal";

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: User;
  onSave: (updatedUser: Partial<User>) => void;
  setLoggedUserData: Dispatch<SetStateAction<User | undefined>>;
  avatar: string; // Add avatar prop
  setAvatar: Dispatch<SetStateAction<string>>; // Add setAvatar prop
}

const ProfileModal = ({
  isOpen,
  onClose,
  user,
  onSave,
  setLoggedUserData,
  avatar,
  setAvatar,
}: ProfileModalProps) => {
  const [fullName, setFullName] = useState(user.fullName);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isFullNameValid, setIsFullNameValid] = useState<boolean>(true);
  const [isEditModalOpen, setIsEditModalOpen] = useState<boolean>(false); // State for edit modal

  const handleEditImageClick = () => {
    setIsEditModalOpen(true);
  };

  const handleFileChange = async (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = event.target.files?.[0];
    if (file) {
      const validImageTypes = [
        "image/jpeg",
        "image/png",
        "image/gif",
        "image/webp",
      ];
      if (!validImageTypes.includes(file.type)) {
        alert("Please upload a valid image file (JPEG, PNG, GIF, or WEBP)");
        return;
      }
      try {
        const url = await getSignedUrl(file);
        await uploadImageToS3(url, file);
        const imageUrl = url.split("?")[0];
        setAvatar(imageUrl);
        setIsEditModalOpen(false);
      } catch (error) {
        console.error("Error uploading image:", error);
      }
    }
  };

  const getSignedUrl = async (file: File): Promise<string> => {
    const response = await axios.post("/api/aws/get-signed-url", {
      fileName: file.name,
      fileType: file.type,
    });
    return response.data.uploadUrl;
  };

  const uploadImageToS3 = async (url: string, file: File) => {
    try {
      await axios.put(url, file, {
        headers: {
          "Content-Type": file.type,
        },
      });
    } catch (error) {
      console.error(error);
    }
  };

  const handleSave = () => {
    onSave({ fullName, avatar });
    onClose();
  };

  const handleDelete = async () => {
    const defaultImage =
      "https://hr-network-assets.s3.ap-south-1.amazonaws.com/profile-default-icon-512x511-v4sw4m29.png";
    setAvatar(defaultImage);
    setIsEditModalOpen(false);
  };

  const validateFullName = (value: string) => {
    return /^[a-zA-Z\s]*$/.test(value) && value.trim().length >= 3;
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} width={"80"}>
      <div className="flex flex-col space-y-4">
        <div className="flex items-center justify-center">
          <div className="relative w-24 h-24">
            <Image
              src={avatar}
              alt="Profile"
              width={40}
              height={40}
              className="w-full h-full rounded-full object-cover"
            />
            <button
              className="absolute bottom-0 right-0 bg-white rounded-full p-1"
              onClick={handleEditImageClick}
            >
              <Image
                width={20}
                height={20}
                src="/assets/icons/edit-button.png"
                alt="Edit"
              />
            </button>
          </div>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">
            Email
          </label>
          <input
            type="text"
            value={user.email}
            disabled
            className="mt-1 block w-full bg-white cursor-not-allowed border-gray-300 rounded-md px-3 py-2"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">
            Mobile Number (WhatsApp)
          </label>
          <input
            type="text"
            value={user.phoneNumber}
            disabled
            className="mt-1 block w-full bg-white cursor-not-allowed border-gray-300 rounded-md px-3 py-2"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">
            Full Name
          </label>
          <input
            type="text"
            value={fullName}
            onChange={(e) => {
              let value = e.target.value
                .replace(/[^a-zA-Z\s]/g, "")
                .replace(/\b\w/g, (char) => char.toUpperCase());
              setFullName(value);
              setIsFullNameValid(validateFullName(value));
            }}
            className={`create-community-input ${
              isFullNameValid ? "" : "border-red-500"
            }`}
          />
          {!isFullNameValid && (
            <p className="text-xs text-red-500 text-sm pt-1">
              Full name must contain only alphabets and spaces, and be at least
              3 characters long.
            </p>
          )}
        </div>
        <button
          onClick={handleSave}
          className={`primaryButton ${
            !isFullNameValid ? "opacity-50 cursor-not-allowed" : ""
          }`}
          disabled={!isFullNameValid}
        >
          Save
        </button>
      </div>
      {isEditModalOpen && (
        <EditImageModal
          avatar={avatar}
          isOpen={isEditModalOpen}
          onClose={() => setIsEditModalOpen(false)}
          onFileChange={handleFileChange}
          onDelete={handleDelete}
        />
      )}
    </Modal>
  );
};

export default ProfileModal;
