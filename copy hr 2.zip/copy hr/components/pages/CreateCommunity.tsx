"use client";
import { useRouter } from "next/navigation";
import React, { useEffect, useState } from "react";
import { SubmitHandler, useForm } from "react-hook-form";
import axios from "axios";
import Image from "next/image";
import toast, { Toaster } from "react-hot-toast";

type CommunityFields = {
  title: string;
};

const CreateCommunityPage = () => {
  const router = useRouter();
  const [selectedCheckbox, setSelectedCheckbox] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(false);

  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm<CommunityFields>({
    defaultValues: {
      title: "",
    },
  });

  const handleCheckboxChange = (value: string) => {
    setSelectedCheckbox(value);
  };

  useEffect(() => {
    // Check if user is logged in
    const checkUser = async () => {
      try {
        const response = await axios.get("/api/users/check-user");
        if (!response.data.user) {
          // If not logged in, redirect to create-account
          router.push("/create-account");
        }
      } catch (error) {
        console.error(error);
        router.push("/create-account");
      }
    };
    checkUser();
  }, [router]);

  const createMember = async (userId: string) => {
    try {
      const res = await axios.post("/api/member", { userId });
      return res.data.newMember;
    } catch (error) {
      console.log(error);
      toast("Error creating member", {
        icon: "❌",
        style: { backgroundColor: "#454545", color: "white" },
      });
      throw error;
    }
  };

  const createCommunity = async (hostMemberId: string, hostName: string) => {
    const title = watch("title");
    try {
      let publicPageUrl = title
        .trim()
        .replace(/[^a-zA-Z0-9-]/g, " ")
        .replace(/\s+/g, " ")
        .replace(/\s/g, "-");

      const response = await axios.post("/api/community", {
        title,
        host: hostMemberId, // host is now the member ID, not directly the user ID
        publicPageUrl,
        hostName,
      });

      if (response.status === 200) {
        try {
          const userUpdateResponse = await axios.put("/api/users", {
            newCommunity: response.data.community,
          });
          if (userUpdateResponse) {
            router.push(
              `/update-community/${response.data.community.publicPageUrl}/${title}/${response.data.community._id}`
            );
          }
        } catch (error) {
          console.error(error);
        }
      }
    } catch (error) {
      console.error(error);
      toast("Error creating community", {
        icon: "❌",
        style: { backgroundColor: "#454545", color: "white" },
      });
    }
  };

  const onSubmit: SubmitHandler<CommunityFields> = async (data) => {
    try {
      setLoading(true);
      // Get current user details
      const response = await axios.get("/api/users/check-user");
      if (!response.data.user) {
        router.push("/create-account");
        return;
      }

      const user = response.data.user;
      // First, create a member for this user
      const newMember = await createMember(user._id);
      // Now create the community with the member's ID as host
      await createCommunity(newMember._id, user.fullName);
    } catch (error) {
      console.error(error);
      toast("Please login or create an account first.", {
        icon: "❌",
        style: { backgroundColor: "#454545", color: "white" },
      });
      router.push("/create-account");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="relative min-h-screen bg-white desktopView">
      <div className="sticky top-0 w-full bg-white z-10 h-[10%] flex items-center px-4">
        <Image src={"/logo.jpeg"} alt={"logo"} width={100} height={50} />
      </div>
      <div className="w-full h-[90%]">
        <form
          onSubmit={handleSubmit(onSubmit)}
          className="relative h-full flex flex-col justify-between"
        >
          <div className="space-y-20 py-20 px-8">
            <div className="space-y-4">
              <label htmlFor="title" className="create-community-lebel">
                What is the name of your community?
              </label>
              <input
                type="text"
                {...register("title", {
                  required: "Title is required",
                })}
                placeholder="e.g. Creator Club"
                className="create-community-input"
              />
              {errors.title && (
                <p className="text-red-500 text-sm">{errors.title.message}</p>
              )}
            </div>
            <div className="space-y-5">
              <div>
                <label
                  htmlFor="communityMemberLimit"
                  className="text-lg text-primaryBlack font-medium"
                >
                  How big is your community?
                </label>
                <p className="text-base text-gray-400 font-light">
                  E.g. followers, mailing list, subscribers
                </p>
              </div>
              <div className="grid grid-rows-4 grid-flow-col gap-4">
                <div className="checkbox-wrapper">
                  <input
                    type="checkbox"
                    id="check-1"
                    name="check"
                    value=""
                    checked={selectedCheckbox === "10k"}
                    onChange={() => handleCheckboxChange("10k")}
                  />
                  <label htmlFor="check-1">
                    <span></span>Less than 10k
                  </label>
                </div>
                <div className="checkbox-wrapper">
                  <input
                    type="checkbox"
                    id="check-2"
                    name="check"
                    value=""
                    checked={selectedCheckbox === "100k"}
                    onChange={() => handleCheckboxChange("100k")}
                  />
                  <label htmlFor="check-2">
                    <span></span>10-100k
                  </label>
                </div>
                <div className="checkbox-wrapper">
                  <input
                    type="checkbox"
                    id="check-3"
                    name="check"
                    value=""
                    checked={selectedCheckbox === "500k"}
                    onChange={() => handleCheckboxChange("500k")}
                  />
                  <label htmlFor="check-3">
                    <span></span>100-500k
                  </label>
                </div>
                <div className="checkbox-wrapper">
                  <input
                    type="checkbox"
                    id="check-4"
                    name="check"
                    value=""
                    checked={selectedCheckbox === "over 500k"}
                    onChange={() => handleCheckboxChange("over 500k")}
                  />
                  <label htmlFor="check-4">
                    <span></span>Over 500k
                  </label>
                </div>
              </div>
            </div>
          </div>
          <div className="self-end w-full text-right py-3 border px-5">
            <button
              type="submit"
              disabled={!watch("title") || loading}
              className="primaryButton"
            >
              {loading ? "Loading..." : "Create Community"}
            </button>
          </div>
        </form>
      </div>
      <Toaster />
    </div>
  );
};

export default CreateCommunityPage;
