"use client";

import React, { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import axios from "axios";
import { Toaster, toast } from "react-hot-toast";
import { SubmitHandler, useForm } from "react-hook-form";
import Image from "next/image";
import type { Metadata, ResolvingMetadata } from "next";
import Link from "next/link";

type emailFields = {
  emailCheck: string;
};

type loginFields = {
  otp: string;
};

export default function LoginPage() {
  const router = useRouter();
  const [user, setUser] = useState({
    email: "",
    password: "",
  });
  const [buttonDisabled, setButtonDisabled] = useState(false);
  const [loading, setLoading] = useState(false);
  const [isEmailExist, setIsEmailExist] = useState<Boolean>(false);
  const [countdown, setCountdown] = useState(-1);

  // Email check form
  const {
    register: registerEmail,
    handleSubmit: handleSubmitEmail,
    watch: watchEmail,
    formState: { errors: emailErrors, isValid: isEmailValid },
  } = useForm<emailFields>({ mode: "onTouched" });

  const sentOtp = async () => {
    try {
      const response = await axios.post(
        "/api/aws/sent-otp",
        {
          email: watchEmail("emailCheck"),
        },
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      if (response) {
        toast("Check your email for OTP", {
          icon: "💁🏻",
          style: {
            backgroundColor: "#454545",
            color: "white",
          },
        });
        startCountdown();
      }
    } catch (error) {
      console.error(error);
      // toast.error("Email service error");
      toast("Email service error", {
        icon: "❌",
        style: {
          backgroundColor: "#454545",
          color: "white",
        },
      });
    }
  };

  const onSubmitEmail: SubmitHandler<emailFields> = async (data) => {
    console.log(data);
    try {
      setLoading(true);
      const response = await axios.post("/api/users/exist", {
        email: watchEmail("emailCheck"),
      });
      console.log(response);

      if (response.status === 200) {
        console.log("Email exists:", response.data);
        await sentOtp();
        // toast.success("Check your email for OTP");

        setIsEmailExist(true);
        setLoading(false);

        setUser({ ...user, email: data.emailCheck });
      } else {
        console.log("Unexpected status code:", response.status);
      }
    } catch (error: any) {
      if (axios.isAxiosError(error)) {
        if (error.response?.status === 400) {
          toast("This email address is not registered with us.", {
            icon: "⚠️",
            style: {
              backgroundColor: "#454545",
              color: "white",
            },
          });
          setTimeout(() => {
            router.push("/create-account");
          }, 2000);
        }
        console.log(error.response);
        setLoading(false);
      } else {
        // toast.error("Error:", error);
        toast(error, {
          icon: "❌",
          style: {
            backgroundColor: "#454545",
            color: "white",
          },
        });
        setLoading(false);
      }
    }
  };

  // Login form
  const {
    register: registerLogin,
    handleSubmit: handleSubmitLogin,
    watch: watchLogin,
    setValue,
    formState: { errors: loginErrors, isValid: isLoginValid },
  } = useForm<loginFields>({ mode: "onChange" });

  const onLogin: SubmitHandler<loginFields> = async (data) => {
    try {
      setLoading(true);
      const response = await axios.post("/api/users/check-otp", {
        email: user.email,
        otp: data.otp,
      });
      console.log(response);
      if (response) {
        // toast.success("OTP verified successfully!");
        toast("OTP verified successfully!", {
          icon: "✅",
          style: {
            backgroundColor: "#454545",
            color: "white",
          },
        });
        console.log(response.data);
        if (response.data.user.isVerified) {
          router.push("/community");
        }
      }
    } catch (error: any) {
      console.error(error);
      if (error.response && error.response.data) {
        // Extract error message from response
        const errorMessage = error.response.data.message;
        // toast.error(errorMessage || "Error while OTP verification");
        toast(errorMessage || "Error while OTP verification", {
          icon: "❌",
          style: {
            backgroundColor: "#454545",
            color: "white",
          },
        });
      } else {
        // toast.error("Error while OTP verification");
        toast("Error while OTP verification", {
          icon: "❌",
          style: {
            backgroundColor: "#454545",
            color: "white",
          },
        });
      }
    } finally {
      setLoading(false);
    }
  };

  const startCountdown = () => {
    setCountdown(30); // 3 minutes in seconds
  };

  useEffect(() => {
    if (countdown > 0) {
      const timer = setTimeout(() => {
        setCountdown(countdown - 1);
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [countdown]);

  console.log(
    process.env.NEXT_PUBLIC_ACCESS_KEY,
    process.env.NEXT_PUBLIC_SECRET_KEY,
    process.env.NEXT_PUBLIC_REGION
  );

  return (
    <div className="w-full desktopView min-h-screen bg-white flex justify-between items-center">
      <div className="w-full space-y-10 px-4">
        <div className="">
          <Image
            src={"/logo.jpeg"}
            alt="logo"
            width={150}
            height={80}
            className="mx-auto"
          />
        </div>
        <h2 className="text-3xl text-primaryBlack  font-medium leading-8 w-full text-center">
          {!isEmailExist ? "Login to WA Collab" : "Welcome back, please log in"}
        </h2>
        {!isEmailExist ? (
          <form
            className="flex flex-col "
            onSubmit={handleSubmitEmail(onSubmitEmail)}
          >
            <div className="">
              <label htmlFor="email" className="form-lebel">
                Email*
              </label>
              <input
                type="email"
                {...registerEmail("emailCheck", {
                  required: "Email is required",
                  pattern: {
                    value: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/,
                    message: "Invalid email address",
                  },
                })}
                placeholder="Enter your email"
                className="create-community-input"
              />

              <p className="text-red-500 text-sm text-sm">
                {emailErrors.emailCheck && emailErrors.emailCheck.message}
              </p>
            </div>
            <button
              type="submit"
              disabled={!isEmailValid || loading}
              className="primaryButton"
            >
              {loading ? "Loading" : "Continue"}
            </button>
            <div className="text-center text-sm text-para pt-3">
              <p>
                {`Don't have an account?`}{" "}
                <span className="text-primaryBlack font-medium">
                  <Link
                    href={"/create-account"}
                    className="hover:underline hover:underline-offset-2"
                  >
                    Get started
                  </Link>{" "}
                </span>
              </p>
            </div>
          </form>
        ) : (
          <form
            className="flex flex-col space-y-3"
            onSubmit={handleSubmitLogin(onLogin)}
          >
            <div>
              <p className="text-primaryBlack ">Email</p>
              <div className="create-community-input">
                {watchEmail("emailCheck")}
              </div>
            </div>
            <div>
              <label htmlFor="password" className="form-lebel">
                OTP*
              </label>
              <input
                type="text"
                {...registerLogin("otp", {
                  required: "OTP is required",
                  validate: {
                    isNumeric: (value) =>
                      /^\d*$/.test(value) || "OTP must contain only digits",
                    isValidLength: (value) =>
                      value.length === 0 ||
                      value.length === 6 ||
                      "OTP must be exactly 6 characters long",
                  },
                })}
                placeholder="Enter your OTP"
                className="create-community-input"
                onInput={(e: any) => {
                  e.target.value = e.target.value
                    .replace(/[^0-9]/g, "")
                    .slice(0, 6);
                }}
              />
            </div>
            {loginErrors.otp && (
              <p className="text-red-500  text-sm ">
                {loginErrors.otp.message}
              </p>
            )}
            <div className="space-y-2">
              <button
                type="submit"
                disabled={!isLoginValid || loading}
                className="primaryButton"
              >
                {loading ? "Loading" : "Login"}
              </button>
              <button
                type="button"
                className="underline text-primaryBlack  text-center w-full mx-auto pb-10"
                onClick={() => {
                  setValue("otp", "");
                  sentOtp();
                }}
                disabled={countdown > 0}
                style={{ whiteSpace: "nowrap" }}
              >
                {countdown > 0
                  ? `Didn’t received the OTP? Retry in ${String(
                      Math.floor(countdown / 60)
                    ).padStart(2, "0")}:${String(countdown % 60).padStart(
                      2,
                      "0"
                    )}`
                  : countdown !== -1 && "Resend OTP"}
              </button>
              <button
                onClick={() => setIsEmailExist(false)}
                type="button"
                className="secondaryButton "
              >
                Back
              </button>
            </div>
          </form>
        )}
        <Toaster />
      </div>
    </div>
  );
}
