"use client";
import React, { useEffect, useState } from "react";
import { useForm, SubmitHandler } from "react-hook-form";
import { useRouter } from "next/navigation";
import axios from "axios";
import toast, { Toaster } from "react-hot-toast";
import Image from "next/image";
import Link from "next/link";

type EmailFields = {
  emailCheck: string;
  otp: string;
};

type UserFields = {
  fullName: string;
  phoneNumber: string;
};

const CreateAccount = () => {
  const router = useRouter();

  const [isEmailExist, setIsEmailExist] = useState<boolean | null>(null);
  const [isOtpVerified, setIsOtpVerified] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);
  const [countdown, setCountdown] = useState<number>(-1);

  const {
    register: registerEmail,
    handleSubmit: handleSubmitEmail,
    watch: watchEmail,
    setValue: setEmail,
    formState: { errors: emailErrors, isValid: isEmailValid },
  } = useForm<EmailFields>({
    mode: "onChange",
  });

  const {
    register: registerUser,
    handleSubmit: handleSubmitUser,
    watch: watchUser,
    setValue: setUser,
    formState: { errors: userErrors, isValid: isUserValid },
  } = useForm<UserFields>({
    mode: "onChange",
    defaultValues: {
      fullName: "",
      phoneNumber: "+91 ",
    },
  });

  const startCountdown = () => {
    setCountdown(30);
  };

  useEffect(() => {
    if (countdown > 0) {
      const timer = setTimeout(() => {
        setCountdown(countdown - 1);
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [countdown]);

  const sentOtp = async () => {
    try {
      const response = await axios.post("/api/aws/sent-otp", {
        email: watchEmail("emailCheck"),
      });
      if (response.data) {
        toast("Check your email for OTP", {
          icon: "💁🏻",
          style: { backgroundColor: "#454545", color: "white" },
        });
        startCountdown();
      }
    } catch (error) {
      console.error(error);
      toast("Email service error", {
        icon: "❌",
        style: { backgroundColor: "#454545", color: "white" },
      });
    }
  };

  const checkOtp = async () => {
    try {
      const response = await axios.post("/api/users/check-otp", {
        email: watchEmail("emailCheck"),
        otp: watchEmail("otp"),
      });
      if (response) {
        toast("OTP verified successfully!", {
          icon: "✅",
          style: { backgroundColor: "#454545", color: "white" },
        });

        // If user is verified already, just redirect them
        if (response.data.user.isVerified) {
          router.push("/community"); // or "/create-community"
        } else {
          // New user, needs additional details
          setIsOtpVerified(true);
        }
      }
    } catch (error: any) {
      console.error(error);
      const errorMessage =
        error.response?.data?.message || "Error while OTP verification";
      toast(errorMessage, {
        icon: "❌",
        style: { backgroundColor: "#454545", color: "white" },
      });
    }
  };

  const onSubmitEmail: SubmitHandler<EmailFields> = async (data) => {
    setLoading(true);
    if (isEmailExist === null) {
      // First submit: check email and send OTP
      try {
        const response = await axios.get(
          "/api/users/check-email/" + data.emailCheck
        );
        if (response.status === 200) {
          setIsEmailExist(true);
        } else {
          setIsEmailExist(false);
        }
      } catch (error) {
        toast("Error checking email", {
          icon: "❌",
          style: { backgroundColor: "#454545", color: "white" },
        });
      } finally {
        await sentOtp();
        setLoading(false);
      }
    } else {
      // Second submit: verify OTP
      await checkOtp();
      setLoading(false);
    }
  };

  //   const createMember = async (userId: string) => {
  //     try {
  //       const res = await axios.post("/api/member", { userId });
  //       return res.data.newMember;
  //     } catch (error) {
  //       console.log(error);
  //     }
  //   };

  const onSubmitUser: SubmitHandler<UserFields> = async (data) => {
    setLoading(true);
    try {
      const emailFromEmailForm = watchEmail("emailCheck");
      const response = await axios.post("/api/users", {
        email: emailFromEmailForm,
        fullName: data.fullName,
        phoneNumber: data.phoneNumber,
      });

      //   const newMember = await createMember(response.data.savedUser._id);
      if (response.status === 200) {
        router.push("/community"); // Redirect after account creation
      }
    } catch (error: any) {
      console.error(error);
      const errorMessage =
        error.response?.data?.message || "An error occurred. Please try again.";
      toast(errorMessage, {
        icon: "❌",
        style: { backgroundColor: "#454545", color: "white" },
      });
      setUser("phoneNumber", "+91 ");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="relative min-h-screen bg-white desktopView">
      <div className="sticky top-0 w-full bg-white z-10 h-[10%] flex items-center px-4">
        <Image src={"/logo.jpeg"} alt={"logo"} width={100} height={50} />
      </div>
      <div className="w-full h-[90%] flex flex-col">
        {!isOtpVerified ? (
          <form
            onSubmit={handleSubmitEmail(onSubmitEmail)}
            className="flex flex-col h-full"
          >
            <div className="flex-grow pt-40 px-8 space-y-5">
              <h2 className="create-community-lebel">Create your account</h2>
              <div className="w-full space-y-1">
                <label htmlFor="emailCheck" className="form-lebel">
                  Email*
                </label>
                <div className="relative">
                  <input
                    type="email"
                    {...registerEmail("emailCheck", {
                      required: "Email is required",
                      pattern: {
                        value:
                          /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/,
                        message: "Invalid email address",
                      },
                    })}
                    placeholder="johndoe@gmail.com"
                    readOnly={isEmailExist !== null && !isOtpVerified}
                    className={`create-community-input ${
                      isEmailExist !== null && !isOtpVerified
                        ? "read-only:bg-[#D3D0D0]"
                        : ""
                    }`}
                  />
                  {isEmailExist !== null && !isOtpVerified && (
                    <button
                      type="button"
                      className="absolute right-2 top-[60%] transform -translate-y-1/2 p-0"
                      onClick={() => {
                        setEmail("emailCheck", "");
                        setIsEmailExist(null);
                        setEmail("otp", "");
                      }}
                    >
                      <Image
                        src={"/assets/icons/edit-button.svg"}
                        alt="edit"
                        width={20}
                        height={20}
                      />
                    </button>
                  )}
                  {emailErrors.emailCheck && (
                    <p className="text-red-500 text-sm">
                      {emailErrors.emailCheck.message}
                    </p>
                  )}
                </div>
              </div>
              {isEmailExist !== null && !isOtpVerified && (
                <div className="w-full">
                  <label htmlFor="emailCheck" className="text-primaryBlack">
                    OTP*
                  </label>
                  <input
                    type="text"
                    {...registerEmail("otp", {
                      required: "OTP is required",
                      validate: {
                        isNumeric: (value) =>
                          /^\d*$/.test(value) || "OTP must contain only digits",
                        isValidLength: (value) =>
                          value.length === 0 ||
                          value.length === 6 ||
                          "OTP must be exactly 6 characters long",
                      },
                    })}
                    placeholder="Enter your OTP"
                    className="create-community-input"
                    onInput={(e: any) => {
                      e.target.value = e.target.value
                        .replace(/[^0-9]/g, "")
                        .slice(0, 6);
                    }}
                  />
                  {emailErrors.otp && (
                    <p className="text-red-500 text-sm">
                      {emailErrors.otp.message}
                    </p>
                  )}
                </div>
              )}
              {isEmailExist === null ? (
                <button
                  className="primaryButton"
                  type="submit"
                  disabled={!isEmailValid || loading}
                >
                  {loading ? "Loading" : "Continue"}
                </button>
              ) : (
                <>
                  <button
                    className="primaryButton w-full text-center"
                    disabled={!isEmailValid || loading}
                    type="submit"
                  >
                    {loading ? "Loading" : "Submit"}
                  </button>

                  <button
                    type="button"
                    className="underline text-primaryBlack text-center w-full mx-auto"
                    onClick={() => {
                      setEmail("otp", "");
                      sentOtp();
                    }}
                    disabled={countdown > 0}
                  >
                    {countdown > 0
                      ? `Didn’t receive the OTP? Retry in ${String(
                          Math.floor(countdown / 60)
                        ).padStart(2, "0")}:${String(countdown % 60).padStart(
                          2,
                          "0"
                        )}`
                      : countdown !== -1 && "Resend OTP"}
                  </button>
                </>
              )}

              {/* Add "Already have an account? Login" message when at the email/OTP steps */}
              {(isEmailExist === null ||
                (isEmailExist !== null && !isOtpVerified)) && (
                <div className="text-center text-sm text-para pt-3">
                  <p>
                    {`Already have an account?`}{" "}
                    <span className="text-primaryBlack font-medium">
                      <Link
                        href={"/login"}
                        className="hover:underline hover:underline-offset-2"
                      >
                        Login
                      </Link>{" "}
                    </span>
                  </p>
                </div>
              )}
            </div>
            {isEmailExist !== null && (
              <div className="border-t px-5 py-3 w-full text-right mt-5">
                <button
                  type="button"
                  className="secondaryButton"
                  onClick={() => {
                    setEmail("emailCheck", "");
                    setIsEmailExist(null);
                    setEmail("otp", "");
                  }}
                >
                  Back
                </button>
              </div>
            )}
          </form>
        ) : (
          <form
            onSubmit={handleSubmitUser(onSubmitUser)}
            className="flex flex-col h-full"
          >
            <div className="flex-grow pt-40 px-8 space-y-5">
              <div className="w-full">
                <p className="form-lebel">Email</p>
                <div className="create-community-input border-primaryBlack ">
                  {watchEmail("emailCheck")}
                </div>
              </div>

              <div className="w-full">
                <label htmlFor="fullName" className="form-lebel">
                  Full Name*
                </label>
                <input
                  type="text"
                  {...registerUser("fullName", {
                    required: "Full name is required",
                    pattern: {
                      value: /^[a-zA-Z\s]*$/,
                      message:
                        "Full name must only contain letters and spaces.",
                    },
                    validate: {
                      noSpecialChars: (value) =>
                        /^[^\u00C0-\uFFFF]*$/.test(value) ||
                        "Full name must not contain special characters or emojis.",
                    },
                  })}
                  placeholder="John Doe"
                  className="create-community-input"
                  onInput={(e: React.ChangeEvent<HTMLInputElement>) => {
                    e.target.value = e.target.value
                      .replace(/[^a-zA-Z\s]/g, "")
                      .replace(/\b\w/g, (char) => char.toUpperCase());
                  }}
                />
                {userErrors.fullName && (
                  <p className="text-red-500 text-sm">
                    {userErrors.fullName.message}
                  </p>
                )}
              </div>
              <div className="w-full">
                <label htmlFor="phoneNumber" className="form-label">
                  Mobile Number (WhatsApp)*
                </label>
                <input
                  type="tel"
                  {...registerUser("phoneNumber", {
                    required: "Mobile Number (WhatsApp) is required",
                    pattern: {
                      value: /^\+91 \d{10}$/,
                      message:
                        "Mobile Number (WhatsApp) must be exactly 10 digits",
                    },
                  })}
                  placeholder="+91 1234567890"
                  className="create-community-input outline-none w-full pl-14"
                />

                {userErrors.phoneNumber && (
                  <p className="text-red-500 text-sm">
                    {userErrors.phoneNumber.message}
                  </p>
                )}
              </div>

              <button
                className="primaryButton"
                type="submit"
                disabled={!isUserValid || loading}
              >
                {loading ? "Loading" : "Create Account"}
              </button>

              {/* Add "Already have an account? Login" message at the final step as well */}
              <div className="text-center text-sm text-para pt-3">
                <p>
                  {`Already have an account?`}{" "}
                  <span className="text-primaryBlack font-medium">
                    <Link
                      href={"/login"}
                      className="hover:underline hover:underline-offset-2"
                    >
                      Login
                    </Link>{" "}
                  </span>
                </p>
              </div>
            </div>
            <div className="border-t px-5 py-3 w-full text-right mt-5">
              <button
                type="button"
                className="secondaryButton"
                onClick={() => {
                  setEmail("emailCheck", "");
                  setIsEmailExist(null);
                  setIsOtpVerified(false);
                  setEmail("otp", "");
                }}
              >
                Back
              </button>
            </div>
          </form>
        )}
      </div>
      <Toaster />
    </div>
  );
};

export default CreateAccount;
