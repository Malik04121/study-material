import { User } from "@/types/user.types";
import Image from "next/image";
import React from "react";
import { CommunityDetails } from "@/types/communityDetails.types";
import Link from "next/link";

type Props = {
  coverImage: string;
  title: string;
  communityLogo: string;
  communityHostName: string;
  Members: number;
  isAutoApproveMembership: boolean;
  loggedUserData?: User;
  setIsJoinCommunityOpen: (value: boolean) => void;
  handleJoinCommunity: () => void;
  communityDetails: CommunityDetails;
  withDrawRequest: () => void;
  loading: boolean;
};

const AboutCommunity = (props: Props) => {
  console.log(props.communityDetails.isAutoApproveMembership);

  return (
    <div className="w-full">
      <div className="w-full h-[250px] md:h-[300px]  relative">
        <Image
          src={props.coverImage}
          alt="cover-image"
          width={4080}
          height={200}
          className="object-cover object-center w-full h-full"
        />
        <div className="absolute -bottom-[20%] left-1/2 transform -translate-x-1/2 border-[7px] w-20 h-20  border-white rounded-2xl">
          <Image
            src={props.communityLogo}
            alt="community-logo"
            width={100}
            height={100}
            className="rounded-lg bg-white bg-cover w-full h-full object-cover"
          />
        </div>
      </div>
      <div className=" flex flex-col justify-between items-center bg-white   px-8 pb-5 gap-10">
        <div className="w-full flex flex-col justify-between items-center gap-2 pt-20">
          <div className="text-4xl text-primaryBlack  font-semibold w-full text-center flex justify-center items-center gap-1">
            <h1>{props.title}</h1>

            <button
              onClick={() => {
                const shareUrl = `${process.env.NEXT_PUBLIC_DOMAIN_NAME}/${props.communityDetails.publicPageUrl}`;
                if (navigator.share) {
                  navigator.share({
                    title: props.communityDetails?.title,
                    text: "Check out this community!",
                    url: shareUrl,
                  });
                } else {
                  navigator.clipboard
                    .writeText(shareUrl)
                    .catch((err) => console.error(err));
                }
              }}
              className="bg-white pl-4  rounded text-white "
            >
              <Image
                src={"/assets/icons/share.png"}
                alt="share"
                width={30}
                height={30}
              />
            </button>
          </div>
          <p className=" text-primaryBlack  font-light text-base text-center">
            by {props.communityHostName}
          </p>
        </div>
        <div className="bg-white flex justify-between item-center rounded-2xl border-primaryBlack  border-[0.5px] py-7 px-5 text-primaryBlack  w-full ">
          <div className="basis-[20%] border-white  px-5">
            <p className="text-sm text-center w-full">Member</p>
            <p className="text-base font-semibold text-center">
              {props.Members}
            </p>
          </div>
          <div
            className={`flex-1 border-white border-l-gray-400  border  ${
              props.communityDetails.whatsUpGroupLink && "   "
            } px-5`}
          >
            <p className="text-sm text-center">Access</p>
            <p className="text-base font-semibold text-center">
              {props.isAutoApproveMembership ? "Public" : "Private"}
            </p>
          </div>
          {(props.loggedUserData?.communityStatus === "Host" ||
            props.loggedUserData?.communityStatus === "Member") &&
            props.communityDetails.whatsUpGroupLink && (
              <Link
                href={props.communityDetails.whatsUpGroupLink}
                target="_blank"
                className=" px-5 text-sm  border-white border-l-gray-400  border"
              >
                Chat on
                <Image
                  src="/assets/icons/whatsapp_icon.png"
                  alt="WhatsApp"
                  className="mr-2"
                  width={50}
                  height={50}
                />
              </Link>
            )}
        </div>
        {(props.loggedUserData?.communityStatus === "New" ||
          !props.loggedUserData) && (
          <>
            <button
              className="primaryButton"
              type="button"
              onClick={() => props.handleJoinCommunity()}
            >
              Join Community
            </button>
            <div className="text-center w-full">
              {!props.communityDetails.isAutoApproveMembership && (
                <div className="flex justify-center items-center gap-1 ">
                  <div>
                    <Image
                      src={"/assets/icons/padlock.png"}
                      alt="lock_icon"
                      className=""
                      width={20}
                      height={20}
                    />
                  </div>

                  <p className="text-primaryBlack  text-sm">
                    Approval required
                  </p>
                </div>
              )}
            </div>
          </>
        )}
        {props.loggedUserData?.communityStatus === "Pending" && (
          <div className="flex flex-col justify-center items-center gap-1 w-full ">
            <button
              type="button"
              onClick={props.withDrawRequest}
              disabled={props.loading}
              className="primaryButton text-center"
            >
              {props.loading ? "Requesting for withdraw" : "Withdraw request"}
            </button>
            <p className="text-primaryBlack  text-sm mt-2 text-center">
              💁🏻‍♂️ We will let you know when your application is approved.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default AboutCommunity;
