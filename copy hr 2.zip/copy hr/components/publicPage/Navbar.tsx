"use client";
import { CommunityDetails } from "@/types/communityDetails.types";
import { User } from "@/types/user.types";
import axios from "axios";

import Image from "next/image";
import Link from "next/link";

import React, { useEffect, useRef, useState } from "react";

const Navbar = ({
  loggedUser,

  communityId,
  community,
  handleJoinCommunity,
}: {
  loggedUser: User | undefined;

  communityId?: string;
  community: CommunityDetails;
  handleJoinCommunity: () => void;
}) => {
  const [openProfileSetting, setOpenProfileSetting] = useState<boolean>(false);
  const [showProfile, setShowProfile] = useState<boolean>(false);
  const profileRef = useRef<HTMLDivElement>(null);
  const buttonRef = useRef<HTMLButtonElement>(null);

  const handleClickOutside = (event: MouseEvent) => {
    if (
      profileRef.current &&
      !profileRef.current.contains(event.target as Node) &&
      buttonRef.current &&
      !buttonRef.current.contains(event.target as Node)
    ) {
      setShowProfile(false);
    }
  };

  const logout = async () => {
    try {
      const response = await axios.delete("/api/users/logout");

      if (response.data) {
        window.location.reload();
      }
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);
  console.log(loggedUser);

  return (
    <nav className="sticky top-0 w-full bg-gray-50  z-[10] px-5 py-2">
      <div className="flex justify-between items-center relative">
        <div>
          <Image src={"/logo.jpeg"} alt="logo" width={70} height={70} />
        </div>
        <div>
          {!loggedUser ? (
            <button
              onClick={handleJoinCommunity}
              className="public-page-primaryButton "
            >
              Login
            </button>
          ) : (
            <div className="flex justify-center items-center gap-2">
              {loggedUser.communityDetails.find(
                (communityDe) => communityDe.communityId === community._id
              )?.memberId === community.host && (
                <Link
                  href={"/portal/home/" + community._id}
                  className="public-page-primaryButton"
                >
                  Dashboard
                </Link>
              )}
              <button
                ref={buttonRef}
                type="button"
                className="flex justify-center items-center gap-3 rounded-2xl bg-white hover:bg-gray-200 p-1"
                onClick={(e) => {
                  e.stopPropagation();
                  setShowProfile((prev) => !prev);
                }}
              >
                <div className="w-8 h-8 rounded-full overflow-hidden">
                  <Image
                    src={loggedUser.avatar}
                    alt="user_logo"
                    width={100}
                    height={100}
                    className="object-cover w-full h-full"
                  />
                </div>
                <div className="w-4 h-4">
                  <Image
                    src={"/assets/icons/menu.png"}
                    alt="menu_icon"
                    width={100}
                    height={100}
                    className="object-center object-cover"
                  />
                </div>
              </button>
            </div>
          )}
        </div>
        {showProfile && (
          <div
            ref={profileRef}
            className="absolute right-0 -bottom-[220%] z-[100] min-w-[50%] rounded-md bg-white text-primaryBlack  drop-shadow-2xl"
          >
            <div className="flex flex-col justify-between items-startFcon p-4 gap-4">
              <div className="text-sm ">
                <p>{loggedUser?.fullName}</p>
                <p className="text-gray-500 font-extralight">
                  {loggedUser?.email}
                </p>
              </div>
              <hr className="bg-gray-600 w-full h-[1px] border border-gray-700" />
              <Link
                href={`/user/profile?fromCommunity=${community.publicPageUrl}`}
                onClick={() => {
                  setOpenProfileSetting(true);
                  setShowProfile(false);
                }}
                className="flex justify-start items-center gap-2 w-full"
              >
                <Image
                  src={"/assets/icons/demo_profile.png"}
                  alt="profile_icon"
                  width={15}
                  height={15}
                />
                <p className="text-sm">Profile Settings</p>
              </Link>
              <button
                type="button"
                onClick={() => {
                  setOpenProfileSetting(true);
                  setShowProfile(false);
                  logout();
                }}
                className="flex justify-start items-center gap-2 w-full"
              >
                <Image
                  src={"/assets/icons/logout.png"}
                  alt="logout_icon"
                  width={15}
                  height={15}
                />
                <p className="text-sm">Logout</p>
              </button>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
