"use client";
import React, { useEffect, useRef, useState } from "react";
import axios from "axios";
import { useForm, Controller } from "react-hook-form";
import Select from "react-select";
import toast, { Toaster } from "react-hot-toast";
import { CommunityDetails } from "@/types/communityDetails.types";
import { useRouter } from "next/navigation";
import MemberAuthProvider from "./reusable/MemberAuthProvider";
import Image from "next/image";
import Link from "next/link";
import { User } from "@/types/user.types";

interface ContentTypeFormField {
  typeOfField: string;
  isRequired: boolean;
  labelName: string;
  options?: string[];
}

interface ContentTypeData {
  title: string;
  description: string;
  contentTypeForm: ContentTypeFormField[];
  isActive: boolean;
  tags: string[];
}

type FileUpload = {
  file: File;
  uploadUrl: string;
};

const PublicContentForm = ({
  params,
}: {
  params: { contentId: string; communityId: string };
}) => {
  const [contentTypeData, setContentTypeData] =
    useState<ContentTypeData | null>(null);
  const [communityDetails, setCommunityDetails] = useState<CommunityDetails>();
  const [loading, setLoading] = useState(false); // Loading state
  const [loggedUserData, setLoggedUserData] = useState<User>();
  const profileRef = useRef<HTMLDivElement>(null);
  const buttonRef = useRef<HTMLButtonElement>(null);
  const [showProfile, setShowProfile] = useState<boolean>(false);

  const {
    control,
    handleSubmit,
    register,
    setValue,
    formState: { errors, isValid },
  } = useForm({
    mode: "onChange", // Validate on change
  });

  const [filesToUpload, setFilesToUpload] = useState<{
    [key: string]: FileUpload;
  }>({});
  const { communityId } = params;
  const router = useRouter();
  const handleClickOutside = (event: MouseEvent) => {
    if (
      profileRef.current &&
      !profileRef.current.contains(event.target as Node) &&
      buttonRef.current &&
      !buttonRef.current.contains(event.target as Node)
    ) {
      setShowProfile(false);
    }
  };
  useEffect(() => {
    const fetchContentTypeData = async () => {
      try {
        const response = await axios.get(`/api/content/${params.contentId}`);
        if (response.data.success) {
          setContentTypeData(response.data.data);
        } else {
          console.error("Failed to fetch content type data");
        }
      } catch (error) {
        console.error("Error fetching content type data:", error);
      }
    };
    const checkTokenValidity = async () => {
      try {
        const response = await axios.get("/api/users/check-user");
        if (response.data) {
          setLoggedUserData(response.data.user);
        }
        return true;
      } catch (error) {
        console.error(error);
        return false;
      }
    };
    const fetchCommunity = async () => {
      try {
        const response = await axios.get(
          `/api/community/get-by-id/${communityId}`
        );
        if (response.status === 200) {
          console.log(response.data.community);
          setCommunityDetails(response.data.community);
        } else {
          console.log("Unexpected status code:", response.status);
        }
      } catch (error) {
        console.error(error);
        router.push("/not-found");
      }
    };
    checkTokenValidity();
    fetchContentTypeData();
    fetchCommunity();
  }, [params.contentId, params.communityId]);

  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const prepareFileUpload = async (file: File, fieldName: string) => {
    const maxSizeInBytes = 5 * 1024 * 1024;

    if (file.size > maxSizeInBytes) {
      toast.error("File size should be less than 5 MB", {
        style: {
          backgroundColor: "#454545",
          color: "white",
        },
      });
      return;
    }

    try {
      const { data } = await axios.post("/api/aws/get-signed-url", {
        fileName: file.name,
        fileType: file.type,
      });

      setFilesToUpload((prev) => ({
        ...prev,
        [fieldName]: { file, uploadUrl: data.uploadUrl },
      }));

      setValue(fieldName, `Pending upload: ${file.name}`);
    } catch (error) {
      console.error("Error preparing file upload", error);
    }
  };
  const logout = async () => {
    try {
      const response = await axios.delete("/api/users/logout");

      if (response.data) {
        window.location.reload();
      }
    } catch (error) {
      console.error(error);
    }
  };

  const onSubmit = async (data: any) => {
    setLoading(true); // Start loading
    try {
      for (const key in data) {
        if (Array.isArray(data[key])) {
          data[key] = data[key].join(", "); // Convert array to comma-separated string
        }
      }

      console.log("Transformed form data before submission:", data); // Log the transformed form data

      // Upload each file to S3 and update the form data with the S3 URL
      for (const [fieldName, { file, uploadUrl }] of Object.entries(
        filesToUpload
      )) {
        await axios.put(uploadUrl, file, {
          headers: {
            "Content-Type": file.type,
          },
        });

        const fileUrl = uploadUrl.split("?")[0];
        data[fieldName] = fileUrl;
      }
      console.log("Form data before submission:", data);

      // Make the API call to save the record, including the communityId
      const response = await axios.post("/api/content/record", {
        contentId: params.contentId,
        communityId: params.communityId, // Include communityId in the payload
        formData: data,
      });

      if (response.data.success) {
        toast.success("Form submitted successfully!", {
          style: {
            backgroundColor: "#454545",
            color: "white",
          },
        });
        if (communityDetails?.publicPageUrl)
          router.push(`/${communityDetails.publicPageUrl}`);
      } else {
        toast.error("Failed to submit the form", {
          style: {
            backgroundColor: "#454545",
            color: "white",
          },
        });
      }

      console.log("API response:", response.data); // Log the API response
    } catch (error) {
      console.error("Error uploading files or submitting form", error);
      toast.error("An error occurred while submitting the form", {
        style: {
          backgroundColor: "#454545",
          color: "white",
        },
      });
    } finally {
      setLoading(false); // Stop loading
    }
  };

  if (!contentTypeData) {
    return <div></div>;
  }

  console.log(contentTypeData);

  return (
    <div className="bg-slate-50 min-h-screen desktopView">
      {loggedUserData && communityDetails && (
        <nav className="sticky top-0 w-full bg-white z-[10] px-5 py-2">
          <div className="flex justify-between items-center relative">
            <div>
              <Image src={"/logo.jpeg"} alt="logo" width={70} height={70} />
            </div>
            <div>
              <div className="flex justify-center items-center gap-2">
                {loggedUserData.communityDetails.find(
                  (communityDe) =>
                    communityDe.communityId === communityDetails._id
                )?.memberId === communityDetails.host && (
                  <Link
                    href={"/portal/home/" + communityDetails._id}
                    className="public-page-primaryButton"
                  >
                    Dashboard
                  </Link>
                )}
                <button
                  ref={buttonRef}
                  type="button"
                  className="flex justify-center items-center gap-3 rounded-2xl bg-white hover:bg-gray-200 p-1"
                  onClick={(e) => {
                    e.stopPropagation();
                    setShowProfile((prev) => !prev);
                  }}
                >
                  <div className="w-8 h-8 rounded-full overflow-hidden">
                    <Image
                      src={loggedUserData.avatar}
                      alt="user_logo"
                      width={100}
                      height={100}
                      className="object-cover w-full h-full"
                    />
                  </div>
                  <div className="w-4 h-4">
                    <Image
                      src={"/assets/icons/menu.png"}
                      alt="menu_icon"
                      width={100}
                      height={100}
                      className="object-center object-cover"
                    />
                  </div>
                </button>
              </div>
            </div>

            {showProfile && (
              <div
                ref={profileRef}
                className="absolute right-0 -bottom-[180%] z-[100] min-w-[50%] rounded-md bg-white text-primaryBlack  drop-shadow-2xl"
              >
                <div className="flex flex-col justify-between items-startFcon p-4 gap-4">
                  <div className="text-sm ">
                    <p>{loggedUserData?.fullName}</p>
                    <p className="text-gray-500 font-extralight">
                      {loggedUserData?.email}
                    </p>
                  </div>
                  <hr className="bg-gray-600 w-full h-[1px] border border-gray-700" />

                  <button
                    type="button"
                    onClick={() => {
                      setShowProfile(false);
                      logout();
                    }}
                    className="flex justify-start items-center gap-2 w-full"
                  >
                    <Image
                      src={"/assets/icons/logout.png"}
                      alt="logout_icon"
                      width={15}
                      height={15}
                    />
                    <p className="text-sm">Logout</p>
                  </button>
                </div>
              </div>
            )}
          </div>
        </nav>
      )}
      <MemberAuthProvider communityId={params.communityId}>
        <div className="  p-6 w-full  flex-1">
          <h1 className="text-3xl font-bold text-gray-800 mb-4">
            {contentTypeData.title}
          </h1>
          <p className="text-gray-600 mb-6">{contentTypeData.description}</p>

          {contentTypeData.isActive ? (
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
              {contentTypeData.contentTypeForm.map((field, index) => (
                <div key={index} className="mb-4">
                  <label className="block mb-2 font-semibold text-gray-700">
                    {field.labelName}{" "}
                    {field.isRequired && (
                      <span className="text-red-500">*</span>
                    )}
                  </label>

                  {field.typeOfField === "text-single" && (
                    <>
                      <input
                        {...register(field.labelName, {
                          required: field.isRequired,
                        })}
                        type="text"
                        placeholder={field.labelName}
                        className="border border-gray-300 rounded-md p-3 w-full focus:outline-none focus:border-gray-500"
                      />
                      {errors[field.labelName] && (
                        <p className="text-red-500 text-sm mt-1">{`${field.labelName} is required`}</p>
                      )}
                    </>
                  )}

                  {field.typeOfField === "text-multi" && (
                    <>
                      <textarea
                        {...register(field.labelName, {
                          required: field.isRequired,
                        })}
                        placeholder={field.labelName}
                        className="border border-gray-300 rounded-md p-3 w-full focus:outline-none focus:border-gray-500"
                      />
                      {errors[field.labelName] && (
                        <p className="text-red-500 text-sm mt-1">{`${field.labelName} is required`}</p>
                      )}
                    </>
                  )}

                  {field.typeOfField === "single-select" && (
                    <>
                      <Controller
                        name={field.labelName}
                        control={control}
                        rules={{ required: field.isRequired }}
                        render={({ field: { onChange, value } }) => (
                          <Select
                            options={field.options?.map((option) => ({
                              value: option,
                              label: option,
                            }))}
                            value={field.options
                              ?.map((option) => ({
                                value: option,
                                label: option,
                              }))
                              .find((option) => option.value === value)}
                            onChange={(selectedOption) =>
                              onChange(
                                selectedOption ? selectedOption.value : ""
                              )
                            }
                            styles={{
                              control: (base, state) => ({
                                ...base,
                                borderWidth: 0, // Remove the inner border
                                border: "none", // Ensure there's no border being added
                                boxShadow: "none", // Remove any box shadow
                              }),
                              container: (base) => ({
                                ...base,
                                border: "1px solid #d1d5db", // Outer border to maintain the look
                                borderRadius: "0.375rem", // Same rounded-md border radius
                                padding: "6px", // Keep padding for consistency
                              }),
                              placeholder: (base) => ({
                                ...base,
                                color: "#9ca3af", // text-gray-500
                              }),
                            }}
                            className="w-full"
                            placeholder={`Select ${field.labelName}`}
                          />
                        )}
                      />
                      {errors[field.labelName] && (
                        <p className="text-red-500 text-sm mt-1">{`${field.labelName} is required`}</p>
                      )}
                    </>
                  )}

                  {field.typeOfField === "multi-select" && (
                    <>
                      <Controller
                        name={field.labelName}
                        control={control}
                        rules={{ required: field.isRequired }}
                        render={({ field: { onChange, value } }) => (
                          <Select
                            isMulti
                            options={field.options?.map((option) => ({
                              value: option,
                              label: option,
                            }))}
                            value={field.options
                              ?.map((option) => ({
                                value: option,
                                label: option,
                              }))
                              .filter((option) =>
                                value?.includes(option.value)
                              )}
                            onChange={(selectedOptions) =>
                              onChange(
                                selectedOptions.map((option) => option.value)
                              )
                            }
                            styles={{
                              control: (base, state) => ({
                                ...base,
                                borderWidth: 0, // Remove the inner border
                                border: "none", // Ensure there's no border being added
                                boxShadow: "none", // Remove any box shadow
                              }),
                              container: (base) => ({
                                ...base,
                                border: "1px solid #d1d5db", // Outer border to maintain the look
                                borderRadius: "0.375rem", // Same rounded-md border radius
                                padding: "6px", // Keep padding for consistency
                              }),
                              placeholder: (base) => ({
                                ...base,
                                color: "#9ca3af", // text-gray-500
                              }),
                              multiValue: (base) => ({
                                ...base,
                                backgroundColor: "#e5e7eb", // Light gray background for selected values
                                borderRadius: "0.375rem", // Rounded corners for selected values
                                padding: "2px 5px", // Padding within the selected values
                              }),
                              multiValueLabel: (base) => ({
                                ...base,
                                color: "#374151", // Darker gray for the text within selected values
                              }),
                              multiValueRemove: (base) => ({
                                ...base,
                                color: "#374151",
                                "&:hover": {
                                  backgroundColor: "#f87171", // Red background on hover
                                  color: "white", // White text on hover
                                },
                              }),
                            }}
                            className="w-full"
                            placeholder={`Select ${field.labelName}`}
                          />
                        )}
                      />
                      {errors[field.labelName] && (
                        <p className="text-red-500 text-sm mt-1">{`${field.labelName} is required`}</p>
                      )}
                    </>
                  )}

                  {field.typeOfField === "file-upload" && (
                    <>
                      <input
                        type="file"
                        id="file"
                        className="border border-gray-300 rounded-md p-3 w-full focus:outline-none focus:border-gray-500"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            prepareFileUpload(file, field.labelName);
                          }
                        }}
                      />
                      {errors[field.labelName] && (
                        <p className="text-red-500 text-sm mt-1">{`${field.labelName} is required`}</p>
                      )}
                      <label htmlFor="file">Click me to upload image</label>
                    </>
                  )}
                </div>
              ))}

              {contentTypeData.tags?.length > 0 && (
                <div className="mb-4">
                  <label className="block mb-2 font-semibold text-gray-700">
                    Tags <span className="text-red-500">*</span>
                  </label>
                  <Controller
                    name="Tags"
                    control={control}
                    rules={{
                      validate: (value) => {
                        if (!value || value.length === 0) {
                          return "At least one tag is required.";
                        }
                        return true;
                      },
                    }}
                    render={({
                      field: { onChange, value },
                      fieldState: { error },
                    }) => (
                      <>
                        <Select
                          isMulti
                          options={contentTypeData.tags.map((tag) => ({
                            value: tag,
                            label: tag,
                          }))}
                          value={contentTypeData.tags
                            .map((tag) => ({ value: tag, label: tag }))
                            .filter((option) => value?.includes(option.value))}
                          onChange={(selectedOptions) =>
                            onChange(
                              selectedOptions.map((option) => option.value)
                            )
                          }
                          styles={{
                            control: (base, state) => ({
                              ...base,
                              borderWidth: 0, // Remove the inner border
                              border: "none", // Ensure no border is added by default
                              boxShadow: "none", // Remove any box shadow
                            }),
                            container: (base) => ({
                              ...base,
                              border: "1px solid #d1d5db", // Outer border to match other fields
                              borderRadius: "0.375rem", // Match rounded-md
                              padding: "6px", // Maintain padding for consistency
                            }),
                            placeholder: (base) => ({
                              ...base,
                              color: "#9ca3af", // text-gray-500 for the placeholder
                            }),
                            multiValue: (base) => ({
                              ...base,
                              backgroundColor: "#e5e7eb", // Background for selected values
                              borderRadius: "0.375rem", // Rounded corners for selected values
                              padding: "2px 5px", // Padding inside selected values
                            }),
                            multiValueLabel: (base) => ({
                              ...base,
                              color: "#374151", // Darker text color for selected values
                            }),
                            multiValueRemove: (base) => ({
                              ...base,
                              color: "#374151",
                              "&:hover": {
                                backgroundColor: "#f87171", // Hover background color
                                color: "white", // Hover text color
                              },
                            }),
                          }}
                          className="w-full"
                          placeholder="Select Tags"
                        />
                        {error && (
                          <p className="text-red-500 text-sm mt-1">
                            {error.message}
                          </p>
                        )}
                      </>
                    )}
                  />
                </div>
              )}

              <button
                type="submit"
                className="primaryButton"
                disabled={!isValid || loading} // Disable if the form is invalid or loading
              >
                {loading ? "Loading..." : "Submit"} {/* Show loading state */}
              </button>
            </form>
          ) : (
            <div className="flex flex-1 justify-center items-center w-full min-h-[80vh]">
              <p>
                The host has currently deactivated posting for this content
                page.
              </p>
            </div>
          )}
          <Toaster />
        </div>
      </MemberAuthProvider>
    </div>
  );
};

export default PublicContentForm;
