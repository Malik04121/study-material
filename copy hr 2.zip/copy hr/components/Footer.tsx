import Image from "next/image";
import Link from "next/link";
import React from "react";

const Footer = () => {
  return (
    <footer className="w-full bg-white-bg py-6 flex flex-col items-center justify-center  ">
      <div className="text-center space-y-2 mb-4">
        <p className="text-sm text-gray-500">Built with</p>
        <Image src="/logo.jpeg" alt="WA Collab Logo" width={100} height={40} />
      </div>
      {/* <div className="flex flex-col items-center space-y-4 md:flex-row md:space-y-0 md:space-x-4 w-[70%] md:w-[50%] text-center">
        <Link
          href={"/start-community"}
          target="_blank"
          className=" bg-white border-primaryBlack  border  disabled:bg-opacity-50 text-primaryBlack  px-3 py-3 font-normal rounded-xl w-full"
        >
          Create your community
        </Link>
      </div> */}
    </footer>
  );
};

export default Footer;
