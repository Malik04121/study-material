import React, { ReactNode } from "react";
import { createPortal } from "react-dom";

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  children: ReactNode;
  width?: string;
  isCloseRequire?: boolean;
}

const Modal = ({
  isOpen,
  onClose,
  children,
  width,
  isCloseRequire = true,
}: ModalProps) => {
  if (!isOpen) return null;

  return createPortal(
    <div className="fixed desktopView inset-0 flex items-center justify-center bg-primaryBlack  bg-opacity-50 z-[1000]">
      <div
        className={`bg-white rounded-lg shadow-lg p-5 relative max-h-[90vh] overflow-auto ${
          width && `w-[${width}%]`
        }`}
        style={{
          width: `${width}%`,
        }}
      >
        {isCloseRequire && (
          <button
            className="absolute top-2 right-2 text-gray-600 text-lg"
            onClick={onClose}
          >
            &times;
          </button>
        )}
        {children}
      </div>
    </div>,
    document.body
  );
};

export default Modal;
