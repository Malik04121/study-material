"use client";
import React, { useEffect } from "react";
import { useRouter } from "next/navigation";
import axios from "axios";

type Props = {
  communityId: string; // Assuming you pass the community ID as a prop
  children: React.ReactNode; // The content that will be displayed if the user is authorized
};

const MemberAuthProvider = ({ communityId, children }: Props) => {
  const router = useRouter();

  useEffect(() => {
    const checkUserAuth = async () => {
      try {
        // Step 1: Check if the user is logged in
        const userResponse = await axios.get("/api/users/check-user");
        const user = userResponse.data.user;

        if (!user) {
          // User is not logged in, redirect to login page
          router.push("/login");
          return;
        }

        const userCommunityDetails = user.communityDetails.find(
          (community: any) => community.communityId === communityId
        );

        if (!userCommunityDetails) {
          // User is not a member of this community, redirect to unauthorized page
          router.push("/unauthorized");
          return;
        }

        // Step 3: Check if the user's memberId is in the community's approvedMembers list
        const communityResponse = await axios.get(
          `/api/community/get-by-id/${communityId}`
        );
        const community = communityResponse.data.community;

        if (!community) {
          // Community not found, redirect to unauthorized page
          router.push("/unauthorized");
          return;
        }
        console.log(userCommunityDetails);
        console.log(community);
        // Step 3: Check if the logged-in user is an approved member of the community
        const isMemberApproved = community.approvedMembers.some(
          (member: any) => member.userId._id === user._id
        );
        console.log(isMemberApproved);

        if (!isMemberApproved) {
          // User is not an approved member, redirect to unauthorized page
          router.push("/unauthorized");
          return;
        }
      } catch (error) {
        console.error("Error checking user authentication:", error);
        // In case of any error, redirect to unauthorized page
        router.push("/unauthorized");
      }
    };

    checkUserAuth();
  }, [communityId, router]);

  // Render children only if the user is authenticated and authorized
  return <>{children}</>;
};

export default MemberAuthProvider;
