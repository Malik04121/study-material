import Image from "next/image";
import React from "react";

type Props = {
  CommunityName: string;
};

const CommunityProfileCard = (props: Props) => {
  return (
    <div className="relative bg-white bg-opacity-50 rounded-xl w-full min-w-[300px] py-20">
      <div className="absolute -top-[15%] left-1/2 transform -translate-x-1/2 rounded-full w-20 h-20   border-2 border-white overflow-clip">
        <Image
          src={"/assets/default/defaultCommunityImg.jpg"}
          alt="community_img"
          width={70}
          height={70}
          className="w-full h-full "
        />
      </div>
      <div className="flex flex-col justify-center items-center gap-5 ">
        <h2 className="text-2xl text-primaryBlack  font-bold ">
          {props.CommunityName}
        </h2>
        <p className="text-lg text-primaryBlack   font-light">Hosted by you</p>
      </div>
      <hr className="w-[90%] mx-auto border border-primaryBlack  h-[1px]" />
    </div>
  );
};

export default CommunityProfileCard;
