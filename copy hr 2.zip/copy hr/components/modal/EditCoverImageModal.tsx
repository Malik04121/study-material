import React, { useRef, useState } from "react";
import Modal from "../reusable/Modal";
import Image from "next/image";

interface EditCoverImageModalProps {
  isOpen: boolean;
  onClose: () => void;
  onFileChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
  onDelete: () => void;
  galleryImages: string[];
  onSelectGalleryImage: (url: string) => void;
}

const EditCoverImageModal = ({
  isOpen,
  onClose,
  onFileChange,
  onDelete,
  galleryImages,
  onSelectGalleryImage,
}: EditCoverImageModalProps) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [activeTab, setActiveTab] = useState("upload");

  const handleUpdateClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} width={"90"}>
      <div className="flex flex-col space-y-4">
        <div className="flex justify-start border-b">
          <button
            className={`p-2 ${
              activeTab === "upload" ? "border-b-2 border-yellow-500" : ""
            }`}
            onClick={() => setActiveTab("upload")}
          >
            Upload
          </button>
          <button
            className={`p-2 ${
              activeTab === "gallery" ? "border-b-2 border-yellow-500" : ""
            }`}
            onClick={() => setActiveTab("gallery")}
          >
            Gallery
          </button>
        </div>

        {activeTab === "upload" && (
          <div className="flex flex-col items-center space-y-4">
            <p className="text-center text-sm">
              Recommended size: 1920x1080 (16:9) and less than 10MB.
            </p>
            <div className="border-dashed border-2 border-gray-300 p-6 w-full flex flex-col items-center justify-center rounded-md">
              {/* <p className="text-center mb-2">Drag & Drop to Upload</p> */}
              <p className="text-center text-sm text-gray-500">
                Supported files: png, jpg, jpeg
              </p>
              <button
                onClick={handleUpdateClick}
                className="mt-4 bg-gray-200 text-black px-4 py-2 rounded-md"
              >
                Add from computer
              </button>
            </div>
            <input
              type="file"
              ref={fileInputRef}
              onChange={onFileChange}
              className="hidden"
              accept="image/*"
            />
          </div>
        )}

        {activeTab === "gallery" && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
            {galleryImages.map((image, index) => (
              <div
                key={index}
                className="relative w-full h-20 border rounded-xl overflow-hidden cursor-pointer"
                onClick={() => onSelectGalleryImage(image)}
              >
                <Image
                  src={image}
                  alt={`gallery_image_${index}`}
                  layout="fill"
                  className="object-cover"
                />
              </div>
            ))}
          </div>
        )}
      </div>
    </Modal>
  );
};

export default EditCoverImageModal;
