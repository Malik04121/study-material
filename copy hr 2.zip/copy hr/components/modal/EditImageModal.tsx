"use client";
import { useRef } from "react";
import Modal from "../reusable/Modal";

interface EditImageModalProps {
  isOpen: boolean;
  onClose: () => void;
  onFileChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
  onDelete: () => void;
  avatar: string;
}

const EditImageModal = ({
  isOpen,
  onClose,
  onFileChange,
  onDelete,
  avatar,
}: EditImageModalProps) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleUpdateClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };
  console.log(avatar);

  return (
    <Modal isOpen={isOpen} onClose={onClose} width={"90"}>
      <div className="flex flex-col space-y-4">
        <p className="text-center text-lg font-semibold">
          Change Profile Photo
        </p>
        <div className="flex justify-around items-center gap-2">
          <button
            onClick={handleUpdateClick}
            className="   bg-primaryBlack  disabled:bg-[#D3D0D0] text-white px-2 py-3 font-light rounded-xl w-full  sm:text-nowrap "
          >
            Change Photo
          </button>
          {avatar !==
            "https://hr-network-assets.s3.ap-south-1.amazonaws.com/profile-default-icon-512x511-v4sw4m29.png" && (
            <button
              onClick={onDelete}
              className="   bg-red-100   disabled:bg-[#D3D0D0] text-red-500 px-2 py-3 font-light rounded-xl w-full sm:text-nowrap "
            >
              Delete Photo
            </button>
          )}
        </div>
        <input
          type="file"
          ref={fileInputRef}
          onChange={onFileChange}
          className="hidden"
          accept="image/*"
        />
      </div>
    </Modal>
  );
};

export default EditImageModal;
