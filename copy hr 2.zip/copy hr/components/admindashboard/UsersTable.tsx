import { FC } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import Image from "next/image";
import { User } from "@/types/user.types"; // Adjust the import path based on your project structure
import { Card } from "../ui/card";
import { Skeleton } from "@/components/ui/skeleton"; // Import the Skeleton component

interface UserTableProps {
  users: User[];
  loading: boolean; // Add a loading prop to handle loading state
}

const UserTable: FC<UserTableProps> = ({ users, loading }) => {
  return (
    <Card x-chunk="dashboard-01-chunk-3">
      <div className="p-4">
        <h2 className="text-xl font-semibold">User Analysis</h2>
        <p className="text-sm text-muted-foreground">
          This table provides an analysis of users, including their avatar,
          name, mobile number, the number of communities they host, and the
          number of communities they are members of.
        </p>
      </div>
      <div className="max-h-[500px] overflow-y-scroll">
        {" "}
        {/* Fixed height and scroll */}
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className=""> </TableHead>
              <TableHead className="text-center"> Name</TableHead>
              <TableHead className="text-center"> Mobile Number</TableHead>
              <TableHead className="text-center"> Email</TableHead>
              <TableHead className="text-center">Communities as Host</TableHead>
              <TableHead className="text-center">
                Communities as Member
              </TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading
              ? // Render skeleton rows if loading is true
                Array.from({ length: 5 }).map((_, index) => (
                  <TableRow key={index}>
                    <TableCell className="text-center">
                      <Skeleton className="w-16 h-16 mx-auto rounded-full" />
                    </TableCell>
                    <TableCell className="text-center">
                      <Skeleton className="h-4 w-32 mx-auto" />
                    </TableCell>
                    <TableCell className="text-center">
                      <Skeleton className="h-4 w-32 mx-auto" />
                    </TableCell>
                    <TableCell className="text-center">
                      <Skeleton className="h-4 w-40 mx-auto" />
                    </TableCell>
                    <TableCell className="text-center">
                      <Skeleton className="h-4 w-16 mx-auto" />
                    </TableCell>
                    <TableCell className="text-center">
                      <Skeleton className="h-4 w-16 mx-auto" />
                    </TableCell>
                  </TableRow>
                ))
              : users.map((user) => {
                  if (!user.isVerified) {
                    return null; // Skip unverified users
                  }
                  const hostCount = user.communityDetails.filter(
                    (detail) => detail.role === "Host"
                  ).length;
                  const memberCount = user.communityDetails.filter(
                    (detail) => detail.role !== "Host"
                  ).length;

                  return (
                    <TableRow key={user._id}>
                      <TableCell className="text-center flex justify-center items-center">
                        <div className="flex justify-center items-center w-16 h-16">
                          <Image
                            src={user.avatar || "/default-avatar.png"}
                            alt={user.fullName}
                            width={50} // Set width
                            height={50} // Set height
                            className="object-center w-full h-full rounded-full" // Ensures image covers the area without stretching
                          />
                        </div>
                      </TableCell>
                      <TableCell className="text-center text-nowrap">
                        {user.fullName}
                      </TableCell>
                      <TableCell className="text-center text-nowrap">
                        {user.phoneNumber}
                      </TableCell>
                      <TableCell className="text-center">
                        {user.email}
                      </TableCell>
                      <TableCell className="text-center">{hostCount}</TableCell>
                      <TableCell className="text-center">
                        {memberCount}
                      </TableCell>
                    </TableRow>
                  );
                })}
          </TableBody>
        </Table>
      </div>
    </Card>
  );
};

export default UserTable;
