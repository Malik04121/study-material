"use client";
import Link from "next/link";
import { Activity, CreditCard, Users, Package2 } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useRouter } from "next/navigation";
import { useSignOut } from "react-firebase-hooks/auth";
import { auth } from "@/firebaseConfig/firebase";

import { useEffect, useState } from "react";
import { CommunityDetails } from "@/types/communityDetails.types";
import axios from "axios";
import Image from "next/image";
import { User } from "@/types/user.types";
import CommunityTable from "./CommunityTable";
import UserTable from "./UsersTable";
import CommunityDetail from "./CommunityDetailPage";
import useCountUp from "@/customHooks/UseCountUp";
export function Dashboard() {
  const [selectedCommunity, setSelectedCommunity] =
    useState<CommunityDetails | null>(null);

  const [signOut, loadingSignOut, error] = useSignOut(auth);
  const router = useRouter();

  const [communities, setCommunities] = useState<CommunityDetails[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true); // Add loading state
  let countOfTotalRecords = 0;
  let countOfContentType = 0;

  const handleLogout = async () => {
    try {
      await signOut();
      router.push("/admin/login"); // Redirect to login after logout
    } catch (error) {
      console.error("Error logging out:", error);
    }
  };

  const fetchAllCommunity = async () => {
    try {
      const response = await axios.get("/api/community");
      if (response.data) {
        const originalCommunities = response.data.communities;
        // const duplicatedCommunities = originalCommunities.flatMap(
        //   (community: CommunityDetails) => Array(5).fill(community)
        // );
        setCommunities(originalCommunities);
      }
    } catch (error) {
      console.log(error);
    }
  };

  const fetchAllUsers = async () => {
    try {
      const response = await axios.get("/api/users");
      if (response.data) {
        const originalUsers = response.data.users;

        setUsers(originalUsers);
      }
    } catch (error) {
      console.log(error);
    }
  };

  const handleCommunityClick = (community: CommunityDetails) => {
    setSelectedCommunity(community);
  };

  useEffect(() => {
    const fetchData = async () => {
      await fetchAllCommunity();
      await fetchAllUsers();
      setLoading(false); // Set loading to false after data is fetched
    };
    fetchData();
  }, []);

  if (communities) {
    communities.forEach((community) => {
      community.contentTypes.forEach((contentType) => {
        countOfTotalRecords += contentType.records.length;
      });
    });
    communities.forEach((community) => {
      countOfContentType += community.contentTypes.length;
    });
  }

  const totalCommunities = useCountUp(communities.length, 2); // Animate over 2 seconds
  const totalUsers = useCountUp(users.length, 2);
  const totalRecords = useCountUp(countOfTotalRecords, 2);
  const totalContentTypes = useCountUp(countOfContentType, 2);

  return (
    <div className="flex min-h-screen w-full flex-col">
      <header className="sticky top-0 flex h-16 justify-between w-full items-center gap-4 border-b bg-background px-4 md:px-6 z-20">
        <nav className="hidden flex-col gap-6 text-lg font-medium md:flex md:flex-row md:items-center md:gap-5 md:text-sm lg:gap-6">
          <div className="flex items-center gap-2 text-lg font-semibold md:text-base">
            <Package2 className="h-6 w-6" />
            <span className="sr-only">Acme Inc</span>
          </div>
          <div className="text-foreground transition-colors hover:text-foreground">
            Dashboard
          </div>
        </nav>

        <div className="flex w-full items-center justify-end gap-4 md:ml-auto md:gap-2 lg:gap-4">
          <Button variant={"destructive"} onClick={handleLogout}>
            Logout
          </Button>
        </div>
      </header>
      {communities && users && !selectedCommunity && (
        <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
          <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-2 md:gap-8 lg:grid-cols-4">
            <Card x-chunk="dashboard-01-chunk-0">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Total Communities
                </CardTitle>

                <Image
                  src={"/assets/icons/communities.png"}
                  alt="public"
                  width={20}
                  height={20}
                  className="h-6 w-6 text-muted-foreground"
                />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">+{totalCommunities}</div>
                <p className="text-xs text-muted-foreground"></p>
              </CardContent>
            </Card>
            <Card x-chunk="dashboard-01-chunk-1">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Total Users
                </CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">+{totalUsers}</div>
                <p className="text-xs text-muted-foreground"></p>
              </CardContent>
            </Card>
            <Card x-chunk="dashboard-01-chunk-2">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Total records
                </CardTitle>
                <CreditCard className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">+{totalRecords}</div>
                <p className="text-xs text-muted-foreground"></p>
              </CardContent>
            </Card>
            <Card x-chunk="dashboard-01-chunk-3">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Total Content Types
                </CardTitle>
                <Activity className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">+{totalContentTypes}</div>
                <p className="text-xs text-muted-foreground"></p>
              </CardContent>
            </Card>
          </div>
          <div className="flex flex-col justify-between gap-4 md:gap-8">
            <CommunityTable
              communities={communities}
              onCommunityClick={handleCommunityClick}
              loading={loading} // Pass the loading state
            />
            <UserTable users={users} loading={loading} />{" "}
            {/* Pass the loading state */}
          </div>
        </main>
      )}
      {selectedCommunity && (
        <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
          <CommunityDetail
            selectedCommunity={selectedCommunity}
            setSelectedCommunity={setSelectedCommunity}
          />
        </main>
      )}
    </div>
  );
}
