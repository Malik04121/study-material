import { FC, useState } from "react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import Image from "next/image";
import { CommunityDetails } from "@/types/communityDetails.types";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Button } from "../ui/button";

interface CommunityDetailProps {
  selectedCommunity: CommunityDetails;
  setSelectedCommunity: (community: CommunityDetails | null) => void;
}

const CommunityDetail: FC<CommunityDetailProps> = ({
  selectedCommunity,
  setSelectedCommunity,
}) => {
  const [currentTab, setCurrentTab] = useState<
    "approved" | "rejected" | "pending"
  >("approved");

  const filteredMembers = (status: "approved" | "rejected" | "pending") => {
    let members: any[] = [];
    if (status === "approved") {
      members = selectedCommunity.approvedMembers;
    } else if (status === "pending") {
      members = selectedCommunity.pendingMembers;
    } else if (status === "rejected") {
      members = selectedCommunity.rejectedMembers;
    }

    return members.map((member) => ({
      avatar: member.userId.avatar,
      fullName: member.userId.fullName,
      email: member.userId.email,
      phoneNumber: member.userId.phoneNumber,
      applicationSubmittedDate: member.applicationSubmittedDate,
      joinDate: member.joinDate,
      rejectedDate: member.rejectedDate,
    }));
  };

  const members = filteredMembers(currentTab);
  const contentTypes = selectedCommunity.contentTypes;

  return (
    <div className="p-4 sm:p-6 lg:p-8">
      <div className="flex flex-col sm:flex-row justify-between items-center w-full mb-6 lg:mb-10">
        <h2 className="text-xl sm:text-2xl font-semibold">
          {selectedCommunity.title}
        </h2>
        <Button
          onClick={() => setSelectedCommunity(null)}
          className="mt-4 sm:mt-0"
        >
          Back to Dashboard
        </Button>
      </div>

      <Card>
        <CardHeader className="flex flex-col sm:flex-row sm:items-center justify-between space-y-2 sm:space-y-0 pb-2 mb-4">
          <CardTitle className="text-lg sm:text-xl font-medium">
            Member Details
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs
            value={currentTab}
            onValueChange={(value) => setCurrentTab(value as typeof currentTab)}
          >
            <TabsList className="mb-4">
              <TabsTrigger value="approved">Approved</TabsTrigger>
              <TabsTrigger value="pending">Pending</TabsTrigger>
              <TabsTrigger value="rejected">Rejected</TabsTrigger>
            </TabsList>

            <TabsContent value={currentTab}>
              {members.length > 0 ? (
                <div className="max-h-[400px] h-[500px] overflow-y-scroll">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="text-center  sm:table-cell"></TableHead>
                        <TableHead className="text-center">Name</TableHead>
                        <TableHead className="text-center  sm:table-cell">
                          Email
                        </TableHead>
                        <TableHead className="text-center  sm:table-cell">
                          Phone
                        </TableHead>
                        <TableHead className="text-center">
                          Application Date
                        </TableHead>
                        <TableHead className="text-center  sm:table-cell">
                          Joined Date
                        </TableHead>
                        <TableHead className="text-center  sm:table-cell">
                          Rejected Date
                        </TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {members.map((member, index) => (
                        <TableRow key={index}>
                          <TableCell className="text-center  sm:table-cell">
                            <div className="flex justify-center items-center w-10 h-10">
                              <Image
                                src={member.avatar || "/default-avatar.png"}
                                alt={member.fullName}
                                width={40}
                                height={40}
                                className="object-center w-full h-full rounded-full"
                              />
                            </div>
                          </TableCell>
                          <TableCell className="text-center text-nowrap">
                            {member.fullName}
                          </TableCell>
                          <TableCell className="text-center  sm:table-cell">
                            {member.email}
                          </TableCell>
                          <TableCell className="text-center  sm:table-cell text-nowrap">
                            {member.phoneNumber}
                          </TableCell>
                          <TableCell className="text-center">
                            {new Date(
                              member.applicationSubmittedDate
                            ).toLocaleDateString()}
                          </TableCell>
                          <TableCell className="text-center  sm:table-cell">
                            {member.joinDate
                              ? new Date(member.joinDate).toLocaleDateString()
                              : currentTab === "approved"
                              ? new Date(
                                  member.applicationSubmittedDate
                                ).toLocaleDateString()
                              : "N/A"}
                          </TableCell>
                          <TableCell className="text-center  sm:table-cell">
                            {member.rejectedDate
                              ? new Date(
                                  member.rejectedDate
                                ).toLocaleDateString()
                              : "N/A"}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              ) : (
                <div className="h-[300px] sm:h-[400px] flex flex-col items-center justify-center">
                  <Image
                    src="/assets/icons/members.png"
                    alt="No matches found"
                    width={30}
                    height={30}
                  />
                  <p className="text-lg sm:text-xl text-primaryBlack mt-4">
                    No matches found.
                  </p>
                  <p className="text-sm text-gray-500">
                    Tweak your search and filters.
                  </p>
                  <button
                    className="mt-6 px-4 py-2 text-white bg-black rounded-full"
                    onClick={() => setCurrentTab("approved")} // Example action to reset filters
                  >
                    Reset Filters
                  </button>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {contentTypes.length > 0 && (
        <Card className="mt-6 lg:mt-8">
          <CardHeader className="flex flex-col sm:flex-row sm:items-center justify-between space-y-2 sm:space-y-0 pb-2 mb-4">
            <CardTitle className="text-lg sm:text-xl font-medium">
              Content Types
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="max-h-[400px] h-[500px]  overflow-y-scroll">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-center">Title</TableHead>
                    <TableHead className="text-center  sm:table-cell">
                      Description
                    </TableHead>
                    <TableHead className="text-center">Records</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {contentTypes.map((contentType, index) => (
                    <TableRow key={index}>
                      <TableCell className="text-center">
                        {contentType.title}
                      </TableCell>
                      <TableCell className="text-center  sm:table-cell ">
                        {contentType.description}
                      </TableCell>
                      <TableCell className="text-center">
                        {contentType.records.length}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default CommunityDetail;
