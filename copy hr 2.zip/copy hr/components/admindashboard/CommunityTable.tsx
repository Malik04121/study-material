import { FC } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import Image from "next/image";
import { CommunityDetails } from "@/types/communityDetails.types"; // Adjust the import path based on your project structure
import { Card } from "../ui/card";
import { Skeleton } from "@/components/ui/skeleton"; // Import the Skeleton component

interface CommunityTableProps {
  communities: CommunityDetails[];
  onCommunityClick: (community: CommunityDetails) => void;
  loading: boolean; // Add a loading prop to handle loading state
}

const CommunityTable: FC<CommunityTableProps> = ({
  communities,
  onCommunityClick,
  loading,
}) => {
  return (
    <Card x-chunk="dashboard-01-chunk-3">
      <div className="p-4">
        <h2 className="text-xl font-semibold">Community Analysis</h2>
        <p className="text-sm text-muted-foreground">
          This table provides an analysis of communities. Click on a row to view
          more details.
        </p>
      </div>
      <div className="max-h-[500px] overflow-y-scroll">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="text-center"></TableHead>
              <TableHead className="text-center">Title</TableHead>
              <TableHead className="text-center">Host Name</TableHead>
              <TableHead className="text-center">Approved Members</TableHead>
              <TableHead className="text-center">Pending Members</TableHead>
              <TableHead className="text-center">Rejected Members</TableHead>
              <TableHead className="text-center">Content Types </TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading
              ? // Render skeleton rows if loading is true
                Array.from({ length: 5 }).map((_, index) => (
                  <TableRow key={index}>
                    <TableCell className="text-center">
                      <Skeleton className="w-16 h-16 mx-auto" />
                    </TableCell>
                    <TableCell className="text-center">
                      <Skeleton className="h-4 w-32 mx-auto" />
                    </TableCell>
                    <TableCell className="text-center">
                      <Skeleton className="h-4 w-32 mx-auto" />
                    </TableCell>
                    <TableCell className="text-center">
                      <Skeleton className="h-4 w-16 mx-auto" />
                    </TableCell>
                    <TableCell className="text-center">
                      <Skeleton className="h-4 w-16 mx-auto" />
                    </TableCell>
                    <TableCell className="text-center">
                      <Skeleton className="h-4 w-16 mx-auto" />
                    </TableCell>
                    <TableCell className="text-center">
                      <Skeleton className="h-4 w-16 mx-auto" />
                    </TableCell>
                  </TableRow>
                ))
              : // Render actual table rows if loading is false
                communities.map((community) => (
                  <TableRow
                    key={community._id}
                    onClick={() => onCommunityClick(community)}
                    className="cursor-pointer"
                  >
                    <TableCell className="text-center flex justify-center items-center">
                      <div className="w-16 h-16 flex justify-center items-center">
                        <Image
                          src={community.logoImage || "/default-logo.png"}
                          alt={community.title}
                          width={50}
                          height={50}
                          className="object-cover w-full h-full object-center rounded-md"
                        />
                      </div>
                    </TableCell>
                    <TableCell className="text-center">
                      {community.title}
                    </TableCell>
                    <TableCell className="text-center text-nowrap text-nowrap">
                      {community.hostName}
                    </TableCell>
                    <TableCell className="text-center">
                      {community.approvedMembers.length}
                    </TableCell>
                    <TableCell className="text-center">
                      {community.pendingMembers.length}
                    </TableCell>
                    <TableCell className="text-center">
                      {community.rejectedMembers.length}
                    </TableCell>
                    <TableCell className="text-center">
                      {community.contentTypes.length}
                    </TableCell>
                  </TableRow>
                ))}
          </TableBody>
        </Table>
      </div>
    </Card>
  );
};

export default CommunityTable;
