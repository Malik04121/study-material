interface User {
  _id: string;
  avatar: string;
  email: string;
  isVerified: boolean;
  communityDetails: string[];
  __v: number;
  expiryDateForOTP: string;
  otpForVerification: number;
  fullName: string;
  phoneNumber: string;
}

export interface MemberDetails {
  applicationSubmittedDate: string;
  joinDate?: string;
  rejectedDate?: string;
  userId: User;
  removalReason: string;
  __v: number;
  _id: string;
  additionalFields?: { [key: string]: any }; // Added field to store additional details in key-value pairs
}

export interface CommunityDetails {
  applicationFields: Array<{
    typeOfField: string;
    isRequired: boolean;
    labelName: string;
    options?: string[]; // Added options for select fields
  }>;
  approvedMembers: MemberDetails[];
  coverImage: string;
  host: string; // Assuming this is an ObjectId string
  isApplicationRequire: boolean;
  isAutoApproveMembership: boolean;
  logoImage: string;
  hostName?: string;
  welcomeMessageSubject: string;
  welcomeMessageContent: string;
  whatsUpGroupLink: string;
  description?: string;
  pendingMembers: MemberDetails[];
  publicPageUrl: string;
  rejectedMembers: MemberDetails[];
  contentTypes: ContentType[];
  title: string;
  __v: number;
  _id: string; // Assuming this is an ObjectId string
}
export interface ContentType {
  _id: string;
  title: string;
  description: string;
  isActive: boolean;
  contentTypeForm: ContentTypeFormType[];
  tags: string[];
  records: RecordType[]; // Changed from string[] to RecordType[]
  __v: number;
}

interface ContentTypeFormType {
  typeOfField: string;
  isRequired: boolean;
  labelName: string;
  options: string[];
  _id: string;
}

export interface RecordType {
  _id: string;
  memberDetails: MemberDetailsType;
  recordFields: RecordFieldsType;
  createDate: string;
  __v: number;
}

interface MemberDetailsType {
  _id: string;
  userId: UserType;
  applicationSubmittedDate: string;
  joinDate: string | null;
  rejectedDate: string | null;
  removalReason: string;
  additionalFields: Record<string, any>;
  __v: number;
}

interface UserType {
  _id: string;
  avatar: string;
  email: string;
  isVerified: boolean;
  phoneNumber: string;
  communityDetails: CommunityDetailsType[];
  __v: number;
  expiryDateForOTP: string;
  otpForVerification: number;
  fullName: string;
}

interface CommunityDetailsType {
  communityTitle: string;
  communityId: string;
  communityLogo: string;
  memberId: string;
  role: string;
  _id: string;
}

interface RecordFieldsType {
  [key: string]: string; // Dynamic keys with string values for record fields
}
