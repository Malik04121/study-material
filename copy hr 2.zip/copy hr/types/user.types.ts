interface CommunityDetail {
  communityTitle: string;
  communityId: string;
  memberId: string;
  role: string;
  _id: string;
  communityLogo: string;
  publicPageUrl: string;
  logoImage: string;
}
export enum CommunityStatus {
  HOST = "Host",
  Member = "Member",
  PENDING = "Pending",
  NEW = "New",
}

export interface User {
  _id: string;
  avatar: string;
  email: string;
  isVerified: boolean;
  communityDetails: CommunityDetail[];
  __v: number;
  expiryDateForOTP: string;
  otpForVerification: number;
  fullName: string;
  phoneNumber: string;
  communityStatus: CommunityStatus;
}
