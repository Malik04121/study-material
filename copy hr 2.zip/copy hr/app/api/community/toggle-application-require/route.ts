import { NextRequest, NextResponse } from "next/server";
import { connect } from "@/dbConfig/dbConnect";
import Community from "@/models/CommunityModel";

connect();

export async function POST(request: NextRequest) {
  try {
    const reqBody = await request.json();
    const { communityId, isApplicationRequire } = reqBody;

    if (!communityId) {
      return NextResponse.json(
        {
          message: "Community ID is required",
          success: false,
        },
        { status: 400 }
      );
    }

    const updatedCommunity = await Community.findByIdAndUpdate(
      communityId,
      { isApplicationRequire },
      { new: true }
    );

    if (!updatedCommunity) {
      return NextResponse.json(
        {
          message: "Community not found",
          success: false,
        },
        { status: 404 }
      );
    }

    return NextResponse.json(
      {
        message: "Application requirement updated successfully",
        success: true,
        community: updatedCommunity,
      },
      { status: 200 }
    );
  } catch (error: any) {
    console.error("Error updating application requirement:", error);
    return NextResponse.json(
      {
        message: "Error updating application requirement",
        success: false,
        error: error.message,
      },
      { status: 500 }
    );
  }
}
