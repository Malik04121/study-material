// pages/api/createCommunity.ts

import { connect } from "@/dbConfig/dbConnect";
import Community from "@/models/CommunityModel";
import Member from "@/models/MemberModel";
import User from "@/models/UserModel";
import { NextApiResponse } from "next";
import { NextRequest, NextResponse } from "next/server";
import { SESClient, SendEmailCommand } from "@aws-sdk/client-ses";




const { NEXT_PUBLIC_ACCESS_KEY, NEXT_PUBLIC_SECRET_KEY, NEXT_PUBLIC_REGION } =
  process.env;

const sesClient = new SESClient({
  region: NEXT_PUBLIC_REGION,
  credentials: {
    accessKeyId: NEXT_PUBLIC_ACCESS_KEY!,
    secretAccessKey: NEXT_PUBLIC_SECRET_KEY!,
  },
});

connect();

export async function POST(request: NextRequest, response: NextApiResponse) {
  const reqBody = await request.json();
  const {
    communityId,
    memberId,
    userId,
    receiverEmail,
    isApprovedMember,
    isRejectedMember,
    reasonForRemoval,
    isCustomReason,
    fromHost,
  } = reqBody;

  if (!communityId || !memberId) {
    return NextResponse.json(
      {
        message: "Community ID and Member ID are required",
        success: false,
      },
      { status: 404 }
    );
  }
  let user;
  try {
    user = await User.findById(userId);
    if (!user) {
      return NextResponse.json(
        {
          message: "User not found",
          success: false,
        },
        { status: 404 }
      );
    }

    // Check if the user has communityDetails for the given communityId
    const userCommunityDetail = user.communityDetails.find(
      (detail: any) => detail.communityId === communityId
    );

    if (userCommunityDetail) {
      // Check if memberId is in the rejectedMembers array of the community
      const community = await Community.findById(communityId);
      if (
        community &&
        community.rejectedMembers.includes(userCommunityDetail.memberId)
      ) {
        // Remove memberId from rejectedMembers
        await Community.findByIdAndUpdate(
          communityId,
          {
            $pull: {
              rejectedMembers: userCommunityDetail.memberId,
            },
          },
          { new: true }
        );

        // Remove the corresponding communityDetails record from the user document
        await User.findByIdAndUpdate(
          userId,
          {
            $pull: {
              communityDetails: { memberId: userCommunityDetail.memberId },
            },
          },
          { new: true }
        );

        // Delete the memberId from the Member collection
        await Member.findByIdAndDelete(userCommunityDetail.memberId);
      }
    }

    let updatedCommunity;
    let userEmail = "";

    if (isRejectedMember) {
      const community = await Community.findById(communityId);

      if (community) {
        const userInApprovedMembers =
          community.approvedMembers.includes(memberId);

        const user = await User.findOne({ email: receiverEmail });
        console.log(user);

        if (user) {
          userEmail = user.email;
          let subject, content;

          if (userInApprovedMembers) {
            subject = `[${community.title}], You have been removed from the community`;
            content = `
              <p>Hello ${user.fullName},</p>
              <p>${community.hostName} has removed you from ${
              community.title
            }. You will not be able to access the community.</p>
            ${
              isCustomReason
                ? `<p>Reason for Removal: ${reasonForRemoval}</p>`
                : ""
            }`;
          } else {
            subject = `Your application to join ${community.title} is not approved`;
            content = `
              <p>Hello,</p>
              <p>Thank you for your interest in joining ${
                community.title
              }. We have carefully considered your application, unfortunately we won't be able to accept it at this time.</p>
               ${
                 isCustomReason
                   ? `<p>Reason for Removal: ${reasonForRemoval}</p>`
                   : ""
               }
              <p>We appreciate the time you took to apply.</p>
              
            `;
          }

          // Send rejection email
          const emailParams = {
            Source: "jatinp8390@gmail.com",
            Destination: {
              ToAddresses: [receiverEmail],
            },
            Message: {
              Subject: {
                Data: subject,
              },
              Body: {
                Html: {
                  Data: `
                    <!DOCTYPE html>
                    <html lang="en">
                    <head>
                      <meta charset="UTF-8">
                      <meta name="viewport" content="width=device-width, initial-scale=1.0">
                      <title>${subject}</title>
                      <style>
                        body {
                          font-family: Arial, sans-serif;
                          background-color: #f4f4f4;
                          color: #333;
                          margin: 0;
                          padding: 0;
                        }
                        .container {
                          width: 100%;
                          max-width: 600px;
                          margin: 0 auto;
                          background-color: #fff;
                          padding: 20px;
                          box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                          border-radius: 8px;
                        }
                        .header {
                          background-color: #151515;
                          padding: 10px 20px;
                          color: #fff;
                          border-radius: 8px 8px 0 0;
                          text-align: center;
                        }
                        .header h1 {
                          margin: 0;
                          font-size: 24px;
                        }
                        .content {
                          padding: 20px;
                          text-align: left;
                        }
                        .content p {
                          font-size: 16px;
                          font-weight: semibold;
                          margin: 10px 0;
                        }
                        .footer {
                          margin-top: 20px;
                          font-size: 12px;
                          color: #777;
                          text-align: left;
                        }
                      </style>
                    </head>
                    <body>
                      <div class="container">
                        <div class="header">
                          <h1>${community.title}</h1>
                        </div>
                        <div class="content">
                          ${content}
                        </div>
                        <div class="footer">
                          <p>&copy; ${new Date().getFullYear()} WA Collab. All rights reserved.</p>
                        </div>
                      </div>
                    </body>
                    </html>
                  `,
                },
              },
            },
          };

          const res = await sesClient.send(new SendEmailCommand(emailParams));
          console.log(res);
        }
      }
      updatedCommunity = await Community.findByIdAndUpdate(
        communityId,
        {
          $push: {
            rejectedMembers: memberId,
          },
          $pull: {
            pendingMembers: memberId,
            approvedMembers: memberId,
          },
        },
        { upsert: true, new: true }
      );
      await Member.findByIdAndUpdate(memberId, {
        rejectedDate: Date.now(),
        removalReason: reasonForRemoval,
      });
    } else if (isApprovedMember) {
      console.log("called");

      updatedCommunity = await Community.findByIdAndUpdate(
        communityId,
        {
          $push: {
            approvedMembers: memberId,
          },
          $pull: {
            pendingMembers: memberId,
          },
        },
        { upsert: true, new: true }
      );
      await Member.findByIdAndUpdate(memberId, {
        joinDate: Date.now(),
      });

      const user = await User.findOne({ email: receiverEmail });
      console.log(user);

      const community = await Community.findById(communityId);
      console.log(user);

      if (user && community) {
        userEmail = user.email;
        const welcomeSubject = community.welcomeMessageSubject;
        const welcomeContent = community.welcomeMessageContent
          .replace("{name}", user.fullName)
          .replace("{community_name}", community.title);

        // Send welcome email
        const emailParams = {
          Source: "jatinp8390@gmail.com",
          Destination: {
            ToAddresses: [receiverEmail],
          },
          Message: {
            Subject: {
              Data: welcomeSubject,
            },
            Body: {
              Html: {
                Data: `
                  <!DOCTYPE html>
                  <html lang="en">
                  <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <title>${welcomeSubject}</title>
                    <style>
                      body {
                        font-family: Arial, sans-serif;
                        background-color: #f4f4f4;
                        color: #333;
                        margin: 0;
                        padding: 0;
                      }
                      .container {
                        width: 100%;
                        max-width: 600px;
                        margin: 0 auto;
                        background-color: #fff;
                        padding: 20px;
                        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                        border-radius: 8px;
                      }
                      .header {
                        background-color: #151515;
                        padding: 10px 20px;
                        color: #fff;
                        border-radius: 8px 8px 0 0;
                        text-align: center;
                      }
                      .header h1 {
                        margin: 0;
                        font-size: 24px;
                      }
                      .content {
                        padding: 20px;
                        text-align: center;
                      }
                      .content p {
                        font-size: 16px;
                        font-weight: semibold;
                      }
                      .footer {
                        margin-top: 20px;
                        font-size: 12px;
                        color: #777;
                        text-align: center;
                      }
                    </style>
                  </head>
                  <body>
                    <div class="container">
                      <div class="header">
                        <h1>${community.title}</h1>
                      </div>
                      <div class="content">
                        ${welcomeContent}
                      </div>
                      <div class="footer">
                        <p>&copy; ${new Date().getFullYear()} WA Collab. All rights reserved.</p>
                      </div>
                    </div>
                  </body>
                  </html>
                `,
              },
            },
          },
        };

        const res = await sesClient.send(new SendEmailCommand(emailParams));
        console.log(res);
      }
    } else {
      updatedCommunity = await Community.findByIdAndUpdate(
        communityId,
        {
          $push: {
            pendingMembers: memberId,
          },
        },
        { upsert: true, new: true }
      );
      const user = await User.findById(userId);
      const community = await Community.findById(communityId);
      console.log(user);

      if (user && community) {
        userEmail = user.email;
        const pendingApprovalSubject = `You are pending approval for ${community.title}`;
        const pendingApprovalContent = `
          <p>Welcome ${user.fullName},</p>
          <p>Thank you so much for applying to ${community.title}!</p>
          <p>Did you know that we handpick every person who joins our community? It’s what makes the experience so valuable for all of our super talented members.</p>
          <p>You will receive an email when your application is approved.</p>
        `;

        // Send pending approval email
        const emailParams = {
          Source: "jatinp8390@gmail.com",
          Destination: { ToAddresses: [userEmail] },
          Message: {
            Subject: { Data: pendingApprovalSubject },
            Body: {
              Html: {
                Data: `
                  <!DOCTYPE html>
                  <html lang="en">
                  <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <title>${pendingApprovalSubject}</title>
                    <style>
                      body {
                        font-family: Arial, sans-serif;
                        background-color: #f4f4f4;
                        color: #333;
                        margin: 0;
                        padding: 0;
                      }
                      .container {
                        width: 100%;
                        max-width: 600px;
                        margin: 0 auto;
                        background-color: #fff;
                        padding: 20px;
                        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                        border-radius: 8px;
                      }
                      .header {
                        background-color: #151515;
                        padding: 10px 20px;
                        color: #fff;
                        border-radius: 8px 8px 0 0;
                        text-align: center;
                      }
                      .header h1 {
                        margin: 0;
                        font-size: 24px;
                      }
                      .content {
                        padding: 20px;
                        text-align: left;
                      }
                      .content p {
                        font-size: 16px;
                        font-weight: semibold;
                        margin: 10px 0;
                      }
                      .footer {
                        margin-top: 20px;
                        font-size: 12px;
                        color: #777;
                        text-align: left;
                      }
                      .manager-info {
                        display: flex;
                        align-items: center;
                        margin-top: 20px;
                      }
                      .manager-info img {
                        width: 50px;
                        height: 50px;
                        border-radius: 50%;
                        margin-right: 10px;
                      }
                    </style>
                  </head>
                  <body>
                    <div class="container">
                      <div class="header">
                        <h1>You are pending approval for ${community.title}</h1>
                      </div>
                      <div class="content">
                        ${pendingApprovalContent}
                        
                      </div>
                      <div class="footer">
                        <p>&copy; ${new Date().getFullYear()} WA Collab. All rights reserved.</p>
                      </div>
                    </div>
                  </body>
                  </html>
                `,
              },
            },
          },
        };

        const res = await sesClient.send(new SendEmailCommand(emailParams));
        console.log(res);
      }
    }

    const updateCommunity = await updatedCommunity.save();
    if (fromHost) {
      return NextResponse.json(
        {
          message: "Community details added successfully.",
          user: user,
          community: updateCommunity,
        },
        { status: 200 }
      );
    }
    const communityDetails = {
      communityTitle: updateCommunity.title,
      communityId: updateCommunity._id.toString(),
      role: "Member",
      memberId: memberId,
      communityLogo: updateCommunity.logoImage,
    };

    let updatedUser = await User.findByIdAndUpdate(
      userId,
      {
        $push: {
          communityDetails: communityDetails,
        },
      },
      { upsert: true, new: true }
    );

    let updateUser = await updatedUser.save();

    return NextResponse.json(
      {
        message: "Community details added successfully.",
        user: updateUser,
        community: updateCommunity,
      },
      { status: 200 }
    );
  } catch (error) {
    return NextResponse.json(
      { error: "Error updating community details to user." },
      { status: 500 }
    );
  }
}
