import { connect } from "@/dbConfig/dbConnect";
import { NextRequest, NextResponse } from "next/server";
import Community from "@/models/CommunityModel";

connect();
export async function PUT(request: NextRequest) {
  try {
    const reqBody = await request.json();
    const { communityID, imageUrl, isLogo } = reqBody;

    if (!imageUrl) {
      return NextResponse.json(
        { error: "Provide new Logo url" },
        { status: 400 }
      );
    }
    if (!communityID) {
      return NextResponse.json(
        { error: "Provide new Community Id" },
        { status: 400 }
      );
    }
    if (isLogo) {
      let updateCommunity = await Community.findByIdAndUpdate(
        communityID,
        {
          logoImage: imageUrl,
        },

        { upsert: true, new: true }
      );

      let updatedCommunity = await updateCommunity.save();

      return NextResponse.json(
        {
          message: "Community logo updated successfully",
          community: updatedCommunity,
        },
        { status: 200 }
      );
    } else {
      let updateCommunity = await Community.findByIdAndUpdate(
        communityID,
        {
          coverImage: imageUrl,
        },

        { upsert: true, new: true }
      );

      let updatedCommunity = await updateCommunity.save();

      return NextResponse.json(
        {
          message: "Community logo updated successfully",
          community: updatedCommunity,
        },
        { status: 200 }
      );
    }
  } catch (error: any) {
    return NextResponse.json(
      { error: "Error while updating Community logo" },
      { status: 500 }
    );
  }
}
