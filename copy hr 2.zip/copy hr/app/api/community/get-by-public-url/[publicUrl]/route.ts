import { NextRequest, NextResponse } from "next/server";
import { connect } from "@/dbConfig/dbConnect";
import Community from "@/models/CommunityModel";
import Member from "@/models/MemberModel";
import User from "@/models/UserModel";
import ContentType from "@/models/ContentTypeModel";
import ContentRecord from "@/models/ContentRecords";

connect();

export async function GET(
  request: NextRequest,
  { params }: { params: { publicUrl: string } }
) {
  try {
    const { publicUrl } = params;

    if (!publicUrl) {
      return NextResponse.json(
        {
          message: "Please provide a publicPageUrl",
          success: false,
        },
        { status: 400 }
      );
    }

    const decodedUrl = decodeURIComponent(publicUrl);
    console.log(decodedUrl);

    const community = await Community.findOne({
      publicPageUrl: decodedUrl,
    })
      .populate({
        path: "approvedMembers",
        model: Member,
        populate: {
          path: "userId",
          model: User,
        },
      })
      .populate({
        path: "pendingMembers",
        model: Member,
        populate: {
          path: "userId",
          model: User,
        },
      })
      .populate({
        path: "rejectedMembers",
        model: Member,
        populate: {
          path: "userId",
          model: User,
        },
      })
      .populate({
        path: "contentTypes",
        model: ContentType, // This should match the name used when defining the ContentType model
        populate: [
          {
            path: "records",
            model: ContentRecord, // Ensure this matches your ContentRecord model name
            populate: {
              path: "memberDetails",
              model: Member, // Ensure this matches your Member model name
              populate: {
                path: "userId",
                model: User, // Ensure this matches your User model name
              },
            },
          },
        ],
      });

    if (!community) {
      return NextResponse.json(
        {
          message: "Community not found!",
          success: false,
        },
        { status: 404 }
      );
    }

    return NextResponse.json(
      {
        message: "Community found successfully!",
        success: true,
        community,
      },
      { status: 200 }
    );
  } catch (error: any) {
    console.error(error);

    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
