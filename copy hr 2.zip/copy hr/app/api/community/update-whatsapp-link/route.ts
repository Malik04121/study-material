import { connect } from "@/dbConfig/dbConnect";
import Community from "@/models/CommunityModel";
import { NextApiResponse } from "next";
import { NextRequest, NextResponse } from "next/server";

connect();

export async function POST(request: NextRequest, response: NextApiResponse) {
  const reqBody = await request.json();
  const { communityId, whatsAppLink } = reqBody;

  if (!communityId) {
    return NextResponse.json(
      {
        message: "Community ID is required",
        success: false,
      },
      { status: 400 }
    );
  }

  try {
    let updateData = {};
    if (whatsAppLink !== undefined) {
      updateData = { whatsUpGroupLink: whatsAppLink };
    } else {
      updateData = { $unset: { whatsUpGroupLink: "" } };
    }

    const community = await Community.findByIdAndUpdate(
      communityId,
      updateData,
      { new: true }
    );

    if (!community) {
      return NextResponse.json(
        {
          message: "Community not found",
          success: false,
        },
        { status: 404 }
      );
    }

    return NextResponse.json(
      {
        message: "WhatsApp link updated successfully",
        success: true,
        community,
      },
      { status: 200 }
    );
  } catch (error) {
    return NextResponse.json(
      { error: "Error updating WhatsApp link" },
      { status: 500 }
    );
  }
}
