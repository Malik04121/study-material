import { connect } from "@/dbConfig/dbConnect";
import Community from "@/models/CommunityModel";
import Member from "@/models/MemberModel";
import User from "@/models/UserModel";
import { NextApiResponse } from "next";
import { NextRequest, NextResponse } from "next/server";

connect();

export async function POST(request: NextRequest, response: NextApiResponse) {
  try {
    const reqBody = await request.json();
    const { communityId, userId } = reqBody;

    if (!communityId || !userId) {
      return NextResponse.json(
        { message: "Community ID and User ID are required", success: false },
        { status: 400 }
      );
    }

    // Find the user
    const user = await User.findById(userId);
    console.log(user);

    if (!user) {
      return NextResponse.json(
        { message: "User not found", success: false },
        { status: 404 }
      );
    }

    // Find the community details for the given community in the user's communityDetails array
    const userCommunityDetail = user.communityDetails.find(
      (detail: any) => detail.communityId === communityId
    );

    if (!userCommunityDetail) {
      return NextResponse.json(
        { message: "Community details not found in user", success: false },
        { status: 404 }
      );
    }

    console.log(userCommunityDetail);
    const memberId = userCommunityDetail.memberId;
    console.log(memberId);

    // Update the community by pulling the memberId from the pendingMembers array
    const updateCommunity = await Community.findByIdAndUpdate(
      communityId,
      { $pull: { pendingMembers: memberId } },
      { new: true }
    );

    if (!updateCommunity) {
      return NextResponse.json(
        { message: "Community not found", success: false },
        { status: 404 }
      );
    }
    await updateCommunity.save();
    // Update the user by pulling the communityId from the communityDetails array
    await User.updateOne(
      { _id: userId },
      { $pull: { communityDetails: { communityId: communityId } } }
    );
    // Optionally, remove the Member document if necessary
    const deletedMember = await Member.findByIdAndDelete(memberId);

    if (!deletedMember) {
      return NextResponse.json(
        { message: "Member not found", success: false },
        { status: 404 }
      );
    }

    return NextResponse.json(
      { message: "Pending request withdrawn successfully.", success: true },
      { status: 200 }
    );
  } catch (error: any) {
    return NextResponse.json(
      {
        message: error.message || "Error withdrawing pending request.",
        success: false,
      },
      { status: 500 }
    );
  }
}
