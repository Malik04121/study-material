import { NextRequest, NextResponse } from "next/server";
import { connect } from "@/dbConfig/dbConnect";
import Community from "@/models/CommunityModel";

connect();

export async function POST(request: NextRequest) {
  try {
    const reqBody = await request.json();
    const { communityId, applicationFields } = reqBody;

    console.log(applicationFields);

    if (!communityId || !applicationFields) {
      return NextResponse.json(
        {
          message: "Community ID and application fields are required",
          success: false,
        },
        { status: 400 }
      );
    }

    // Validate application fields
    for (const field of applicationFields) {
      if (
        (field.typeOfField === "single-select" ||
          field.typeOfField === "multi-select") &&
        (!Array.isArray(field.options) || field.options.length === 0)
      ) {
        return NextResponse.json(
          {
            message: `Options are required for ${field.typeOfField} field`,
            success: false,
          },
          { status: 400 }
        );
      }
    }

    // Ensure the options field is included in the update
    const updatedCommunity = await Community.findByIdAndUpdate(
      communityId,
      {
        $set: { applicationFields },
      },
      { new: true }
    );

    if (!updatedCommunity) {
      return NextResponse.json(
        {
          message: "Community not found",
          success: false,
        },
        { status: 404 }
      );
    }

    return NextResponse.json(
      {
        message: "Application fields updated successfully",
        success: true,
        community: updatedCommunity,
      },
      { status: 200 }
    );
  } catch (error: any) {
    console.error("Error updating application fields:", error);
    return NextResponse.json(
      {
        message: "Error updating application fields",
        success: false,
        error: error.message,
      },
      { status: 500 }
    );
  }
}
