// app/api/community/toggle-access/route.ts
import { NextRequest, NextResponse } from "next/server";
import { connect } from "@/dbConfig/dbConnect";
import Community from "@/models/CommunityModel";

connect();

export async function POST(request: NextRequest) {
  const { communityId, isAutoApproveMembership } = await request.json();

  if (!communityId) {
    return NextResponse.json(
      { success: false, message: "Community ID is required" },
      { status: 400 }
    );
  }

  try {
    const community = await Community.findByIdAndUpdate(
      communityId,
      { isAutoApproveMembership },
      { new: true }
    );

    return NextResponse.json({ success: true, community });
  } catch (error) {
    return NextResponse.json(
      { success: false, message: "Server error" },
      { status: 500 }
    );
  }
}
