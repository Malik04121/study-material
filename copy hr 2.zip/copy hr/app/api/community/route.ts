// pages/api/createCommunity.ts

import { connect } from "@/dbConfig/dbConnect";
import Community from "@/models/CommunityModel";
import ContentRecord from "@/models/ContentRecords";
import ContentType from "@/models/ContentTypeModel";
import Member from "@/models/MemberModel";
import User from "@/models/UserModel";
import { NextApiResponse } from "next";
import { NextRequest, NextResponse } from "next/server";

connect();

export async function POST(request: NextRequest) {
  try {
    const reqBody = await request.json();
    const { title, host, publicPageUrl, hostName } = reqBody;

    // Validate if community title and publicPageUrl are provided
    if (!title || !publicPageUrl) {
      return NextResponse.json(
        { error: "Community title and publicPageUrl are required" },
        { status: 400 }
      );
    }

    // Restricted public page URLs
    const restrictedUrls = [
      "login",
      "dashboard",
      "community",
      "content-form",
      "create-account",
      "not-found",
      "portal",
      "service-unavailable",
      "start-community",
      "unauthorized",
      "update-community",
      "user",
    ];

    // Generate unique publicPageUrl for community
    let formattedPublicPageUrl = publicPageUrl
      .toLowerCase()
      .replace(/\s+/g, "-");

    let count = 1;
    while (
      restrictedUrls.includes(formattedPublicPageUrl) ||
      (await Community.findOne({ publicPageUrl: formattedPublicPageUrl }))
    ) {
      formattedPublicPageUrl = `${publicPageUrl}-${count}`;
      count++;
    }

    // Create new community instance
    const newCommunity = new Community({
      title,
      publicPageUrl: formattedPublicPageUrl,
      host,
      hostName,
      approvedMembers: [host],
    });

    // Save community to the database
    const savedCommunity = await newCommunity.save();

    return NextResponse.json(
      {
        message: "Community created successfully",
        success: true,
        community: savedCommunity,
      },
      { status: 200 }
    );
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function PUT(request: NextRequest, response: NextApiResponse) {
  const reqBody = await request.json();
  let { newPublicUrl, publicUrl, memberId } = reqBody;
  publicUrl = decodeURIComponent(publicUrl);

  try {
    // Restricted public page URLs
    const restrictedUrls = [
      "login",
      "dashboard",
      "community",
      "content-form",
      "create-account",
      "not-found",
      "portal",
      "service-unavailable",
      "start-community",
      "unauthorized",
      "update-community",
      "user",
    ];

    let formattedPublicPageUrl = decodeURIComponent(newPublicUrl)
      .toLowerCase()
      .trim()
      .replace(/\s\s+/g, " ")
      .replace(/\s+/g, "-");

    let count = 1;
    while (
      restrictedUrls.includes(formattedPublicPageUrl) ||
      (await Community.findOne({ publicPageUrl: formattedPublicPageUrl }))
    ) {
      formattedPublicPageUrl = `${formattedPublicPageUrl}-${count}`;
      count++;
    }

    const community = await Community.findOneAndUpdate(
      { publicPageUrl: publicUrl },
      {
        publicPageUrl: formattedPublicPageUrl,
      },
      { new: true }
    );

    if (!community) {
      return NextResponse.json(
        {
          message: "Community not found!",
          success: false,
        },
        { status: 400 }
      );
    }

    return NextResponse.json(
      {
        message: "Community updated successfully!",
        success: true,
        community: community,
      },
      { status: 200 }
    );
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function GET(request: NextRequest) {
  try {
    const community = await Community.find()
      .populate({
        path: "approvedMembers",
        model: Member,
        populate: {
          path: "userId",
          model: User,
        },
      })
      .populate({
        path: "pendingMembers",
        model: Member,
        populate: {
          path: "userId",
          model: User,
        },
      })
      .populate({
        path: "rejectedMembers",
        model: Member,
        populate: {
          path: "userId",
          model: User,
        },
      })
      .populate({
        path: "contentTypes",
        model: ContentType, // This should match the name used when defining the ContentType model
        populate: [
          {
            path: "records",
            model: ContentRecord, // Ensure this matches your ContentRecord model name
            populate: {
              path: "memberDetails",
              model: Member, // Ensure this matches your Member model name
              populate: {
                path: "userId",
                model: User, // Ensure this matches your User model name
              },
            },
          },
        ],
      });

    if (!community) {
      return NextResponse.json(
        {
          message: "Community not found!",
          success: false,
        },
        { status: 404 }
      );
    }

    return NextResponse.json(
      {
        message: "Community found successfully!",
        success: true,
        communities: community,
      },
      { status: 200 }
    );
  } catch (error: any) {
    console.error(error);

    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
