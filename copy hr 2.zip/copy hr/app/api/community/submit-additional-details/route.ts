import { NextRequest, NextResponse } from "next/server";
import { connect } from "@/dbConfig/dbConnect";
import Member from "@/models/MemberModel";

connect();

export async function POST(request: NextRequest) {
  try {
    const reqBody = await request.json();
    const { additionalDetails, userId } = reqBody;

    if (!userId || !additionalDetails) {
      return NextResponse.json(
        {
          message: "User ID and additional details are required",
          success: false,
        },
        { status: 400 }
      );
    }

    // Convert arrays to comma-separated strings
    const formattedAdditionalDetails: any = {};
    for (const key in additionalDetails) {
      if (Array.isArray(additionalDetails[key])) {
        formattedAdditionalDetails[key] = additionalDetails[key].join(", ");
      } else {
        formattedAdditionalDetails[key] = additionalDetails[key];
      }
    }

    const newMember = new Member({
      userId: userId,
      applicationSubmittedDate: new Date(),
      additionalFields: formattedAdditionalDetails,
    });

    const updatedMember = await newMember.save();
    console.log(updatedMember);

    return NextResponse.json(
      {
        message: "Additional details submitted successfully",
        success: true,
        member: updatedMember,
      },
      { status: 200 }
    );
  } catch (error: any) {
    console.error("Error submitting additional details:", error);
    return NextResponse.json(
      {
        message: "Error submitting additional details",
        success: false,
        error: error.message,
      },
      { status: 500 }
    );
  }
}
