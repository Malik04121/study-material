import { connect } from "@/dbConfig/dbConnect";
import { NextRequest, NextResponse } from "next/server";
import Community from "@/models/CommunityModel";

connect();
export async function PUT(request: NextRequest) {
  try {
    const reqBody = await request.json();
    const { communityID, description, hostName, title } = reqBody;

    if (!hostName) {
      return NextResponse.json({ error: "Provide host name" }, { status: 400 });
    }
    if (!title) {
      return NextResponse.json({ error: "Provide title" }, { status: 400 });
    }
    if (!communityID) {
      return NextResponse.json(
        { error: "Provide new Community Id" },
        { status: 400 }
      );
    }

    let updateCommunity = await Community.findByIdAndUpdate(
      communityID,
      {
        title: title,
        description: description,
        hostName: hostName,
      },

      { upsert: true, new: true }
    );

    let updatedCommunity = await updateCommunity.save();

    return NextResponse.json(
      {
        message: "Community details updated successfully",
        community: updatedCommunity,
      },
      { status: 200 }
    );
  } catch (error: any) {
    return NextResponse.json(
      { error: "Error while updating Community logo" },
      { status: 500 }
    );
  }
}
