// app/api/community/update-welcome-message/route.ts
import { NextRequest, NextResponse } from "next/server";
import { connect } from "@/dbConfig/dbConnect";
import Community from "@/models/CommunityModel";

connect();

export async function POST(request: NextRequest) {
  const { communityId, welcomeMessageSubject, welcomeMessageContent } =
    await request.json();

  if (!communityId || !welcomeMessageSubject || !welcomeMessageContent) {
    return NextResponse.json(
      { success: false, message: "Missing required fields" },
      { status: 400 }
    );
  }

  try {
    const community = await Community.findByIdAndUpdate(
      communityId,
      { welcomeMessageSubject, welcomeMessageContent },
      { new: true }
    );

    return NextResponse.json({ success: true, community });
  } catch (error) {
    return NextResponse.json(
      { success: false, message: "Server error" },
      { status: 500 }
    );
  }
}
