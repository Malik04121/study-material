import { connect } from "@/dbConfig/dbConnect";
import User from "@/models/UserModel";
import { NextRequest, NextResponse } from "next/server";
import bcryptjs from "bcryptjs";
import jwt from "jsonwebtoken";

connect();

export async function POST(request: NextRequest) {
  try {
    const reqBody = await request.json();
    const { email } = reqBody;
    console.log(reqBody);

    //check if user exists
    const user = await User.findOne({ email });
    if (!user) {
      return NextResponse.json(
        { error: "Your email is invalid or does not exist" },
        { status: 400 }
      );
    } else {
      // const tokenData = {
      //   id: user._id,
      //   email: user.email,
      // };
      // //create token
      // let token = await jwt.sign(
      //   tokenData,
      //   process.env.NEXT_PUBLIC_TOKEN_SECRET!,
      //   {
      //     expiresIn: "30d",
      //   }
      // );

      const response = NextResponse.json(
        { error: "Your email is valid" },
        { status: 200 }
      );

      // response.cookies.set("token", token, {
      //   httpOnly: true,
      // });
      return response;
    }
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
