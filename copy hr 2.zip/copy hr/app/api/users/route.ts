import { connect } from "@/dbConfig/dbConnect";
import User from "@/models/UserModel";
import Member from "@/models/MemberModel";
import { NextRequest, NextResponse } from "next/server";
import bcryptjs from "bcryptjs";
import mongoose, { Document } from "mongoose";
import jwt from "jsonwebtoken";
import { getDataFromToken } from "@/helper/getDataFromToken";

connect();

export async function POST(request: NextRequest) {
  let savedUser; // Declare savedUser outside the try-catch block

  try {
    const reqBody = await request.json();
    const { email, fullName, phoneNumber } = reqBody;

    // Start a session for transaction
    const session = await mongoose.startSession();
    session.startTransaction();

    try {
      // const phoneExists = await User.findOne({ phoneNumber });
      // console.log(phoneExists);

      // if (phoneExists !== null) {
      //   return NextResponse.json(
      //     {
      //       message: "Phone number is already in use",
      //       success: false,
      //     },
      //     { status: 409 } // Conflict status code
      //   );
      // }
      // Hash password
      // Check if user already exists
      const existingUser = await User.findOneAndUpdate(
        { email },
        {
          fullName,
          phoneNumber,
          isVerified: true,
        },
        { new: true }
      );

      if (!existingUser) {
        return NextResponse.json(
          {
            message: "Email id not found",
            success: false,
          },
          { status: 404 }
        );
      }
      // Save user
      savedUser = await existingUser.save({ session });

      // Create member associated with the user
      // const newMember = new Member({
      //   userId: savedUser._id,
      //   applicationSubmittedDate: new Date(),
      // });

      // Save member
      // await newMember.save({ session });

      // Commit the transaction
      await session.commitTransaction();
      session.endSession();

      // Generate token
      const tokenData = {
        id: savedUser._id,
        email: savedUser.email,
      };
      const token = jwt.sign(tokenData, process.env.NEXT_PUBLIC_TOKEN_SECRET!, {
        expiresIn: "30d",
      });

      // Return success response with token in cookie
      const response = NextResponse.json(
        {
          message: "User and member created successfully",
          success: true,
          savedUser,
          // newMember,
        },
        { status: 200 }
      );
      response.cookies.set("token", token, {
        httpOnly: true,
        maxAge: 86400, // 1 day in seconds
        path: "/", // Specify the path as needed
      });
      return response;
    } catch (error: any) {
      // Rollback if there's an error
      await session.abortTransaction();
      session.endSession();

      // Delete the user if it was created before the error
      if (savedUser && error instanceof mongoose.Error) {
        await User.deleteOne({ _id: savedUser._id });
      }

      return NextResponse.json({ error: error.message }, { status: 500 });
    }
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const reqBody = await request.json();
    const { newCommunity } = reqBody;

    if (!newCommunity) {
      return NextResponse.json(
        { error: "Provide community details" },
        { status: 400 }
      );
    }

    const data = getDataFromToken(request);

    if (!data.id) {
      return NextResponse.json(
        { error: "You are unauthorized." },
        { status: 401 }
      );
    }

    const communityDetails = {
      communityTitle: newCommunity.title,
      communityId: newCommunity._id.toString(),
      role: "Host",
      memberId: newCommunity.host.toString(),
      communityLogo: newCommunity.logoImage,
    };
    let user = await User.findOneAndUpdate(
      { email: data.email },
      {
        $push: {
          communityDetails: communityDetails,
        },
      },
      { upsert: true, new: true }
    );

    let updatedUser = await user.save();
    console.log("User after pushing to communityDetails:", updatedUser);

    return NextResponse.json(
      { message: "Community details added successfully.", user: updatedUser },
      { status: 200 }
    );
  } catch (error: any) {
    console.error("Error adding community details to user:", error);
    return NextResponse.json(
      { error: "Error adding community details to user." },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const users = await User.find();

    return NextResponse.json(
      {
        message: "Users found successfully!",
        success: true,
        users: users,
      },
      { status: 200 }
    );
  } catch (error: any) {
    console.error(error);

    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
