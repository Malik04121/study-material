import { connect } from "@/dbConfig/dbConnect";
import User from "@/models/UserModel";
import Community from "@/models/CommunityModel";
import { NextRequest, NextResponse } from "next/server";
import { getDataFromToken } from "@/helper/getDataFromToken";
import mongoose from "mongoose";

connect();

export async function GET(request: NextRequest) {
  try {
    // Extract user data from the token
    const data = getDataFromToken(request);

    if (!data.id) {
      return NextResponse.json({ error: "Token is invalid" }, { status: 404 });
    }

    // Find the user by ID
    let user = await User.findById(data.id);

    if (!user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }

    // Populate the communityDetails with publicPageUrl, logoImage, and approvedMembers fields of the associated communities
    const populatedUser = await User.findById(data.id).populate({
      path: "communityDetails.communityId",
      select: "publicPageUrl logoImage approvedMembers",
      model: Community,
    });

    if (!populatedUser) {
      return NextResponse.json(
        { error: "User not found after population" },
        { status: 404 }
      );
    }

    // Map and filter the populated data back to the user’s communityDetails array
    const updatedCommunityDetails = user.communityDetails
      .filter((detail: { communityId: string; memberId: string }) => {
        const community = populatedUser.communityDetails.find(
          (popDetail: { communityId: mongoose.Types.ObjectId }) =>
            popDetail.communityId &&
            popDetail.communityId._id.toString() === detail.communityId
        );
        if (!community || !community.communityId.approvedMembers) return false;
        return community.communityId.approvedMembers
          .map((id: mongoose.Types.ObjectId) => id.toString())
          .includes(detail.memberId);
      })
      .map((detail: { communityId: string; toObject: () => any }) => {
        const community = populatedUser.communityDetails.find(
          (popDetail: { communityId: mongoose.Types.ObjectId }) =>
            popDetail.communityId &&
            popDetail.communityId._id.toString() === detail.communityId
        );
        return {
          ...detail.toObject(),
          publicPageUrl: community ? community.communityId.publicPageUrl : null,
          logoImage: community ? community.communityId.logoImage : null,
        };
      });

    // Return the updated user object with populated and filtered communityDetails
    return NextResponse.json(
      {
        message: "User found successfully.",
        user: { ...user.toObject(), communityDetails: updatedCommunityDetails },
      },
      { status: 200 }
    );
  } catch (error: any) {
    console.error("Error occurred:", error);
    return NextResponse.json(
      { error: "An unexpected error occurred." },
      { status: 500 }
    );
  }
}
