import { NextRequest, NextResponse } from "next/server";
import jwt from "jsonwebtoken";

export async function GET(request: NextRequest) {
  const token = request.cookies.get("token")?.value;

  if (token) {
    try {
      // Here you can add any additional logic to handle the token, such as logging or database updates

      // Create the response and set the token cookie with an expired date to delete it
      const response = NextResponse.json({
        message: "Token verified and deleted successfully",
        isTokenPresent: true,
      });
      response.cookies.set("token", "", { expires: new Date(0) }); // Deleting the token by setting it with an expired date
      return response;
    } catch (error: any) {
      return NextResponse.json({ message: "Invalid token" }, { status: 401 });
    }
  }

  return NextResponse.json(
    { message: "Token not found", isTokenPresent: false },
    { status: 200 }
  );
}
