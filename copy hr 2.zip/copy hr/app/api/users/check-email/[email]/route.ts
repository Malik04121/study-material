import { connect } from "@/dbConfig/dbConnect";
import User from "@/models/UserModel";
import { NextRequest, NextResponse } from "next/server";
import jwt from "jsonwebtoken";

connect();

export const GET = async function (
  req: NextRequest,
  { params }: { params: { email: string } }
) {
  const { email } = params;
  let token = "";
  if (!email) {
    return NextResponse.json(
      {
        message: "Provide Email address",
      },
      { status: 400 }
    );
  }
  function generateTenDigitNumber() {
    // Generate a random 10-digit number
    // Math.random() generates a number between 0 and 1, so we multiply it by 10^10 to get a 10-digit number
    const number = Math.floor(1000000000 + Math.random() * 9000000000);

    return number.toString(); // Convert to string if you need it as a string
  }

  // Example usage
  const tenDigitNumber = generateTenDigitNumber();
  try {
    const user = await User.findOne({ email });
    console.log(user);

    if (!user) {
      console.log("create new");

      try {
        const newUser = new User({
          email,
          phoneNumber: tenDigitNumber,
        });
        await newUser.save();
        console.log("newUser,", newUser);
        //create token data

        const response = NextResponse.json({
          message: "Create User successful",
          success: true,
          user: newUser,
        });

        console.log(response);

        return response;
      } catch (error: any) {
        return NextResponse.json(
          {
            message: "Internal server error",
            success: false,
            error: error.message, // optionally include error message in the response
          },
          { status: 500 }
        );
      }
    } else {
      const response = NextResponse.json({
        message: " User sets ",
        success: true,
        user: user,
      });

      return response;
    }
  } catch (error: any) {
    return NextResponse.json(
      {
        message: "Internal server error",
        success: false,
        error: error.message, // optionally include error message in the response
      },
      { status: 500 }
    );
  }
};
