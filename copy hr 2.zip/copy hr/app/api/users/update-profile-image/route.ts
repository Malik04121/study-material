import { connect } from "@/dbConfig/dbConnect";
import User from "@/models/UserModel";

import { NextRequest, NextResponse } from "next/server";

import { getDataFromToken } from "@/helper/getDataFromToken";

connect();
export async function PUT(request: NextRequest) {
  try {
    const reqBody = await request.json();
    const { imageUrl } = reqBody;

    if (!imageUrl) {
      return NextResponse.json(
        { error: "Provide new Avatar url" },
        { status: 400 }
      );
    }

    const data = getDataFromToken(request);

    if (!data.id) {
      return NextResponse.json(
        { error: "You are unauthorized." },
        { status: 401 }
      );
    }

    let user = await User.findOneAndUpdate(
      { email: data.email },
      {
        avatar: imageUrl,
      },
      { upsert: true, new: true }
    );

    let updatedUser = await user.save();

    return NextResponse.json(
      { message: "User avatar updated successfully", user: updatedUser },
      { status: 200 }
    );
  } catch (error: any) {
    return NextResponse.json(
      { error: "Error while updating User avatar." },
      { status: 500 }
    );
  }
}
