import { NextRequest, NextResponse } from "next/server";

export async function DELETE(request: NextRequest) {
  const token = request.cookies.get("token")?.value;

  if (token) {
    // Here you can add any additional logic to handle the token deletion, such as logging or database updates

    const response = NextResponse.json({
      message: "Token deleted successfully",
    });
    response.cookies.set("token", "", { expires: new Date(0) }); // Setting the token cookie with an expired date to delete it
    return response;
  }

  return NextResponse.json({ message: "Token not found" }, { status: 200 });
}
