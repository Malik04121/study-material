import { NextRequest, NextResponse } from "next/server";
import { connect } from "@/dbConfig/dbConnect";

import User from "@/models/UserModel";
import { getDataFromToken } from "@/helper/getDataFromToken";
import { log } from "console";

connect();

export async function PUT(request: NextRequest) {
  try {
    const reqBody = await request.json();
    const { fullName, email, phoneNumber, avatar } = reqBody; // Assuming these are the fields you can update
    console.log(fullName, email, phoneNumber, avatar);

    // Retrieve user data from token or session
    const data = getDataFromToken(request);

    // Validate authorization
    if (!data.id) {
      return NextResponse.json(
        { error: "You are unauthorized." },
        { status: 401 }
      );
    }

    // Update user profile in database
    const updatedUser = await User.findOneAndUpdate(
      { email: data.email },
      { fullName, email, phoneNumber, avatar }, // Fields to update
      { new: true } // Return updated document
    );

    if (!updatedUser) {
      return NextResponse.json({ error: "User not found." }, { status: 404 });
    }
    let updateUser = await updatedUser.save();

    return NextResponse.json(
      { message: "User profile updated successfully", user: updateUser },
      { status: 200 }
    );
  } catch (error: any) {
    console.error("Error updating user profile:", error);
    return NextResponse.json(
      { error: "Error updating user profile." },
      { status: 500 }
    );
  }
}
