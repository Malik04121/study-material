import { connect } from "@/dbConfig/dbConnect";
import Member from "@/models/MemberModel";
import User from "@/models/UserModel";
import { NextRequest, NextResponse } from "next/server";
import jwt from "jsonwebtoken";

connect();

export const POST = async function (request: NextRequest) {
  const reqBody = await request.json();
  const { email, otp, isCheckOtpVerificationOnly } = reqBody;
  let onlyCheckOtpVerification = isCheckOtpVerificationOnly
    ? isCheckOtpVerificationOnly
    : false;
  if (!email) {
    return NextResponse.json(
      {
        message: "Provide Email address",
      },
      { status: 400 }
    );
  }
  if (!otp) {
    return NextResponse.json(
      {
        message: "Provide OTP",
      },
      { status: 400 }
    );
  }

  try {
    const user = await User.findOne({ email });

    if (!user) {
      return NextResponse.json(
        {
          message: "User not found",
        },
        { status: 404 }
      );
    }

    // Check if OTP matches
    if (user.otpForVerification !== parseInt(otp)) {
      return NextResponse.json(
        {
          message: "You have entered the incorrect OTP.",
        },
        { status: 400 }
      );
    }

    // Check if OTP is expired
    const currentTime = new Date();
    if (user.expiryDateForOTP && currentTime > user.expiryDateForOTP) {
      return NextResponse.json(
        {
          message: "OTP is invalid or expired",
        },
        { status: 400 }
      );
    } else {
      if (user.isVerified && !onlyCheckOtpVerification) {
        try {
          const newMember = new Member({
            userId: user._id,
            applicationSubmittedDate: new Date(),
          });

          await newMember.save();
          const tokenData = {
            id: user._id,
            email: user.email,
          };
          //create token
          let token = await jwt.sign(
            tokenData,
            process.env.NEXT_PUBLIC_TOKEN_SECRET!,
            {
              expiresIn: "30d",
            }
          );
          const response = NextResponse.json({
            message: "OTP verification successful",
            success: true,
            user: user,
            newMember,
          });
          response.cookies.set("token", token, {
            httpOnly: true,
          });
          return response;
        } catch (error) {
          return NextResponse.json({
            message: "OTP verification successful",
            success: true,
            user: user,
          });
        }
      }
      const tokenData = {
        id: user._id,
        email: user.email,
      };
      //create token
      let token = await jwt.sign(
        tokenData,
        process.env.NEXT_PUBLIC_TOKEN_SECRET!,
        {
          expiresIn: "30d",
        }
      );
      const response = NextResponse.json({
        message: "OTP verification successful",
        success: true,
        user: user,
      });
      response.cookies.set("token", token, {
        httpOnly: true,
      });
      return response;
    }
  } catch (error: any) {
    return NextResponse.json(
      {
        message: "Internal server error",
        success: false,
        error: error.message, // optionally include error message in the response
      },
      { status: 500 }
    );
  }
};
