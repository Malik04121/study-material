import { getDataFromToken } from "@/helper/getDataFromToken";

import { NextRequest, NextResponse } from "next/server";
import { connect } from "@/dbConfig/dbConnect";
import User from "@/models/UserModel";
import Community from "@/models/CommunityModel";
import Member from "@/models/MemberModel";

connect();

export async function POST(request: NextRequest) {
  try {
    const reqBody = await request.json();
    const { publicUrl } = reqBody;
    const token = request.cookies.get("token")?.value || "";

    if (!token) {
      return NextResponse.json(
        {
          message: "Please provide token!",
        },
        { status: 404 }
      );
    }
    const data = getDataFromToken(request);
    console.log("data", data);

    try {
      const community = await Community.findOne({ publicPageUrl: publicUrl });
      console.log("commmunity", community);

      if (community) {
        const member = await Member.findById(community.host);
        console.log("member", member);

        if (member) {
          if (member.userId.toString() === data.id) {
            return NextResponse.json(
              {
                message: "You are authorized.",
                data: data,
              },
              { status: 200 }
            );
          }
        } else {
          return NextResponse.json(
            {
              message: "You are Unauthorized.",

              data: data,
            },
            { status: 401 }
          );
        }
      } else {
        return NextResponse.json(
          {
            message: "Community not exist",
            data: data,
          },
          { status: 404 }
        );
      }
    } catch (error) {}
    return NextResponse.json(
      {
        message: "You are Unauthorized",
        data: data,
      },
      { status: 401 }
    );
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 400 });
  }
}
