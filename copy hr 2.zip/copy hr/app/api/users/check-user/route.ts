import { connect } from "@/dbConfig/dbConnect";
import User from "@/models/UserModel";
import { NextRequest, NextResponse } from "next/server";
import { getDataFromToken } from "@/helper/getDataFromToken";

connect();

export async function GET(request: NextRequest) {
  try {
    const data = getDataFromToken(request);

    if (!data.id) {
      return NextResponse.json({ error: "Token is invalid" }, { status: 404 });
    }

    let user = await User.findById(data.id);

    if (user) {
      return NextResponse.json(
        { message: "User found successfully.", user },
        { status: 200 }
      );
    } else {
      return NextResponse.json({ error: "Token is invalid" }, { status: 404 });
    }
  } catch (error: any) {
    return NextResponse.json({ error: "Token is invalid" }, { status: 404 });
  }
}
