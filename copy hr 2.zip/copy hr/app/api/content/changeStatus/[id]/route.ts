import { NextResponse } from "next/server";
import ContentType from "@/models/ContentTypeModel"; // Adjust the path based on your project structure
import Community from "@/models/CommunityModel"; // Adjust the path based on your project structure
import { connect } from "@/dbConfig/dbConnect";

connect();

export async function PUT(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const contentTypeId = params.id;
    const { isActive } = await request.json();

    const contentType = await ContentType.findByIdAndUpdate(
      contentTypeId,
      { isActive },
      { new: true }
    );

    if (!contentType) {
      return NextResponse.json(
        { success: false, message: "Content type not found" },
        { status: 404 }
      );
    }

    return NextResponse.json(
      { success: true, data: contentType },
      { status: 200 }
    );
  } catch (error) {
    console.error("Error updating content type:", error);
    return NextResponse.json(
      { success: false, message: "Failed to update content type" },
      { status: 500 }
    );
  }
}
