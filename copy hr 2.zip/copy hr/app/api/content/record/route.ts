import { NextRequest, NextResponse } from "next/server";
import ContentType from "@/models/ContentTypeModel";
import ContentRecord from "@/models/ContentRecords";
import User from "@/models/UserModel"; // Import User model
import { connect } from "@/dbConfig/dbConnect";
import mongoose from "mongoose";
import { getDataFromToken } from "@/helper/getDataFromToken"; // Assuming you have a helper to get data from token

export async function POST(req: NextRequest) {
  await connect();

  const session = await mongoose.startSession(); // Start a new session for the transaction
  session.startTransaction(); // Begin the transaction

  try {
    const { contentId, communityId, formData } = await req.json();

    if (!contentId || !communityId || !formData) {
      throw new Error(
        "Missing contentId, communityId, or formData in the request body"
      );
    }

    // Get user data from the token
    const data = getDataFromToken(req);
    if (!data.id) {
      throw new Error("Token is invalid");
    }

    const user = await User.findById(data.id);
    if (!user) {
      throw new Error("User not found");
    }

    // Find the community in the user's communityDetails
    const userCommunityDetails = user.communityDetails.find(
      (community: any) => community.communityId === communityId
    );

    if (!userCommunityDetails) {
      throw new Error("User is not a member of the specified community");
    }

    const memberId = userCommunityDetails.memberId; // Get the member ID

    // Create a new ContentRecord within the transaction
    const newRecord = new ContentRecord({
      memberDetails: memberId, // Use the member ID from the user's community details
      recordFields: formData,
      createDate: Date.now(),
    });

    await newRecord.save({ session }); // Save the record within the transaction

    // Find the ContentType by ID and update it with the new record
    const contentType = await ContentType.findById(contentId).session(session);
    if (!contentType) {
      throw new Error("ContentType not found");
    }

    contentType.records.push(newRecord._id);
    await contentType.save({ session }); // Save the updated content type within the transaction

    await session.commitTransaction(); // Commit the transaction
    session.endSession();

    return NextResponse.json(
      { success: true, data: newRecord },
      { status: 201 }
    );
  } catch (error: any) {
    // Specific error messages for known errors
    if (error instanceof mongoose.Error.ValidationError) {
      await session.abortTransaction(); // Rollback the transaction on validation error
      session.endSession();
      return NextResponse.json(
        {
          success: false,
          message: "Validation error occurred while saving the record",
          error: error.message,
        },
        { status: 400 }
      );
    } else if (error.message === "ContentType not found") {
      await session.abortTransaction(); // Rollback the transaction if content type is not found
      session.endSession();
      return NextResponse.json(
        { success: false, message: "ContentType not found" },
        { status: 404 }
      );
    } else if (error.message === "User not found") {
      await session.abortTransaction(); // Rollback the transaction if user is not found
      session.endSession();
      return NextResponse.json(
        { success: false, message: "User not found" },
        { status: 404 }
      );
    } else if (
      error.message === "User is not a member of the specified community"
    ) {
      await session.abortTransaction(); // Rollback the transaction if user is not a member of the specified community
      session.endSession();
      return NextResponse.json(
        { success: false, message: error.message },
        { status: 403 }
      );
    } else if (
      error.message ===
      "Missing contentId, communityId, or formData in the request body"
    ) {
      await session.abortTransaction(); // Rollback the transaction for bad requests
      session.endSession();
      return NextResponse.json(
        { success: false, message: error.message },
        { status: 400 }
      );
    } else {
      // General error handler for any other errors
      console.error(
        "Error saving content record or updating content type:",
        error
      );
      await session.abortTransaction(); // Rollback the transaction on any other error
      session.endSession();
      return NextResponse.json(
        {
          success: false,
          message: "Failed to save content record or update content type",
          error: error.message || "Unknown error occurred",
        },
        { status: 500 }
      );
    }
  }
}
