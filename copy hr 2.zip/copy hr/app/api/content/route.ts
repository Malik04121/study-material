import { NextResponse } from "next/server";
import mongoose from "mongoose";
import ContentType from "@/models/ContentTypeModel"; // Adjust the path based on your project structure
import Community from "@/models/CommunityModel"; // Adjust the path based on your project structure
import { connect } from "@/dbConfig/dbConnect";

connect();

export async function POST(request: Request) {
  const session = await mongoose.startSession(); // Start a new session for the transaction
  session.startTransaction(); // Begin the transaction

  try {
    // Parse the JSON body from the request
    const body = await request.json();

    // Validate input data (optional but recommended for robust applications)
    if (
      !body.title ||
      !body.description ||
      !body.contentTypeForm ||
      !body.communityId
    ) {
      await session.abortTransaction(); // Abort the transaction in case of validation errors
      session.endSession();
      return NextResponse.json(
        { success: false, message: "Missing required fields" },
        { status: 400 }
      );
    }

    // Ensure tags are an array (optional validation)
    if (body.tags && !Array.isArray(body.tags)) {
      await session.abortTransaction(); // Abort the transaction in case of validation errors
      session.endSession();
      return NextResponse.json(
        { success: false, message: "Tags must be an array of strings" },
        { status: 400 }
      );
    }

    // Create a new content type within the transaction
    const newContentType = new ContentType({
      title: body.title,
      description: body.description,
      isActive: body.isActive ?? true, // Default to true if not provided
      contentTypeForm: body.contentTypeForm,
      records: [], // Initialize as empty array
      tags: body.tags ?? [], // Handle tags, default to empty array if not provided
    });

    await newContentType.save({ session }); // Save the content type within the transaction

    // Find the community by ID and update it by adding the new content type
    const community = await Community.findById(body.communityId).session(
      session
    );
    if (!community) {
      await session.abortTransaction(); // Abort the transaction if the community is not found
      session.endSession();
      return NextResponse.json(
        { success: false, message: "Community not found" },
        { status: 404 }
      );
    }

    // Add the newly created content type's ID to the community's contentTypes array
    community.contentTypes.push(newContentType._id);

    // Save the updated community document within the transaction
    await community.save({ session });

    await session.commitTransaction(); // Commit the transaction
    session.endSession();

    // Return a successful response with the created content type and updated community
    return NextResponse.json(
      { success: true, data: { newContentType, community } },
      { status: 201 }
    );
  } catch (error) {
    console.error("Error creating content type or updating community:", error);

    await session.abortTransaction(); // Rollback the transaction on error
    session.endSession();

    return NextResponse.json(
      {
        success: false,
        message: "Failed to create content type or update community",
      },
      { status: 500 }
    );
  }
}
