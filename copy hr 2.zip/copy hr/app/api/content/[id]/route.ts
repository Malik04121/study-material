import { NextResponse } from "next/server";
import ContentType from "@/models/ContentTypeModel"; // Adjust the path based on your project structure
import Community from "@/models/CommunityModel"; // Adjust the path based on your project structure
import { connect } from "@/dbConfig/dbConnect";
import mongoose from "mongoose";
import Member from "@/models/MemberModel";
import User from "@/models/UserModel";

connect();

export async function PUT(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const contentTypeId = params.id;

    if (!contentTypeId) {
      return NextResponse.json(
        { success: false, message: "Content type ID is required" },
        { status: 400 }
      );
    }

    const body = await request.json();
    const { title, description, contentTypeForm, tags } = body;

    // Validate required fields
    if (!title || !description || !contentTypeForm) {
      return NextResponse.json(
        { success: false, message: "Missing required fields" },
        { status: 400 }
      );
    }

    // Ensure tags is an array of strings
    if (tags && !Array.isArray(tags)) {
      return NextResponse.json(
        { success: false, message: "Tags must be an array of strings" },
        { status: 400 }
      );
    }
    console.log(contentTypeForm);

    // Find and update the content type
    const updatedContentType = await ContentType.findByIdAndUpdate(
      contentTypeId,
      { title, description, contentTypeForm, tags },
      { new: true }
    );

    if (!updatedContentType) {
      return NextResponse.json(
        { success: false, message: "Content type not found" },
        { status: 404 }
      );
    }

    return NextResponse.json(
      { success: true, data: updatedContentType },
      { status: 200 }
    );
  } catch (error) {
    console.error("Error updating content type:", error);

    if (error instanceof mongoose.Error.CastError) {
      return NextResponse.json(
        { success: false, message: "Invalid content type ID" },
        { status: 400 }
      );
    }

    return NextResponse.json(
      { success: false, message: "Failed to update content type" },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const contentTypeId = params.id;
    const contentType = await ContentType.findByIdAndDelete(contentTypeId);

    if (!contentType) {
      return NextResponse.json(
        { success: false, message: "Content type not found" },
        { status: 404 }
      );
    }

    // Optionally update the community by removing the deleted content type's ID from the contentTypes array
    await Community.updateMany(
      { contentTypes: contentTypeId },
      { $pull: { contentTypes: contentTypeId } }
    );

    return NextResponse.json(
      { success: true, message: "Content type deleted successfully" },
      { status: 200 }
    );
  } catch (error) {
    console.error("Error deleting content type:", error);
    return NextResponse.json(
      { success: false, message: "Failed to delete content type" },
      { status: 500 }
    );
  }
}

export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params;

    const contentType = await ContentType.findById(id).populate({
      path: "records",
      populate: {
        path: "memberDetails",
        model: Member,
        populate: {
          path: "userId",
          model: User,
        },
      },
    });

    if (!contentType) {
      return NextResponse.json(
        { success: false, message: "ContentType not found" },
        { status: 404 }
      );
    }

    return NextResponse.json(
      { success: true, data: contentType },
      { status: 200 }
    );
  } catch (error) {
    console.error("Error fetching ContentType:", error);
    return NextResponse.json(
      { success: false, message: "Failed to fetch ContentType" },
      { status: 500 }
    );
  }
}
