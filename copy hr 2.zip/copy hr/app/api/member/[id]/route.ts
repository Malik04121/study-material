import { NextRequest, NextResponse } from "next/server";
import { connect } from "@/dbConfig/dbConnect";
import Member from "@/models/MemberModel";

connect();

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params;

    if (!id) {
      return NextResponse.json(
        {
          message: "Please provide a member ID",
          success: false,
        },
        { status: 400 }
      );
    }

    const member = await Member.findById(id).populate("userId");

    if (!member) {
      return NextResponse.json(
        {
          message: "Member not found!",
          success: false,
        },
        { status: 404 }
      );
    }

    return NextResponse.json(
      {
        message: "Member found successfully!",
        success: true,
        member,
      },
      { status: 200 }
    );
  } catch (error: any) {
    console.error(error);

    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
