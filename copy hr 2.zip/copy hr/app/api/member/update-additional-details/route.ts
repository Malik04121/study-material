import { NextRequest, NextResponse } from "next/server";
import { connect } from "@/dbConfig/dbConnect";
import Member from "@/models/MemberModel";

connect();

export async function POST(request: NextRequest) {
  try {
    const { memberId, additionalDetails } = await request.json();

    if (!memberId || !additionalDetails) {
      return NextResponse.json(
        {
          message: "Please provide memberId and additionalDetails",
          success: false,
        },
        { status: 400 }
      );
    }

    const member = await Member.findById(memberId);
    console.log(additionalDetails);

    if (!member) {
      return NextResponse.json(
        {
          message: "Member not found!",
          success: false,
        },
        { status: 404 }
      );
    }

    member.additionalFields = new Map(Object.entries(additionalDetails));
    await member.save();

    return NextResponse.json(
      {
        message: "Additional details updated successfully!",
        success: true,
        member,
      },
      { status: 200 }
    );
  } catch (error: any) {
    console.error(error);

    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
