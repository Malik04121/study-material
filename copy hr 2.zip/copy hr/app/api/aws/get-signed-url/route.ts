import type { NextApiResponse } from "next";
import S3 from "aws-sdk/clients/s3";
import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest, res: NextApiResponse) {
  try {
    if (
      !process.env.NEXT_PUBLIC_ACCESS_KEY ||
      !process.env.NEXT_PUBLIC_SECRET_KEY ||
      !process.env.NEXT_PUBLIC_REGION
    ) {
      throw {
        message: "AWS credential is missing",
        statusCode: 500,
      };
    }
    const s3 = new S3({
      accessKeyId: process.env.NEXT_PUBLIC_ACCESS_KEY,
      secretAccessKey: process.env.NEXT_PUBLIC_SECRET_KEY,
      region: process.env.NEXT_PUBLIC_REGION,
    });
    const reqBody = await req.json();

    const s3Params = {
      Bucket: process.env.NEXT_PUBLIC_BUCKET_NAME,
      Key: "user-profiles/" + reqBody.fileName,
      Expires: 600,
      ContentType: reqBody.fileType,
    };
    const uploadUrl = await s3.getSignedUrl("putObject", s3Params);

    // console.log("uploadUrl ***********************", uploadUrl);
    return NextResponse.json({
      uploadUrl,
    });
  } catch (error: any) {
    return NextResponse.json(
      {
        error: error.message,
      },
      {
        status: 500,
      }
    );
  }
}
