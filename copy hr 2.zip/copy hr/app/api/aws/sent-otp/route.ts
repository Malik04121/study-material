import { getDataFromToken } from "@/helper/getDataFromToken";
import User from "@/models/UserModel";
import { NextRequest, NextResponse } from "next/server";
import { SESClient, SendEmailCommand } from "@aws-sdk/client-ses";



const sesClient = new SESClient({
  region: process.env.NEXT_PUBLIC_REGION,
  credentials: {
    accessKeyId: process.env.NEXT_PUBLIC_ACCESS_KEY!,
    secretAccessKey: process.env.NEXT_PUBLIC_SECRET_KEY!,
  },
});


export async function POST(request: NextRequest) {
  try {
    const reqBody = await request.json();
    const { email } = reqBody;

    const generateOTP = () =>
      Math.floor(100000 + Math.random() * 900000).toString();

    const otp = generateOTP();

    // const data = getDataFromToken(request);

    const expiryDate = new Date();
    expiryDate.setMinutes(expiryDate.getMinutes() + 10);

    try {
      await User.findOneAndUpdate(
        { email: email },
        {
          otpForVerification: otp,
          expiryDateForOTP: expiryDate,
        },
        { new: true }
      );
    } catch (error: any) {
      return NextResponse.json(
        {
          message: "Your email is invalid or does not exist",
          success: false,
        },
        {
          status: 404,
        }
      );
    }

    const emailParams = {
      Source: "jatinp8390@gmail.com",
      Destination: {
        ToAddresses: [email],
      },
      Message: {
        Subject: {
          Data: `${otp} is your verification code`,
        },
        Body: {
          Html: {
            Data: `
              <!DOCTYPE html>
              <html lang="en">
              <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Your OTP Code</title>
                <style>
                  body {
                    font-family: Arial, sans-serif;
                    background-color: #f4f4f4;
                    color: #333;
                    margin: 0;
                    padding: 0;
                  }
                  .container {
                    width: 100%;
                    max-width: 600px;
                    margin: 0 auto;
                    background-color: #fff;
                    padding: 20px;
                    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                    border-radius: 8px;
                  }
                  .header {
                    background-color: #f4f4f4;
                    padding: 20px;
                    text-align: center;
                    border-bottom: 1px solid #ddd;
                  }
                  .header h1 {
                    margin: 0;
                    font-size: 24px;
                    color: #333;
                  }
                  .content {
                    padding: 20px;
                    text-align: center;
                  }
                  .content p {
                    font-size: 16px;
                    font-weight: semibold;
                    margin: 10px 0;
                  }
                  .otp {
                    font-size: 24px;
                    font-weight: bold;
                    color: #007bff;
                    background-color: #f4f4f4;
                    padding: 10px;
                    border-radius: 5px;
                    display: inline-block;
                    margin: 20px 0;
                  }
                  .footer {
                    margin-top: 20px;
                    font-size: 12px;
                    color: #777;
                    text-align: center;
                  }
                </style>
              </head>
              <body>
                <div class="container">
                  <div class="header">
                    <h1>WA Collab</h1>
                  </div>
                  <div class="content">
                    <p>Verification code</p>
                    <p>Enter this code in the next 10 minutes for verification:</p>
                    <div class="otp">${otp}</div>
                    <p>If you did not request this code, you can ignore and delete this email.</p>
                  </div>
                  <div class="footer">
                    <p>&copy; ${new Date().getFullYear()} WA Collab All rights reserved.</p>
                  </div>
                </div>
              </body>
              </html>
            `,
          },
        },
      },
    };

    const result = await sesClient.send(new SendEmailCommand(emailParams));
    console.log(result);

    return NextResponse.json(
      {
        message: "Email sent successfully",
        success: true,
      },
      {
        status: 200,
      }
    );
  } catch (error: any) {
    console.log(error.message);

    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
