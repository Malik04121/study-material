import CreateAccount from "@/components/pages/CreateAccount";
import { Metadata } from "next";
import React from "react";

export const metadata: Metadata = {
  title: "Create Account | WA Collab App",
  description:
    "Join WA Collab App and connect with your communities. Create your account today!",
};
const CreateAccountInWa = () => {
  return <CreateAccount />;
};

export default CreateAccountInWa;
