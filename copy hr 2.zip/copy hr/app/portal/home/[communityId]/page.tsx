"use client";
import CommunityHost from "@/components/pages/CommunityHost";
import React, { useEffect, useState } from "react";

import Home from "@/components/pages/communityDashboard/Home";
import Sidebar from "@/components/pages/Sidebar";
import CommunityNavbar from "@/components/pages/CommunityNavbar";

type PageProps = {
  params: {
    communityId: string;
  };
};

const Page = ({ params }: PageProps) => {
  const { communityId } = params;
  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(false);
  const [activePage, setActivePage] = useState<string>("Home");
  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  const closeSidebar = () => {
    setIsSidebarOpen(false);
  };
  useEffect(() => {
    if (isSidebarOpen) {
      document.body.classList.add("no-scroll");
    } else {
      document.body.classList.remove("no-scroll");
    }
  }, [isSidebarOpen]);
  return (
    <section className={"bg-white overflow-x-hidden desktopView relative"}>
      <CommunityHost communityId={communityId}>
        <Sidebar
          isOpen={isSidebarOpen}
          onClose={closeSidebar}
          setActivePage={setActivePage}
          activePage={activePage}
        />
        <CommunityNavbar onMenuToggle={toggleSidebar} activePage={activePage} />
        <Home />
      </CommunityHost>
    </section>
  );
};

export default Page;
