"use client";
import CommunityHost from "@/components/pages/CommunityHost";
import React, { useEffect, useState } from "react";
import Sidebar from "@/components/pages/Sidebar";
import CommunityNavbar from "@/components/pages/CommunityNavbar";
import { CommunityDetails } from "@/types/communityDetails.types";
import { Toaster } from "react-hot-toast";
import Contents from "@/components/pages/communityDashboard/Contents";
import { useParams } from "next/navigation";

const Page = () => {
  const params = useParams();
  let { communityId } = params;
  if (Array.isArray(communityId)) {
    communityId = communityId[0]; // Take the first element if it's an array
  }
  console.log(params);

  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(false);
  const [activePage, setActivePage] = useState<string>("Contents");
  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  const closeSidebar = () => {
    setIsSidebarOpen(false);
  };
  useEffect(() => {
    if (isSidebarOpen) {
      document.body.classList.add("no-scroll");
    } else {
      document.body.classList.remove("no-scroll");
    }
  }, [isSidebarOpen]);
  console.log("communityId in content", communityId);

  return (
    <section className={"bg-white overflow-x-hidden desktopView relative"}>
      {/* <h1 className="text-4xl text-black">{communityId}</h1> */}
      <CommunityHost communityId={communityId}>
        <Sidebar
          isOpen={isSidebarOpen}
          onClose={closeSidebar}
          setActivePage={setActivePage}
          activePage={activePage}
        />
        <CommunityNavbar onMenuToggle={toggleSidebar} activePage={activePage} />
        <Contents
          setCommunityDetails={function (
            value: React.SetStateAction<CommunityDetails | undefined>
          ): void {
            throw new Error("Function not implemented.");
          }}
        />
      </CommunityHost>
      <Toaster />
    </section>
  );
};

export default Page;
