"use client";
import CommunityHost from "@/components/pages/CommunityHost";
import React, { useEffect, useState } from "react";
import Sidebar from "@/components/pages/Sidebar";
import CommunityNavbar from "@/components/pages/CommunityNavbar";
import Settings from "@/components/pages/communityDashboard/Settings";
import { CommunityDetails } from "@/types/communityDetails.types";
import { Toaster } from "react-hot-toast";
import { User } from "@/types/user.types";

type PageProps = {
  params: {
    communityId: string;
  };
};

const Page = ({ params }: PageProps) => {
  const { communityId } = params;
  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(false);
  const [activePage, setActivePage] = useState<string>("Settings");
  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  const closeSidebar = () => {
    setIsSidebarOpen(false);
  };
  useEffect(() => {
    if (isSidebarOpen) {
      document.body.classList.add("no-scroll");
    } else {
      document.body.classList.remove("no-scroll");
    }
  }, [isSidebarOpen]);
  return (
    <section className={"bg-white overflow-x-hidden desktopView relative"}>
      <CommunityHost communityId={communityId}>
        <Sidebar
          isOpen={isSidebarOpen}
          onClose={closeSidebar}
          setActivePage={setActivePage}
          activePage={activePage}
        />
        <CommunityNavbar onMenuToggle={toggleSidebar} activePage={activePage} />
        <Settings
          setCommunityDetails={function (
            value: React.SetStateAction<CommunityDetails | undefined>
          ): void {
            throw new Error("Function not implemented.");
          }}
          setLoggedUserData={function (
            value: React.SetStateAction<User | undefined>
          ): void {
            throw new Error("Function not implemented.");
          }}
        />
      </CommunityHost>
      <Toaster />
    </section>
  );
};

export default Page;
