import Image from "next/image";
import React from "react";

const ServiceUnavailable = () => {
  return (
    <div className="w-screen h-screen  desktopView flex justify-center items-center bg-white ">
      <div className="text-center flex flex-col  p-8 ">
        <Image
          src="/assets/pages/503.jpg"
          alt="Unauthorized"
          width={500}
          height={300}
          className="mx-auto"
        />
      </div>
    </div>
  );
};

export default ServiceUnavailable;
