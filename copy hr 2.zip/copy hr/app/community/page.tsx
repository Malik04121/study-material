import MyCommunity from "@/components/pages/MyCommunities";
import React from "react";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "My Communities | WA Collab App ",
  description: "Explore and manage your communities on the WA Collab App.",
};

const Community = () => {
  return <MyCommunity />;
};

export default Community;
