import Image from "next/image";
import Link from "next/link";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Page Not Found | WA Collab App",
  description:
    "The page you are looking for does not exist or may have been moved. Please check the URL or return to the login page.",
};

export default function NotFound() {
  return (
    <div className="w-screen h-screen desktopView flex justify-center items-center bg-white">
      <div className="text-center flex w-full flex-col gap-3 p-8 bg-white shadow-lg rounded-lg h-full">
        <Image
          src="/assets/pages/401.jpg"
          alt="Unauthorized"
          width={500}
          height={300}
          className="mx-auto"
        />

        <h1 className="text-4xl font-bold text-gray-800 mt-6">
          The Page does not exist
        </h1>
        <div className="space-y-3">
          <p className="text-sm font-light">
            You may have mistyped the address or the page may have moved.
          </p>
          <p>Error code: 404</p>
        </div>
        <Link href={"/login"} className="primaryButton">
          Go To login page
        </Link>
      </div>
    </div>
  );
}
