"use client";
import ProfileModal from "@/components/pages/ProfileModal";
import UpdateAdditionalDetailsModal from "@/components/pages/UpdateAdditionalDetailsModal"; // Import the new modal component
import { User } from "@/types/user.types";
import axios from "axios";
import Image from "next/image";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import React, { Suspense, useEffect, useRef, useState } from "react";
import toast, { Toaster } from "react-hot-toast";
import EditImageModal from "@/components/modal/EditImageModal"; // Ensure the path is correct

const ProfileSetting = () => {
  const [loggedUserData, setLoggedUserData] = useState<User>();
  const [isProfileModalOpen, setProfileModalOpen] = useState(false);
  const [isAdditionalDetailsModalOpen, setIsAdditionalDetailsModalOpen] =
    useState(false);
  const [isEditImageModalOpen, setIsEditImageModalOpen] = useState(false); // State for edit image modal
  const [avatar, setAvatar] = useState<string>(""); // State for avatar
  const fileInputRef = useRef<HTMLInputElement>(null);
  const router = useRouter();
  const searchParams = useSearchParams();
  const [backTo, setBackTo] = useState<string>("");
  const [isUploading, setIsUploading] = useState<boolean>(false);
  const [additionalMemberDetails, setAdditionalMemberDetails] = useState<
    Map<string, string>
  >(new Map());
  const [communityDetails, setCommunityDetails] = useState(null); // For passing to UpdateAdditionalDetailsModal
  const [memberId, setMemberId] = useState<string>(""); // State to store memberId

  const checkTokenValidity = async () => {
    try {
      const response = await axios.get("/api/users/check-user");
      if (response.data) {
        setLoggedUserData(response.data.user);
        setAvatar(response.data.user.avatar); // Set avatar state
        await fetchCommunityAndMemberDetails(response.data.user);
      }
      return true;
    } catch (error) {
      console.error(error);
      router.push("/unauthorized");
      return false;
    }
  };

  const fetchCommunityAndMemberDetails = async (user: User) => {
    const publicUrl = searchParams.get("fromCommunity");
    if (publicUrl) {
      setBackTo(`/${publicUrl}`);
      try {
        const communityResponse = await axios.get(
          `/api/community/get-by-public-url/${publicUrl}`
        );
        const community = communityResponse.data.community;
        setCommunityDetails(community);
        console.log(community);

        const userCommunity = user.communityDetails.find(
          (communityDetail) => communityDetail.communityId === community._id
        );
        console.log(userCommunity);

        if (userCommunity) {
          const memberResponse = await axios.get(
            `/api/member/${userCommunity.memberId}`
          );
          const member = memberResponse.data.member;
          setMemberId(userCommunity.memberId); // Set the memberId state
          console.log(member);

          if (member.additionalFields) {
            setAdditionalMemberDetails(
              new Map(Object.entries(member.additionalFields))
            );
          }
        }
      } catch (error) {
        console.error("Error fetching community or member details:", error);
      }
    }
  };

  const handleEditImageClick = () => {
    setIsEditImageModalOpen(true); // Open the edit image modal
  };

  const handleFileChange = async (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = event.target.files?.[0];
    if (file) {
      const validImageTypes = [
        "image/jpeg",
        "image/png",
        "image/gif",
        "image/webp",
      ];
      if (!validImageTypes.includes(file.type)) {
        toast.error(
          "Please upload a valid image file (JPEG, PNG, GIF, or WEBP)"
        );
        return;
      }
      setIsUploading(true);
      setIsEditImageModalOpen(false);
      try {
        const url = await getSignedUrl(file);
        await uploadImageToS3(url, file);
        console.log(url.split("?")[0]);

        const updatedUser = await updateUserProfileImage(url.split("?")[0]);
        setLoggedUserData(updatedUser);
        setAvatar(url.split("?")[0]); // Update avatar state
      } catch (error) {
        console.error("Error uploading image:", error);
      } finally {
        setIsUploading(false);
      }
    }
  };

  const getSignedUrl = async (file: File): Promise<string> => {
    const response = await axios.post("/api/aws/get-signed-url", {
      fileName: file.name,
      fileType: file.type,
    });
    console.log(response);

    return response.data.uploadUrl;
  };

  const uploadImageToS3 = async (url: string, file: File) => {
    try {
      const response = await axios.put(url, file, {
        headers: {
          "Content-Type": file.type,
        },
      });
      console.log(response);
    } catch (error) {
      console.error(error);
    }
  };

  const updateUserProfileImage = async (imageUrl: string) => {
    try {
      const response = await axios.put("/api/users/update-profile-image", {
        imageUrl,
      });
      return response.data.user;
    } catch (error) {
      console.log("You are unauthorized");
      console.error(error);
    }
  };

  const handleSaveProfile = async (updatedUser: Partial<User>) => {
    try {
      if (loggedUserData) {
        const response = await axios.put("/api/users/update-profile", {
          ...loggedUserData,
          ...updatedUser,
        });
        setLoggedUserData(response.data.user);
        toast("Your profile has been updated successfully.!", {
          icon: "✅",
          style: { backgroundColor: "#454545", color: "white" },
        });
      }
    } catch (error) {
      console.log("You are unauthorized");
      router.push("/unauthorized");

      console.error(error);
    }
  };

  const handleSaveAdditionalDetails = async (
    additionalDetails: Map<string, string>
  ) => {
    try {
      if (loggedUserData && memberId) {
        // Convert Map to Object
        const additionalDetailsObject = Object.fromEntries(additionalDetails);

        const response = await axios.post(
          "/api/member/update-additional-details",
          {
            memberId: memberId,
            additionalDetails: additionalDetailsObject, // Send as an object
          }
        );
        setAdditionalMemberDetails(
          new Map(Object.entries(response.data.member.additionalFields))
        );
        toast("Additional details have been updated successfully.!", {
          icon: "✅",
          style: { backgroundColor: "#454545", color: "white" },
        });
      }
    } catch (error) {
      console.log("You are unauthorized");
      router.push("/unauthorized");

      console.error(error);
    }
  };

  const handleDeleteImage = () => {
    const defaultImage =
      "https://hr-network-assets.s3.ap-south-1.amazonaws.com/profile-default-icon-512x511-v4sw4m29.png";

    updateUserProfileImage(defaultImage).then((updatedUser) => {
      setLoggedUserData(updatedUser);
      setAvatar(defaultImage); // Update avatar state
      setIsEditImageModalOpen(false); // Close the modal
    });
  };

  useEffect(() => {
    const getFrom = searchParams.get("fromCommunity");
    if (getFrom) {
      setBackTo(`/${getFrom}`);
    } else if (searchParams.get("fromPortal")) {
      const getFromPortal = searchParams.get("fromPortal");
      setBackTo(`/portal/home/${getFromPortal}`);
    } else {
      setBackTo(`/login`);
    }

    const init = async () => {
      await checkTokenValidity();
    };

    init();
  }, []);
  useEffect(() => {
    if (isAdditionalDetailsModalOpen || isProfileModalOpen) {
      document.body.classList.add("no-scroll");
    } else {
      document.body.classList.remove("no-scroll");
    }
  }, [isAdditionalDetailsModalOpen, isProfileModalOpen]);
  console.log(additionalMemberDetails.size);

  return (
    <Suspense>
      <div className="flex flex-col min-h-screen bg-white text-primaryBlack desktopView">
        <div className="flex justify-start items-center gap-3 px-5 py-5 border-b-gray-400 border-[1px]">
          <Link href={backTo} className="text-white w-7 h-7">
            <Image
              src={"/assets/icons/left-arrows.png"}
              alt="back_icon"
              width={50}
              height={50}
              className="object-cover"
            />
          </Link>
          <h2 className="font-semibold text-xl">Profile Settings</h2>
        </div>
        {loggedUserData && (
          <div className="border-[1px] rounded p-5 m-5 bg-white shadow-2xl">
            <div className="flex flex-col justify-start items-center gap-10 w-full h-full">
              <div className="flex justify-between items-center gap-3 w-full">
                <div className="relative w-[4.5rem] h-[4.5rem]">
                  <Image
                    src={avatar} // Use avatar state
                    alt="profile_photo"
                    width={70}
                    height={70}
                    className="object-cover w-full h-full object-center rounded-full"
                  />
                  <button
                    className="w-7 h-7 absolute right-[0rem] bottom-[0rem] bg-white rounded-full p-1"
                    onClick={handleEditImageClick}
                  >
                    <Image
                      src={"/assets/icons/edit-button.png"}
                      alt="update"
                      width={20}
                      height={20}
                      className="object-cover object-center"
                    />
                  </button>
                  {isUploading && (
                    <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center rounded-full text-xs">
                      <p className="text-white">Uploading..</p>
                    </div>
                  )}
                </div>
                <div className="flex flex-1 flex-col justify-between items-start py-1">
                  <p className="font-medium">{loggedUserData.fullName}</p>
                </div>
              </div>
              <div className="flex justify-between items-center w-full">
                <p>Mobile Number (WhatsApp)</p>
                <p>{loggedUserData.phoneNumber}</p>
              </div>
              <div className="flex justify-between items-center w-full">
                <p>Email</p>
                <p>{loggedUserData.email}</p>
              </div>
              <button
                type="button"
                className="primaryButton"
                onClick={() => setProfileModalOpen(true)}
              >
                Edit Profile
              </button>
            </div>
          </div>
        )}
        {loggedUserData && (
          <ProfileModal
            isOpen={isProfileModalOpen}
            onClose={() => setProfileModalOpen(false)}
            user={loggedUserData}
            onSave={handleSaveProfile}
            setLoggedUserData={setLoggedUserData}
            avatar={avatar} // Pass avatar state
            setAvatar={setAvatar} // Pass setAvatar function
          />
        )}
        {isEditImageModalOpen && (
          <EditImageModal
            isOpen={isEditImageModalOpen}
            onClose={() => setIsEditImageModalOpen(false)}
            onFileChange={handleFileChange}
            onDelete={handleDeleteImage}
            avatar={avatar}
          />
        )}

        <div className="p-5">
          {loggedUserData && additionalMemberDetails.size > 0 && (
            <div className="border-[1px] rounded p-5 bg-white shadow-2xl w-full">
              <div className="flex flex-col justify-start items-center gap-4 w-full h-full">
                <div className="flex justify-between items-center w-full mb-4">
                  <h3 className="text-lg font-semibold">
                    Community Additional Details
                  </h3>
                </div>
                {Object.entries(
                  Object.fromEntries(additionalMemberDetails)
                ).map(([key, value]) => (
                  <div
                    key={key}
                    className="flex justify-between items-start w-full gap-2"
                  >
                    <p className="font-medium w-1/2 break-words">{key}</p>
                    <p className="w-1/2 break-words">{value ? value : "-"}</p>
                  </div>
                ))}
              </div>
              <button
                type="button"
                className="primaryButton mt-4"
                onClick={() => setIsAdditionalDetailsModalOpen(true)}
              >
                Update Additional Details
              </button>
            </div>
          )}
        </div>

        {isAdditionalDetailsModalOpen && communityDetails && loggedUserData && (
          <UpdateAdditionalDetailsModal
            isOpen={isAdditionalDetailsModalOpen}
            onClose={() => setIsAdditionalDetailsModalOpen(false)}
            communityDetails={communityDetails}
            onSave={handleSaveAdditionalDetails}
            additionalMemberDetails={additionalMemberDetails}
          />
        )}

        <Toaster />
      </div>
    </Suspense>
  );
};

export default ProfileSetting;
