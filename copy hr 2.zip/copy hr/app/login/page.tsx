import LoginPage from "@/components/pages/Login";
import React from "react";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Login | WA Collab app",
  description: "Log in to WA Collab App and manage your communities with ease.",
};
const Login = () => {
  return <LoginPage />;
};

export default Login;
