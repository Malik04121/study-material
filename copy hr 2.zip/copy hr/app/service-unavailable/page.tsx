import Image from "next/image";
import React from "react";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Service Unavailable | WA Collab App",
  description:
    "The service is temporarily unavailable. Please try again later.",
};

const ServiceUnavailable = () => {
  return (
    <div className="w-screen h-screen desktopView flex justify-center items-center bg-white">
      <div className="text-center flex flex-col p-8">
        <Image
          src="/assets/pages/503.jpg"
          alt="Service Unavailable"
          width={500}
          height={300}
          className="mx-auto"
        />
        <h1 className="text-4xl font-bold text-gray-800 mt-6">
          Service Unavailable
        </h1>
        <p className="text-sm font-light mt-3">
          The service is temporarily unavailable. Please try again later.
        </p>
      </div>
    </div>
  );
};

export default ServiceUnavailable;
