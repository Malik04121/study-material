"use client";
import axios from "axios";
import Image from "next/image";
import Link from "next/link";
import { notFound, useRouter } from "next/navigation";
import React, { useEffect, useReducer, useState } from "react";
import toast, { Toaster } from "react-hot-toast";
import { FaCopy } from "react-icons/fa";

const Page = ({
  params,
}: {
  params: { publicUrl: string; title: string; communityId: string };
}) => {
  const [editMode, setEditMode] = useState(false);
  const [editedPublicUrl, setEditedPublicUrl] = useState(
    decodeURIComponent(params.publicUrl)
  );
  //copy work
  const [copySuccess, setCopySuccess] = useState(false);
  const router = useRouter();
  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(
        process.env.NEXT_PUBLIC_DOMAIN_NAME + "/" + params.publicUrl
      );
      setCopySuccess(true);
    } catch (err) {
      console.error("Failed to copy:", err);
    }
  };
  const handleEditClick = () => {
    setEditMode(true);
  };

  const handleCancelEdit = () => {
    setEditMode(false);
    setEditedPublicUrl(decodeURIComponent(params.publicUrl)); // Reset to original value
  };

  const handleSave = async () => {
    // For demo purposes, just log the new URL
    console.log("Updated URL:", editedPublicUrl);
    try {
      let memberId = "";
      try {
        let response = await axios.post("/api/users/me", {
          publicUrl: decodeURIComponent(params.publicUrl),
        });
        console.log(response.data);
        memberId = response.data.data.memberId;
        if (response.status) {
          response = await axios.put("/api/community", {
            newPublicUrl: editedPublicUrl,
            publicUrl: decodeURIComponent(params.publicUrl),
            memberId,
          });
          console.log(response);
          if (response.status === 200) {
            setEditMode(false);
            router.push(
              "/update-community/" +
                response.data.community.publicPageUrl +
                "/" +
                params.title +
                "/" +
                params.communityId
            );
            toast("Community updated successfully!", {
              icon: "✅",
              style: {
                backgroundColor: "white",
                color: "black",
              },
              id: params.communityId,
            });
          } else if (response.status === 201) {
            toast("Community Url already exists!", {
              icon: "❌",
              style: {
                backgroundColor: "white",
                color: "black",
              },
            });
          } else if (response.status === 404) {
            toast("Community not exist!", {
              icon: "❌",
              style: {
                backgroundColor: "white",
                color: "black",
              },
            });
            notFound();
          }
        }
      } catch (error) {
        console.error(error);
        if (axios.isAxiosError(error)) {
          if (error.response?.status === 404) {
            toast("Community doesn't exist!", {
              icon: "🚫",
              style: {
                backgroundColor: "white",
                color: "black",
              },
            });

            notFound();
          }
          console.log(error.response);
        }
        toast("You are unauthorized", {
          icon: "🚫",
          style: {
            backgroundColor: "white",
            color: "black",
          },
        });
        router.push("/unauthorized");
      }
    } catch (error) {
      console.error(error);
      console.error("Community not exist");

      if (axios.isAxiosError(error)) {
        if (error.response?.status === 401) {
          toast("You are unauthorized", {
            icon: "🚫",
            style: {
              backgroundColor: "white",
              color: "black",
            },
          });

          router.push("/unauthorized");
        }
        console.log(error.response);
      }
    }

    // Exit edit mode
  };

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    // Remove '%' signs
    let value = event.target.value;

    value = value.replace(/[^a-zA-Z0-9 -]/g, "");

    setEditedPublicUrl(value);
  };
  useEffect(() => {
    if (copySuccess) {
      // toast.success("Link copied to clipboard!");
      toast("Link copied to clipboard!", {
        icon: "👍",
        style: {
          backgroundColor: "white",
          color: "black",
        },
      });
      setCopySuccess(false);
    }
  }, [copySuccess]);

  return (
    <section className="w-screen  overflow-x-clip min-h-[100vh] colorChange  ">
      <div className="flex desktopView  min-h-[100vh] lg:justify-center mx-auto flex-col px-6 py-3 w-full    justify-start gap-20 items-center ">
        <div className="w-full ">
          <Image
            src={"/logo.jpeg"}
            alt="logo"
            width={50}
            height={50}
            className=""
          />
        </div>

        <div className="text-white font-medium text-3xl w-full whitespace-normal break-words">
          Congrats! {decodeURIComponent(params.publicUrl)} is live!
        </div>

        {editMode ? (
          <form className="w-full">
            <div className="space-y-3 w-full">
              <label
                htmlFor="pageUrl"
                className="text-lg  text-white font-medium"
              >
                Community Page URL
              </label>
              <div className="space-y-10">
                <input
                  type="text"
                  id="pageUrl"
                  value={editedPublicUrl}
                  onChange={handleChange}
                  className="border-[0.5px] text-white bg-transparent text-xl font-medium focus:border-white outline-none border-white rounded-lg px-3 py-3 w-full flex items-center justify-between"
                />
                <div className="flex justify-start items-stretch gap-2">
                  <button
                    type="button"
                    onClick={handleCancelEdit}
                    className="text-sm px-3 py-2 text-primaryBlack  bg-white rounded-3xl"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={handleSave}
                    disabled={params.publicUrl === editedPublicUrl.trim()}
                    className="text-sm px-5 py-2 text-white bg-primaryBlack  rounded-3xl disabled:bg-opacity-50"
                  >
                    Save
                  </button>
                </div>
              </div>
            </div>
          </form>
        ) : (
          <>
            <div className="space-y-3 w-full">
              <label
                htmlFor="pageUrl"
                className="text-lg text-white font-medium"
              >
                Community Page URL
              </label>
              <button
                onClick={copyToClipboard}
                type="button"
                className="border-[0.5px] min-w-full text-white   text-lg border-white rounded-lg px-3 py-5 w-full flex items-center justify-between group hover:bg-white hover:bg-opacity-50"
              >
                <div className="flex-1 break-words ">
                  <p className=" font-medium break-words text-left">
                    {process.env.NEXT_PUBLIC_DOMAIN_NAME +
                      "/" +
                      decodeURIComponent(params.publicUrl)}
                  </p>
                </div>
                <div className="ml-2 w-auto focus:outline-none invisible group-hover:visible">
                  <FaCopy />
                </div>
              </button>
              <div className=" flex justify-start gap-3 items-center">
                <button
                  onClick={handleEditClick}
                  className="border-white border-[0.5px] rounded-full flex justify-center items-center w-12 h-12"
                >
                  <Image
                    src={"/assets/icons/edit_icon.svg"}
                    alt="edit_icon"
                    width={25}
                    height={25}
                  />
                </button>
                <Link
                  href={
                    (process.env.NEXT_PUBLIC_DOMAIN_NAME ||
                      "http://localhost:3000") +
                    "/" +
                    decodeURIComponent(params.publicUrl)
                  }
                  target="_blank"
                  className="border-white border-[0.5px] rounded-full flex justify-center items-center w-12 h-12"
                >
                  <Image
                    src={"/assets/icons/link_icon.png"}
                    alt="link_icon"
                    width={25}
                    height={25}
                  />
                </Link>
              </div>
            </div>
          </>
        )}
        <div className="w-full pb-10">
          <button
            type="button"
            disabled={editMode}
            className="primaryButton text-center"
            onClick={() => {
              router.push(`/portal/home/${params.communityId}`);
            }}
          >
            Continue to portal
          </button>
        </div>
      </div>
      <Toaster />
    </section>
  );
};

export default Page;
