import React from "react";

type Props = {};
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Home | WA Collab app",
  description: "Home page of WA Collab app",
};
const page = async (props: Props) => {
  return (
    <main className="text-primaryBlack  text-3xl desktopView min-h-screen ">
      Home Page (under development 👨🏻‍💻){" "}
    </main>
  );
};

export default page;
