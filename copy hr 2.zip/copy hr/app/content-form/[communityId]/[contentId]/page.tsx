import CommunityPublicPage from "@/components/pages/PublicPage";
import React from "react";
import type { Metadata } from "next";
import PublicContentForm from "@/components/PublicContentForm";

export const metadata: Metadata = {
  title: "Community Form | WA Collab app",
  description: "Community Form for WA Collab app",
};
const ContentForm = ({
  params,
}: {
  params: { contentId: string; communityId: string };
}) => {
  return <PublicContentForm params={params} />;
};

export default ContentForm;
