"use client";
import MemberAuthProvider from "@/components/reusable/MemberAuthProvider";
import { CommunityDetails, ContentType } from "@/types/communityDetails.types";
import { User } from "@/types/user.types";
import axios from "axios";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import React, { useEffect, useRef, useState } from "react";

const ContentFormOfCommunity = ({
  params,
}: {
  params: { communityId: string };
}) => {
  const [communityDetails, setCommunityDetails] = useState<CommunityDetails>();
  const [loggedUserData, setLoggedUserData] = useState<User>();
  const [showProfile, setShowProfile] = useState<boolean>(false);
  const profileRef = useRef<HTMLDivElement>(null);
  const buttonRef = useRef<HTMLButtonElement>(null);

  const router = useRouter();
  const { communityId } = params;
  const fetchCommunity = async () => {
    try {
      const response = await axios.get(
        `/api/community/get-by-id/${communityId}`
      );
      if (response.status === 200) {
        console.log(response.data.community);

        setCommunityDetails(response.data.community);
      } else {
        console.log("Unexpected status code:", response.status);
      }
    } catch (error) {
      console.error(error);
      router.push("/not-found");
    }
  };
  const checkTokenValidity = async () => {
    try {
      const response = await axios.get("/api/users/check-user");
      if (response.data) {
        setLoggedUserData(response.data.user);
      }
      return true;
    } catch (error) {
      console.error(error);
      return false;
    }
  };

  const handleClickOutside = (event: MouseEvent) => {
    if (
      profileRef.current &&
      !profileRef.current.contains(event.target as Node) &&
      buttonRef.current &&
      !buttonRef.current.contains(event.target as Node)
    ) {
      setShowProfile(false);
    }
  };

  const logout = async () => {
    try {
      const response = await axios.delete("/api/users/logout");

      if (response.data) {
        window.location.reload();
      }
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  useEffect(() => {
    const init = async () => {
      await fetchCommunity();
      await checkTokenValidity();
    };
    init();
  }, [communityId]);
  return (
    <div className="bg-gray-100  desktopView  ">
      <div className="bg-slate-100   w-full min-h-screen ">
        {loggedUserData && communityDetails && (
          <nav className="sticky top-0 w-full bg-white z-[10] px-5 py-2">
            <div className="flex justify-between items-center relative">
              <div>
                <Image src={"/logo.jpeg"} alt="logo" width={70} height={70} />
              </div>
              <div>
                <div className="flex justify-center items-center gap-2">
                  {loggedUserData.communityDetails.find(
                    (communityDe) =>
                      communityDe.communityId === communityDetails._id
                  )?.memberId === communityDetails.host && (
                    <Link
                      href={"/portal/home/" + communityDetails._id}
                      className="public-page-primaryButton"
                    >
                      Dashboard
                    </Link>
                  )}
                  <button
                    ref={buttonRef}
                    type="button"
                    className="flex justify-center items-center gap-3 rounded-2xl bg-white hover:bg-gray-200 p-1"
                    onClick={(e) => {
                      e.stopPropagation();
                      setShowProfile((prev) => !prev);
                    }}
                  >
                    <div className="w-8 h-8 rounded-full overflow-hidden">
                      <Image
                        src={loggedUserData.avatar}
                        alt="user_logo"
                        width={100}
                        height={100}
                        className="object-cover w-full h-full"
                      />
                    </div>
                    <div className="w-4 h-4">
                      <Image
                        src={"/assets/icons/menu.png"}
                        alt="menu_icon"
                        width={100}
                        height={100}
                        className="object-center object-cover"
                      />
                    </div>
                  </button>
                </div>
              </div>

              {showProfile && (
                <div
                  ref={profileRef}
                  className="absolute right-0 -bottom-[220%] z-[100] min-w-[50%] rounded-md bg-white text-primaryBlack  drop-shadow-2xl"
                >
                  <div className="flex flex-col justify-between items-startFcon p-4 gap-4">
                    <div className="text-sm ">
                      <p>{loggedUserData?.fullName}</p>
                      <p className="text-gray-500 font-extralight">
                        {loggedUserData?.email}
                      </p>
                    </div>
                    <hr className="bg-gray-600 w-full h-[1px] border border-gray-700" />
                    <Link
                      href={`/user/profile?fromCommunity=${communityDetails.publicPageUrl}`}
                      onClick={() => {
                        setShowProfile(false);
                      }}
                      className="flex justify-start items-center gap-2 w-full"
                    >
                      <Image
                        src={"/assets/icons/demo_profile.png"}
                        alt="profile_icon"
                        width={15}
                        height={15}
                      />
                      <p className="text-sm">Profile Settings</p>
                    </Link>
                    <button
                      type="button"
                      onClick={() => {
                        setShowProfile(false);
                        logout();
                      }}
                      className="flex justify-start items-center gap-2 w-full"
                    >
                      <Image
                        src={"/assets/icons/logout.png"}
                        alt="logout_icon"
                        width={15}
                        height={15}
                      />
                      <p className="text-sm">Logout</p>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </nav>
        )}
        <div className="py-5">
          <MemberAuthProvider communityId={params.communityId}>
            {communityDetails &&
            communityDetails.contentTypes &&
            communityDetails.contentTypes.length > 0 ? (
              communityDetails.contentTypes.map((contentType: ContentType) => (
                <div
                  key={contentType._id}
                  className="flex justify-between gap-2 my-4 px-8"
                >
                  <div className="flex flex-1 bg-white px-4 py-4 rounded-md justify-between items-center">
                    <div>{contentType.title}</div>
                    <div className="flex items-center gap-2">
                      {/* Toggle Active/Inactive Button */}
                    </div>
                  </div>
                  {/* add todo : is member having record then dont show the + button */}
                  <Link
                    href={`/content-form/${communityDetails._id}/${contentType._id}`}
                    target="_blank"
                    className="w-14 bg-white text-xl flex justify-center items-center rounded-md"
                  >
                    <p>+</p>
                  </Link>
                </div>
              ))
            ) : (
              <div className="flex justify-center items-center w-full h-full">
                <h2 className="text-center">There are no Content Types</h2>
              </div>
            )}
          </MemberAuthProvider>
        </div>
      </div>
    </div>
  );
};

export default ContentFormOfCommunity;
