import Unauthorized from "@/components/pages/Unauthorized";
import React from "react";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Unauthorized Access | WA Collab App",
  description:
    "You do not have the necessary permissions to access this page. Please contact your administrator or log in with an authorized account.",
};

const Page = () => {
  return <Unauthorized />;
};

export default Page;
