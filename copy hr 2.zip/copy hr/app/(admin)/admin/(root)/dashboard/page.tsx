"use client";
import React, { useEffect } from "react";
import { useAuthState } from "react-firebase-hooks/auth";
import { useRouter } from "next/navigation";
import { auth } from "@/firebaseConfig/firebase";
import { Dashboard } from "@/components/admindashboard/Dashboard";

type Props = {};

const DashboardPage = (props: Props) => {
  const [user, loading] = useAuthState(auth);
  const router = useRouter();

  useEffect(() => {
    if (!loading && !user) {
      // If the user is not authenticated, redirect to the login page
      router.push("/admin/login");
    }
  }, [user, loading, router]);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="w-16 h-16 border-4 border-t-4 border-t-black border-gray-200 rounded-full animate-spin"></div>
      </div>
    ); // Spinner loading effect
  }

  if (!user) {
    return null; // Render nothing while redirecting
  }

  return (
    <div>
      <Dashboard />
    </div>
  );
};

export default DashboardPage;
