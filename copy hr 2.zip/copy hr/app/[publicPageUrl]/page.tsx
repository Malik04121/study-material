import CommunityPublicPage from "@/components/pages/PublicPage";
import React from "react";
import type { Metadata, ResolvingMetadata } from "next";
import axios from "axios";

type Props = {
  params: { publicPageUrl: string };
};

const PublicPage = ({ params }: Props) => {
  return <CommunityPublicPage params={params} />;
};

export async function generateMetadata(
  { params }: Props,
  parent: ResolvingMetadata
): Promise<Metadata> {
  const decodedUrl = decodeURIComponent(params.publicPageUrl);
  try {
    // Fetch data
    const response = await axios.get(
      `${process.env.NEXT_PUBLIC_DOMAIN_NAME}/api/community/get-by-public-url/${decodedUrl}`
    );

    // Access and extend parent metadata
    const previousImages = (await parent).openGraph?.images || [];

    console.log(response.data);

    return {
      title: response.data.community.title,
      description: response.data.community.description || "",
      openGraph: {
        title: response.data.community.title,
        images: [response.data.community.logoImage, ...previousImages],
      },
    };
  } catch (error) {
    console.error("Error fetching metadata:", error);

    // Fallback metadata in case of an error
    return {
      title: "Community Public | WA Collab app",
      description: "Community Public page for WA Collab app",
      openGraph: {
        images: [
          "/default-logo.png", // A default fallback image
        ],
      },
    };
  }
}

export default PublicPage;
