import CreateCommunity from "@/components/pages/CreateCommunity";
import React from "react";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Create Community | WA Collab App",
  description:
    "Create and manage your communities effortlessly with WA Collab App.",
};

const Page = () => {
  return (
    <div>
      <CreateCommunity />
    </div>
  );
};

export default Page;
