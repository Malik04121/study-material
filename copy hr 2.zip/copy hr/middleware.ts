import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

export function middleware(request: NextRequest) {
  const path = request.nextUrl.pathname;
  const url = new URL(request.url);

  if (path === "/start-community" && !url.searchParams.has("activeStep")) {
    url.searchParams.set("activeStep", "ONBOARDING_STEP_SET_COMMUNITY_NAME");
    return NextResponse.redirect(url);
  }

  const isPublicPath =
    path === "/login" || path === "/signup" || path === "/start-community";

  const token = request.cookies.get("token")?.value || "";

  //   if (isPublicPath && token) {
  //     return NextResponse.redirect(new URL("/start-community", request.nextUrl));
  //   }
  if (path === "/") {
    return NextResponse.redirect(new URL("/login", request.nextUrl));
  }
  // if (path === "/login" && token) {
  //   return NextResponse.redirect(new URL("/start-community", request.nextUrl));
  // }
  if (!isPublicPath && !token) {
    return NextResponse.redirect(new URL("/login", request.nextUrl));
  }

  return NextResponse.next();
}

// See "Matching Paths" below to learn more
export const config = {
  matcher: [
    "/",
    "/login",
    "/signup",
    "/start-community",
    "/update-community/:path*",
    "/portal",
  ],
};
